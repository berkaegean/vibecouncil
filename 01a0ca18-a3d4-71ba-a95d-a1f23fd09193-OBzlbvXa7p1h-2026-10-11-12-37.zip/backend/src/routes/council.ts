import { env } from "../env";
import { Hono } from "hono";
import { z } from "zod";
import {
  birthContext,
  councilSystemPrompt,
  DEFAULT_COUNCIL,
  dailySystemPrompt,
  dmSystemPrompt,
  memoryContext,
  PERSONA_IDS,
  verdictSystemPrompt,
  voteSystemPrompt,
  LANGS,
  respondIn,
  type Lang,
} from "../personas";

const councilRouter = new Hono();

const OPENAI_URL = "https://api.openai.com/v1/responses";
const COUNCIL_MODEL = "gpt-5.6-terra";
const DM_MODEL = "gpt-5.6-luna";

const birthSchema = z
  .object({
    date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
    time: z.string().regex(/^\d{2}:\d{2}$/),
    name: z.string().trim().max(40).optional(),
  })
  .optional();

/** Regular council size, used when the user asks everyone to answer. */
function members0Len(personas?: string[]): number {
  return Math.min(4, new Set(personas ?? DEFAULT_COUNCIL).size);
}

const GRAND_RULE = `

BÜYÜK KONSEY: Bu özel bir oturum, sekiz karakterin hepsi toplandı. Mesaj DEĞERLENDİRME ise her karakter TAM OLARAK TEK CÜMLE söyler (en fazla 18 kelime), vurucu ve karakterine özgü. Karakterler birbirini tekrar etmez; her biri farklı bir açıdan bakar. Mesaj SOHBET ise (ör. "nasılsınız") en az 4 karakter doğal şekilde cevap verir, hüküm yok.`;

const memoriesSchema = z.array(z.string().max(240)).max(40).optional();

/** Tidy a model-proposed memory; "" / junk means nothing to remember. */
function cleanMemory(m: unknown): string | undefined {
  if (typeof m !== "string") return undefined;
  const t = m.trim();
  return t.length >= 6 && t.length <= 200 ? t : undefined;
}

const analyzeSchema = z.object({
  memories: memoriesSchema,
  mode: z.enum(["chat", "vote", "grand"]).optional(),
  /** Grand Council session (all eight); also applies to votes. */
  grand: z.boolean().optional(),
  imageDataUrl: z.string().optional(),
  context: z.string().optional(),
  birth: birthSchema,
  lang: z.enum(LANGS).optional(),
  personas: z.array(z.enum(PERSONA_IDS)).min(1).max(8).optional(),
  /** Earlier turns of this group chat; assistant turns are "Persona: message". */
  history: z
    .array(z.object({ role: z.enum(["user", "assistant"]), content: z.string() }))
    .max(80)
    .optional(),
});

const chatSequenceSchema = z.object({
  chat_sequence: z
    .array(
      z.object({
        persona: z.enum(PERSONA_IDS),
        message: z.string(),
        delay_ms: z.number(),
      })
    )
    .min(1),
  /** The council's joint takeaway on a real question; empty for small talk. */
  consensus: z.string().optional(),
  memory: z.string().optional(),
});

const voteResultSchema = z.object({
  question: z.string().optional(),
  votes: z
    .array(
      z.object({
        persona: z.enum(PERSONA_IDS),
        vote: z.enum(["yes", "no"]),
        reason: z.string(),
      })
    )
    .min(1),
  memory: z.string().optional(),
});

const dmSchema = z.object({
  persona: z.enum(PERSONA_IDS),
  messages: z
    .array(
      z.object({
        role: z.enum(["user", "assistant"]),
        content: z.string(),
      })
    )
    .min(1),
  imageDataUrl: z.string().optional(),
  birth: birthSchema,
  lang: z.enum(LANGS).optional(),
  memories: memoriesSchema,
});

const dailySchema = z.object({
  birth: birthSchema,
  lang: z.enum(LANGS).optional(),
  memories: memoriesSchema,
  /** Local "YYYY-MM-DD"; also picks the persona of the day. */
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
});

type ContentPart =
  | { type: "input_text"; text: string }
  | { type: "input_image"; image_url: string }
  | { type: "output_text"; text: string };

type InputItem = { role: "system" | "user" | "assistant"; content: ContentPart[] };

async function callOpenAI(model: string, input: InputItem[], jsonMode = false): Promise<string> {
  const response = await fetch(OPENAI_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${env.OPEN_AI_APIKEY ?? process.env.OPENAI_API_KEY}`,
    },
    body: JSON.stringify({
      model,
      input,
      // Low reasoning keeps replies snappy; chat doesn't need deep thinking.
      reasoning: { effort: "low" },
      // JSON mode stops the model from answering in prose (e.g. soft refusals on photos).
      ...(jsonMode ? { text: { format: { type: "json_object" } } } : {}),
    }),
  });

  if (!response.ok) {
    const body = await response.text();
    console.error("[council] OpenAI error", response.status, body.slice(0, 500));
    throw new Error(`OpenAI request failed with status ${response.status}`);
  }

  const json: any = await response.json();

  // Responses API: prefer output_text, otherwise walk the output array.
  if (typeof json?.output_text === "string" && json.output_text.length > 0) {
    return json.output_text;
  }

  const parts: string[] = [];
  for (const item of json?.output ?? []) {
    for (const part of item?.content ?? []) {
      if (typeof part?.text === "string") parts.push(part.text);
    }
  }
  const text = parts.join("\n").trim();
  if (!text) console.error("[council] empty output", JSON.stringify(json).slice(0, 800));
  return text;
}

function extractJson(raw: string): unknown {
  const fenced = raw.match(/```(?:json)?\s*([\s\S]*?)```/);
  const candidate = fenced?.[1] ?? raw;
  const start = candidate.indexOf("{");
  const end = candidate.lastIndexOf("}");
  if (start === -1 || end === -1) throw new Error("No JSON object found in model output");
  return JSON.parse(candidate.slice(start, end + 1));
}

councilRouter.post("/analyze", async (c) => {
  const parsed = analyzeSchema.safeParse(await c.req.json().catch(() => null));
  if (!parsed.success) {
    return c.json({ error: { message: "Geçersiz istek", code: "BAD_REQUEST" } }, 400);
  }

  const { imageDataUrl, context, birth } = parsed.data;
  const lang = parsed.data.lang ?? "tr";
  const grand = parsed.data.mode === "grand" || parsed.data.grand === true;
  // "herkes cevap versin" → nearly the whole council answers.
  const everyone = /\b(herkes|hepiniz|hepsi|hep beraber|tüm karakter|bütün karakter|everyone|everybody|all of you)/iu.test(
    parsed.data.context ?? ""
  );
  const minSpeakers = grand ? (everyone ? 7 : 4) : everyone ? members0Len(parsed.data.personas) : 1;
  // The Grand Council seats all eight; regular councils cap at four.
  const members = grand
    ? [...PERSONA_IDS]
    : [...new Set(parsed.data.personas ?? DEFAULT_COUNCIL)].slice(0, 4);
  const history = parsed.data.history ?? [];
  const memories = memoryContext(parsed.data.memories);
  const followUp = history.length > 0;
  // "@Nyx" style tags in the latest message → that persona leads the reply.
  const mentioned = members.filter((id) =>
    new RegExp(`@${id}\\b`, "i").test(context ?? "")
  );
  const mentionRule = mentioned.length
    ? `\n\nETİKET: Kullanıcı ${mentioned.map((m) => "@" + m).join(", ")} etiketledi. ${mentioned.join(" ve ")} ANA cevabı verir: ilk sırada konuşur, 2-3 cümleyle doğrudan kullanıcıya cevap verir. Diğer karakterler ya tamamen sessiz kalır ya da en fazla tek satırlık çok kısa bir yan yorum yapar.`
    : "";
  if (!imageDataUrl && !context?.trim()) {
    return c.json(
      { error: { message: lang !== "tr" ? "An image or a description is required" : "Bir görsel ya da açıklama gerekli", code: "EMPTY_INPUT" } },
      400
    );
  }

  if (parsed.data.mode === "vote") {
    const content: ContentPart[] = [
      {
        type: "input_text",
        text:
          birthContext(birth) +
          `Oylanacak soru/durum: ${context?.trim() || "(sadece görsel)"}\n\nKonsey oylasın, JSON olarak.` +
          respondIn(lang),
      },
    ];
    if (imageDataUrl) content.push({ type: "input_image", image_url: imageDataUrl });
    try {
      let result: ReturnType<typeof voteResultSchema.safeParse> | undefined;
      for (let attempt = 0; attempt < 2 && !result?.success; attempt++) {
        const raw = await callOpenAI(
          COUNCIL_MODEL,
          [
            { role: "system", content: [{ type: "input_text", text: voteSystemPrompt(members, lang) + memories }] },
            { role: "user", content },
          ],
          true
        );
        try {
          result = voteResultSchema.safeParse(extractJson(raw));
        } catch {
          console.error("[council] vote non-JSON", raw.slice(0, 300));
        }
      }
      if (!result?.success) throw new Error("Bad vote output");
      const data = result.data;
      // Exactly one vote per selected member, in the chosen order.
      const votes = members
        .map((id) => data.votes.find((v) => v.persona === id))
        .filter((v): v is NonNullable<typeof v> => Boolean(v));
      if (votes.length === 0) throw new Error("No selected persona voted");
      return c.json({
        data: {
          question: data.question?.trim() || context?.trim() || "",
          votes,
          memory: cleanMemory(data.memory),
        },
      });
    } catch (error) {
      console.error("[council] vote failed", error);
      return c.json(
        { error: { message: lang !== "tr" ? "The council couldn't vote right now, try again" : "Konsey şu an oylayamadı, tekrar dene", code: "UPSTREAM_ERROR" } },
        502
      );
    }
  }

  const speakerRule =
    minSpeakers > 1
      ? `\n\nKONUŞMACI SAYISI (bu kural diğer sayı kurallarını geçersiz kılar): Bu mesaja EN AZ ${minSpeakers} farklı karakter cevap verir${everyone ? " çünkü kullanıcı herkesin cevap vermesini istedi" : ""}. Her karakter en fazla bir kez konuşur, birbirini tekrar etmez.`
      : "";

  const userContent: ContentPart[] = [];
  userContent.push({
    type: "input_text",
    text: (followUp ? "" : birthContext(birth)) + (followUp
      ? `Kullanıcının yeni mesajı: ${context?.trim() || "(sadece görsel)"}\n\nGrup sohbeti devam ediyor. Bu son mesaja 1-4 karakterle tepki ver, JSON olarak.`
      : context?.trim()
      ? `Kullanıcının mesajı: ${context.trim()}\n\nÖnce mesajın SOHBET mi DEĞERLENDİRME mi olduğuna karar ver ve JSON şemasına göre yanıt ver.`
      : "Kullanıcı sadece bir görsel paylaştı, açıklama yazmadı. Konseyi topla ve JSON şemasına göre yanıt ver.") +
      mentionRule +
      (minSpeakers >= 7
        ? `\n\nKullanıcı HERKESİN cevap vermesini istedi. chat_sequence içinde şu karakterlerin HER BİRİ sırayla birer mesaj yazar: ${members.join(", ")}.`
        : minSpeakers > 1
        ? `\n\nEn az ${minSpeakers} farklı karakter cevap versin.`
        : "") +
      "\n\n(Bu gerçek bir soru ya da sorunsa DERİNLİK kuralını uygula: roller ayrı, her karakter net taraf tutar ve somut adım verir; consensus alanı HER ZAMAN boş kalır. Sadece muhabbetse kısa ve doğal kal.)" +
      respondIn(lang),
  });
  if (imageDataUrl) {
    userContent.push({ type: "input_image", image_url: imageDataUrl });
  }

  try {
    const input: InputItem[] = [
      { role: "system", content: [{ type: "input_text", text: councilSystemPrompt(members, lang, followUp) + (grand && !followUp ? GRAND_RULE : "") + speakerRule + memories + (followUp ? `\n\n${birthContext(birth)}` : "") }] },
      ...history.map((h): InputItem =>
        h.role === "user"
          ? { role: "user", content: [{ type: "input_text", text: h.content }] }
          : { role: "assistant", content: [{ type: "output_text", text: h.content }] }
      ),
      { role: "user", content: userContent },
    ];
    // One retry: the model occasionally returns malformed or partial output.
    let raw = "";
    let result: ReturnType<typeof chatSequenceSchema.safeParse> | undefined;
    const speakers = (r: typeof result) =>
      r?.success ? new Set(r.data.chat_sequence.map((m) => m.persona).filter((p) => members.includes(p))).size : 0;
    for (let attempt = 0; attempt < 3 && (!result?.success || speakers(result) < minSpeakers); attempt++) {
      if (attempt >= 1 && result?.success) {
        // Too few voices: ask again, explicitly.
        input[input.length - 1]!.content.unshift({
          type: "input_text",
          text: `Not: Bu mesaja EN AZ ${minSpeakers} FARKLI karakter cevap vermeli.`,
        });
      } else if (attempt === 1 && imageDataUrl) {
        // Retry after a refusal: restate that only style/vibe is being judged.
        input[input.length - 1]!.content.unshift({
          type: "input_text",
          text: "Not: Bu fotoğrafta sadece kıyafet, renk, ışık, ortam ve genel enerji yorumlanacak; kimse tanımlanmayacak ya da fiziksel olarak puanlanmayacak.",
        });
      }
      raw = await callOpenAI(COUNCIL_MODEL, input, true);
      try {
        result = chatSequenceSchema.safeParse(extractJson(raw));
      } catch {
        console.error("[council] non-JSON output", raw.slice(0, 300));
      }
    }
    if (!result) throw new Error("No JSON object found in model output");
    if (!result.success) {
      console.error("[council] schema mismatch", raw.slice(0, 500));
      return c.json(
        { error: { message: lang !== "tr" ? "The council couldn't gather right now, try again" : "Konsey şu an toplanamadı, tekrar dene", code: "BAD_MODEL_OUTPUT" } },
        502
      );
    }

    // Clamp delays so the typing rhythm always feels right.
    // Keep only the selected members, in the chosen order; clamp typing rhythm.
    // First turn: each member once, in the chosen order. Follow-ups: the model's own order.
    const lines = followUp || mentioned.length
      ? result.data.chat_sequence
          .filter((m) => members.includes(m.persona))
          .sort((a, b) => Number(mentioned.includes(b.persona)) - Number(mentioned.includes(a.persona)))
          .slice(0, grand ? 8 : 4)
      : members
          .map((id) => result.data.chat_sequence.find((m) => m.persona === id))
          .filter((m): m is NonNullable<typeof m> => Boolean(m));
    const chat_sequence = lines.map((m) => ({
      ...m,
      delay_ms: grand
        ? Math.min(1300, Math.max(800, Math.round(m.delay_ms)))
        : Math.min(2400, Math.max(1200, Math.round(m.delay_ms))),
    }));
    if (chat_sequence.length === 0) throw new Error("No selected persona in output");

    // No joint ruling mid-chat: the verdict only comes from the "Reveal Verdict" button.

    const memory = cleanMemory(result.data.memory);
    return c.json({
      data: { chat_sequence, memory },
    });
  } catch (error) {
    console.error("[council] analyze failed", error);
    return c.json(
      { error: { message: lang !== "tr" ? "The council couldn't gather right now, try again" : "Konsey şu an toplanamadı, tekrar dene", code: "UPSTREAM_ERROR" } },
      502
    );
  }
});

const verdictSchema = z.object({
  lang: z.enum(LANGS).optional(),
  personas: z.array(z.enum(PERSONA_IDS)).min(1).max(8).optional(),
  history: z
    .array(z.object({ role: z.enum(["user", "assistant"]), content: z.string() }))
    .min(1)
    .max(120),
});

const verdictResultSchema = z.object({
  diagnostics: z.object({ detected_symptoms: z.array(z.string()).min(1) }),
  final_verdict: z.string().min(1),
});

/** "The Verdict": one closing ruling from the whole council over the full chat. */
councilRouter.post("/verdict", async (c) => {
  const parsed = verdictSchema.safeParse(await c.req.json().catch(() => null));
  if (!parsed.success) {
    return c.json({ error: { message: "Geçersiz istek", code: "BAD_REQUEST" } }, 400);
  }
  const lang = parsed.data.lang ?? "tr";
  const members = [...new Set(parsed.data.personas ?? DEFAULT_COUNCIL)];
  const transcript = parsed.data.history
    .map((m) => (m.role === "user" ? `Kullanıcı: ${m.content}` : m.content))
    .join("\n");

  try {
    let result: ReturnType<typeof verdictResultSchema.safeParse> | undefined;
    for (let attempt = 0; attempt < 2 && !result?.success; attempt++) {
      const raw = await callOpenAI(
        COUNCIL_MODEL,
        [
          { role: "system", content: [{ type: "input_text", text: verdictSystemPrompt(members, lang) }] },
          { role: "user", content: [{ type: "input_text", text: `SOHBET GEÇMİŞİ:\n${transcript}\n\nKonseyin ortak nihai kararını JSON olarak açıkla.` }] },
        ],
        true
      );
      try {
        result = verdictResultSchema.safeParse(extractJson(raw));
      } catch {
        console.error("[council] verdict non-JSON", raw.slice(0, 300));
      }
    }
    if (!result?.success) throw new Error("Bad verdict output");
    const symptoms = result.data.diagnostics.detected_symptoms
      .map((s) => s.trim())
      .filter(Boolean)
      .slice(0, 4);
    return c.json({
      data: {
        diagnostics: { detected_symptoms: symptoms },
        final_verdict: result.data.final_verdict.trim(),
      },
    });
  } catch (error) {
    console.error("[council] verdict failed", error);
    return c.json(
      { error: { message: lang !== "tr" ? "The council couldn't reach a verdict, try again" : "Konsey karara varamadı, tekrar dene", code: "UPSTREAM_ERROR" } },
      502
    );
  }
});

councilRouter.post("/dm", async (c) => {
  const parsed = dmSchema.safeParse(await c.req.json().catch(() => null));
  if (!parsed.success) {
    return c.json({ error: { message: "Geçersiz istek", code: "BAD_REQUEST" } }, 400);
  }

  const { persona, messages, imageDataUrl, birth, memories } = parsed.data;
  const lang = parsed.data.lang ?? "tr";

  const history: InputItem[] = messages.map((m, i) => {
    if (m.role === "assistant") {
      return { role: "assistant", content: [{ type: "output_text", text: m.content }] };
    }
    const content: ContentPart[] = [{ type: "input_text", text: m.content }];
    // Only attach the image to the final user turn.
    if (imageDataUrl && i === messages.length - 1) {
      content.push({ type: "input_image", image_url: imageDataUrl });
    }
    return { role: "user", content };
  });

  try {
    const raw = await callOpenAI(
      DM_MODEL,
      [
        { role: "system", content: [{ type: "input_text", text: dmSystemPrompt(persona, birth, lang) + memoryContext(memories) }] },
        ...history,
      ],
      true
    );

    // JSON {message, memory}; fall back to plain text if the model ignored the format.
    let message = raw.trim();
    let memory: string | undefined;
    try {
      const obj = extractJson(raw) as { message?: unknown; memory?: unknown };
      if (typeof obj.message === "string" && obj.message.trim()) message = obj.message.trim();
      memory = cleanMemory(obj.memory);
    } catch {
      // keep raw text
    }
    if (!message) throw new Error("Empty model output");

    return c.json({ data: { persona, message, memory } });
  } catch (error) {
    console.error("[council] dm failed", error);
    return c.json(
      { error: { message: lang !== "tr" ? "Can't reply right now, try again" : "Şu an cevap veremiyor, tekrar dene", code: "UPSTREAM_ERROR" } },
      502
    );
  }
});

councilRouter.post("/daily", async (c) => {
  const parsed = dailySchema.safeParse(await c.req.json().catch(() => null));
  if (!parsed.success) {
    return c.json({ error: { message: "Geçersiz istek", code: "BAD_REQUEST" } }, 400);
  }
  const { birth, memories, date } = parsed.data;
  const lang = parsed.data.lang ?? "tr";
  // Same persona for everyone on a given day, rotating through the eight.
  const day = Math.floor(Date.parse(`${date}T00:00:00Z`) / 86400000);
  const persona = PERSONA_IDS[((day % PERSONA_IDS.length) + PERSONA_IDS.length) % PERSONA_IDS.length]!;

  try {
    const raw = await callOpenAI(
      DM_MODEL,
      [
        { role: "system", content: [{ type: "input_text", text: dailySystemPrompt(persona, lang) + memoryContext(memories) }] },
        {
          role: "user",
          content: [
            {
              type: "input_text",
              text: `${birthContext(birth)}Bugünün tarihi: ${date}. Bugünün mesajını yaz.${respondIn(lang)}`,
            },
          ],
        },
      ],
      true
    );
    const obj = extractJson(raw) as { message?: unknown };
    const message = typeof obj.message === "string" ? obj.message.trim() : "";
    if (!message) throw new Error("Empty daily message");
    return c.json({ data: { persona, message, date } });
  } catch (error) {
    console.error("[council] daily failed", error);
    return c.json(
      { error: { message: lang !== "tr" ? "Today's message isn't ready yet" : "Günün mesajı henüz hazır değil", code: "UPSTREAM_ERROR" } },
      502
    );
  }
});

export { councilRouter };
