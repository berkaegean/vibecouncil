import "@vibecodeapp/proxy"; // DO NOT REMOVE OTHERWISE VIBECODE PROXY WILL NOT WORK
import { env } from "./env";
import { configure as configureProxy } from "@vibecodeapp/proxy";
import { Hono } from "hono";
import { cors } from "hono/cors";
import { sampleRouter } from "./routes/sample";
import { councilRouter } from "./routes/council";
import { logger } from "hono/logger";

// Use our own OpenAI key directly instead of the Vibecode proxy.
if (env.OPEN_AI_APIKEY) configureProxy({ excludeDomains: ["api.openai.com"] });
console.log(`[OpenAI] ${env.OPEN_AI_APIKEY ? "own key" : "Vibecode proxy"}`);

const app = new Hono();

// CORS middleware - validates origin against allowlist
const allowed = [
  /^http:\/\/localhost(:\d+)?$/,
  /^http:\/\/127\.0\.0\.1(:\d+)?$/,
  /^https:\/\/[a-z0-9-]+\.dev\.vibecode\.run$/,
  /^https:\/\/[a-z0-9-]+\.vibecode\.run$/,
  /^https:\/\/[a-z0-9-]+\.vibecodeapp\.com$/,
  /^https:\/\/[a-z0-9-]+\.vibecode\.dev$/,
  /^https:\/\/vibecode\.dev$/,
  // Freestyle sandbox provider preview domain (dynamically generated per sandbox+port).
  /^https:\/\/[a-z0-9-]+\.style\.dev$/,
  // Daytona sandbox provider preview domain (dynamically generated per sandbox+port; both shared regions).
  /^https:\/\/\d+-[a-z0-9-]+\.daytonaproxy01\.(net|eu)$/,
];

app.use(
  "*",
  cors({
    origin: (origin) => (origin && allowed.some((re) => re.test(origin)) ? origin : null),
    credentials: true,
  })
);

// Logging
app.use("*", logger());

// Health check endpoint
app.get("/health", (c) => c.json({ status: "ok" }));

// Routes
app.route("/api/sample", sampleRouter);
app.route("/api/council", councilRouter);

const port = Number(process.env.PORT) || 3000;

export default {
  port,
  fetch: app.fetch,
};
