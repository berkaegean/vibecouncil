import { LinearGradient } from "expo-linear-gradient";
import * as Sharing from "expo-sharing";
import React, { forwardRef } from "react";
import { Platform, Share, StyleSheet, Text, View } from "react-native";
import { captureRef } from "react-native-view-shot";

import { useI18n } from "@/lib/council/i18n";
import { PersonaGlyph, type PersonaId } from "@/lib/council/personas";
import type { CouncilVote } from "@/lib/council/store";

export type ShareCardData =
  | { kind: "verdict"; verdict: string; symptoms?: string[]; members: PersonaId[] }
  | { kind: "vote"; question: string; votes: CouncilVote[] };

/** Story-sized (9:16) card, rendered off-screen and captured as an image. */
export const ShareCard = forwardRef<View, { data: ShareCardData }>(
  function ShareCard({ data }, ref) {
    const { t, up } = useI18n();
    const yes = data.kind === "vote" ? data.votes.filter((v) => v.vote === "yes").length : 0;
    const members = data.kind === "vote" ? data.votes.map((v) => v.persona) : data.members;

    return (
      <View ref={ref} collapsable={false} style={styles.card}>
        <LinearGradient
          colors={["#07050F", "#1A0E3D", "#3A1A80", "#140B2E"]}
          locations={[0, 0.35, 0.72, 1]}
          style={StyleSheet.absoluteFill}
        />
        <Text style={styles.brand}>
          Vibe<Text style={{ fontWeight: "600" }}>Council</Text>
        </Text>

        <View style={styles.body}>
          <View style={styles.faces}>
            {members.map((id, i) => (
              <View key={id} style={[styles.face, { marginLeft: i === 0 ? 0 : members.length > 4 ? -10 : -12 }]}>
                <PersonaGlyph persona={id} size={members.length > 4 ? 40 : 52} />
              </View>
            ))}
          </View>

          {data.kind === "verdict" ? (
            <>
              <Text style={styles.eyebrow}>{up(t("verdictLabel"))}</Text>
              <Text
                style={[styles.ruling, rulingSize(data.verdict)]}
              >
                {data.verdict}
              </Text>
              {data.symptoms?.length ? (
                <Text style={styles.symptoms} numberOfLines={2} adjustsFontSizeToFit minimumFontScale={0.7}>
                  {data.symptoms.join("  ·  ")}
                </Text>
              ) : null}
            </>
          ) : (
            <>
              <Text style={styles.eyebrow}>{up(t("voteLabel"))}</Text>
              <Text style={styles.question} numberOfLines={6} adjustsFontSizeToFit minimumFontScale={0.6}>
                {data.question}
              </Text>
              <Text style={styles.big}>
                {yes}
                <Text style={styles.bigDim}> {t("voteYes")}</Text>
                {"  ·  "}
                {data.votes.length - yes}
                <Text style={styles.bigDim}> {t("voteNo")}</Text>
              </Text>
            </>
          )}
        </View>

        <Text style={styles.footer}>{t("shareCta")}</Text>
      </View>
    );
  },
);

/** Long rulings shrink so the whole verdict stays on the card. */
function rulingSize(text: string) {
  // Fit ~n chars into a ~300x280pt box (serif glyphs ≈ 0.55em wide, 1.34 line height).
  const n = Math.max(text.length, 1);
  const fontSize = Math.max(15, Math.min(27, Math.floor(Math.sqrt((300 * 280) / (n * 0.55 * 1.34)))));
  return { fontSize, lineHeight: Math.round(fontSize * 1.34) };
}

/** Captures the card and opens the share sheet; falls back to text sharing. */
export async function shareCardImage(view: View | null, fallbackText: string) {
  try {
    if (!view || Platform.OS === "web" || !(await Sharing.isAvailableAsync())) throw new Error("no image share");
    const uri = await captureRef(view, { format: "png", quality: 1, width: 1080, height: 1920 });
    await Sharing.shareAsync(uri, { mimeType: "image/png", UTI: "public.png" });
  } catch {
    await Share.share({ message: fallbackText }).catch(() => undefined);
  }
}

const styles = StyleSheet.create({
  card: {
    width: 360,
    height: 640,
    overflow: "hidden",
    paddingHorizontal: 30,
    paddingTop: 56,
    paddingBottom: 40,
    alignItems: "center",
  },
  brand: { color: "#FFFFFF", fontSize: 22, fontWeight: "200", letterSpacing: -0.8 },
  body: { flex: 1, alignSelf: "stretch", alignItems: "center", justifyContent: "center", paddingVertical: 16 },
  faces: { flexDirection: "row", marginBottom: 24 },
  face: {
    borderRadius: 30,
    borderWidth: 2,
    borderColor: "rgba(210,195,255,0.8)",
    backgroundColor: "#160D33",
  },
  eyebrow: { color: "rgba(220,210,255,0.62)", fontSize: 11, letterSpacing: 3.4 },
  big: {
    color: "#FFFFFF",
    fontSize: 40,
    fontWeight: "200",
    letterSpacing: -1.4,
    marginTop: 12,
    textAlign: "center",
  },
  ruling: {
    color: "#FFFFFF",
    fontSize: 27,
    lineHeight: 37,
    fontWeight: "300",
    letterSpacing: -0.6,
    marginTop: 14,
    textAlign: "center",
  },
  symptoms: {
    color: "#C9B8FF",
    fontSize: 14,
    fontWeight: "700",
    letterSpacing: 1.4,
    textAlign: "center",
    marginTop: 22,
  },
  bigDim: { fontSize: 20, color: "#B7A5FF" },
  question: {
    color: "#FFFFFF",
    fontSize: 22,
    fontWeight: "500",
    lineHeight: 29,
    textAlign: "center",
    marginTop: 14,
  },
  footer: { color: "rgba(220,210,255,0.55)", fontSize: 12, letterSpacing: 1.2 },
});
