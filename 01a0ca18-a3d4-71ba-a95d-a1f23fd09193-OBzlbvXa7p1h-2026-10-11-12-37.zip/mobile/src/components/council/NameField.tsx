import { User } from "lucide-react-native";
import React from "react";
import { TextInput, View } from "react-native";

import { useI18n } from "@/lib/council/i18n";
import { useTheme } from "@/lib/council/useTheme";

export function NameField({
  value,
  onChange,
}: {
  value: string;
  onChange: (name: string) => void;
}) {
  const theme = useTheme();
  const { t } = useI18n();
  return (
    <View className="flex-row items-center px-5 py-4">
      <User size={18} color={theme.accent} strokeWidth={1.9} />
      <TextInput
        value={value}
        onChangeText={onChange}
        placeholder={t("namePlaceholder")}
        placeholderTextColor={theme.textFaint}
        maxLength={40}
        autoCapitalize="words"
        autoCorrect={false}
        returnKeyType="done"
        testID="name-input"
        style={{
          flex: 1,
          marginLeft: 12,
          color: theme.text,
          fontSize: 16.5,
          paddingVertical: 2,
        }}
      />
    </View>
  );
}
