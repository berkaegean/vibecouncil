import DateTimePicker, { type DateTimePickerEvent } from "@react-native-community/datetimepicker";
import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";
import { Bell, Brain, ChevronRight, Clock, X } from "lucide-react-native";
import React, { useState } from "react";
import { Alert, Platform, Pressable, StyleSheet, Switch, Text, View } from "react-native";
import Animated, { FadeIn, FadeOut, LinearTransition } from "react-native-reanimated";

import { LOCALE_TAG, useI18n } from "@/lib/council/i18n";
import { disableDailyReminder, enableDailyReminder } from "@/lib/council/reminder";
import { useCouncilStore } from "@/lib/council/store";
import { alpha } from "@/lib/council/theme";
import { useTheme } from "@/lib/council/useTheme";

import { Glass } from "./Glass";

const timeToDate = (time: string): Date => {
  const [h = 9, m = 0] = time.split(":").map(Number);
  const d = new Date();
  d.setHours(h, m, 0, 0);
  return d;
};
const pad = (n: number) => String(n).padStart(2, "0");

export function ReminderRow() {
  const theme = useTheme();
  const { t, lang } = useI18n();
  const on = useCouncilStore((s) => s.dailyReminder);
  const setOn = useCouncilStore((s) => s.setDailyReminder);
  const time = useCouncilStore((s) => s.reminderTime);
  const setTime = useCouncilStore((s) => s.setReminderTime);
  const [pending, setPending] = useState<boolean>(false);
  const [androidOpen, setAndroidOpen] = useState<boolean>(false);

  const onPickTime = async (e: DateTimePickerEvent, picked?: Date) => {
    if (Platform.OS === "android") setAndroidOpen(false);
    if (e.type !== "set" || !picked) return;
    const next = `${pad(picked.getHours())}:${pad(picked.getMinutes())}`;
    if (next === time) return;
    setTime(next);
    // Reschedule right away so the new time takes effect today.
    if (on) setOn(await enableDailyReminder(next).catch(() => false));
  };

  const toggle = async (next: boolean) => {
    if (pending) return;
    setPending(true);
    if (Platform.OS !== "web") Haptics.selectionAsync();
    try {
      if (next) setOn(await enableDailyReminder(time));
      else {
        await disableDailyReminder();
        setOn(false);
      }
    } catch {
      setOn(false);
    } finally {
      setPending(false);
    }
  };

  return (
    <Glass radius={26} intensity={40}>
      <View className="flex-row items-center px-5 py-4">
        <IconDot>
          <Bell size={18} color={theme.accent} strokeWidth={1.9} />
        </IconDot>
        <View className="ml-3.5 flex-1">
          <Text style={{ color: theme.text, fontSize: 16, fontWeight: "600", letterSpacing: -0.3 }}>
            {t("reminderDaily")}
          </Text>
          <Text style={{ color: theme.textDim, fontSize: 13, marginTop: 2 }}>
            {t("reminderSub", { time })}
          </Text>
        </View>
        <Switch
          value={on}
          onValueChange={toggle}
          disabled={pending}
          trackColor={{ true: theme.accent }}
          testID="daily-reminder-switch"
        />
      </View>
      {on ? (
        <Animated.View entering={FadeIn.duration(200)}>
          <View style={{ height: StyleSheet.hairlineWidth, backgroundColor: theme.hairline, marginLeft: 20 }} />
          <View className="flex-row items-center px-5 py-3" style={{ minHeight: 56 }} testID="reminder-time-row">
            <Clock size={18} color={theme.accent} strokeWidth={1.9} />
            <Text style={{ color: theme.text, fontSize: 16, marginLeft: 12, flex: 1 }}>{t("reminderTimeLabel")}</Text>
            {Platform.OS === "ios" ? (
              <DateTimePicker
                value={timeToDate(time)}
                mode="time"
                display="compact"
                accentColor={theme.accent}
                themeVariant={theme.blurTint}
                locale={LOCALE_TAG[lang]}
                onChange={onPickTime}
              />
            ) : (
              <Pressable onPress={() => setAndroidOpen(true)} className="active:opacity-60">
                <Text style={{ color: theme.accent, fontSize: 16, fontWeight: "600" }}>{time}</Text>
              </Pressable>
            )}
          </View>
          {Platform.OS === "android" && androidOpen ? (
            <DateTimePicker value={timeToDate(time)} mode="time" is24Hour onChange={onPickTime} />
          ) : null}
        </Animated.View>
      ) : null}
    </Glass>
  );
}

/** Settings entry: memory count, opens the full memory screen. */
export function MemoryRow() {
  const theme = useTheme();
  const { t } = useI18n();
  const router = useRouter();
  const count = useCouncilStore((s) => s.memories.length);

  return (
    <Pressable
      onPress={() => {
        if (Platform.OS !== "web") Haptics.selectionAsync();
        router.push("/memory");
      }}
      className="active:opacity-70"
      testID="memory-row"
    >
      <Glass radius={26} intensity={40}>
        <View className="flex-row items-center px-5 py-4">
          <IconDot>
            <Brain size={18} color={theme.accent} strokeWidth={1.9} />
          </IconDot>
          <View className="ml-3.5 flex-1">
            <Text style={{ color: theme.text, fontSize: 16, fontWeight: "600", letterSpacing: -0.3 }}>
              {t("memorySection")}
            </Text>
            <Text style={{ color: theme.textDim, fontSize: 13, marginTop: 2 }}>
              {count > 0 ? t(count === 1 ? "memoryCountOne" : "memoryCountMany", { n: count }) : t("memoryNone")}
            </Text>
          </View>
          <ChevronRight size={18} color={theme.textFaint} strokeWidth={2} />
        </View>
      </Glass>
    </Pressable>
  );
}

export function MemoryList() {
  const theme = useTheme();
  const { t } = useI18n();
  const memories = useCouncilStore((s) => s.memories);
  const removeMemory = useCouncilStore((s) => s.removeMemory);
  const clearMemories = useCouncilStore((s) => s.clearMemories);

  return (
    <Glass radius={26} intensity={40}>
      <View className="px-5 py-4" testID="memory-list">
        <View className="flex-row items-center">
          <IconDot>
            <Brain size={18} color={theme.accent} strokeWidth={1.9} />
          </IconDot>
          <Text style={{ color: theme.textDim, fontSize: 13, lineHeight: 18, marginLeft: 14, flex: 1 }}>
            {memories.length ? t("memoryHint") : t("memoryEmpty")}
          </Text>
        </View>

        {memories.length ? (
          <View className="mt-3.5" style={{ gap: 8 }}>
            {[...memories].reverse().map((m) => (
              <Animated.View key={m.id} entering={FadeIn} exiting={FadeOut} layout={LinearTransition}>
                <Pressable
                  onPress={() => {
                    if (Platform.OS !== "web") Haptics.selectionAsync();
                    Alert.alert(t("memoryDeleteTitle"), t("memoryDeleteBody"), [
                      { text: t("cancel"), style: "cancel" },
                      { text: t("delete"), style: "destructive", onPress: () => removeMemory(m.id) },
                    ]);
                  }}
                  className="flex-row items-center active:opacity-60"
                  style={{
                    borderRadius: 16,
                    paddingHorizontal: 12,
                    paddingVertical: 9,
                    backgroundColor: alpha(theme.accent, 0.08),
                    borderWidth: StyleSheet.hairlineWidth,
                    borderColor: alpha(theme.accent, 0.22),
                  }}
                  testID="memory-item"
                >
                  <Text style={{ color: theme.text, fontSize: 14, lineHeight: 19, flex: 1 }}>{m.text}</Text>
                  <X size={14} color={theme.textFaint} strokeWidth={2.2} />
                </Pressable>
              </Animated.View>
            ))}
            <Pressable
              onPress={() => {
                if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
                Alert.alert(t("memoryClearTitle"), t("memoryClearBody"), [
                  { text: t("cancel"), style: "cancel" },
                  { text: t("memoryClear"), style: "destructive", onPress: clearMemories },
                ]);
              }} className="mt-1 self-start active:opacity-60" testID="memory-clear">
              <Text style={{ color: theme.danger, fontSize: 13.5, fontWeight: "600" }}>{t("memoryClear")}</Text>
            </Pressable>
          </View>
        ) : null}
      </View>
    </Glass>
  );
}

function IconDot({ children }: { children: React.ReactNode }) {
  const theme = useTheme();
  return (
    <View
      style={{
        width: 40,
        height: 40,
        borderRadius: 20,
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: alpha(theme.accent, 0.12),
        borderWidth: StyleSheet.hairlineWidth,
        borderColor: alpha(theme.accent, 0.3),
      }}
    >
      {children}
    </View>
  );
}
