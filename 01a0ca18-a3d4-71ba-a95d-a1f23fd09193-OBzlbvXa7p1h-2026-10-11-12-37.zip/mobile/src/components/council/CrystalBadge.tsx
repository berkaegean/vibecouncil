import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";
import { Gem } from "lucide-react-native";
import React from "react";
import { Platform, Pressable, Text, View } from "react-native";

import { useCouncilStore } from "@/lib/council/store";
import { alpha } from "@/lib/council/theme";
import { useTheme } from "@/lib/council/useTheme";

import { Glass } from "./Glass";

export function CrystalBadge() {
  const crystals = useCouncilStore((s) => s.crystals);
  const router = useRouter();
  const theme = useTheme();

  const empty = crystals <= 0;
  const color = empty ? theme.danger : theme.accent;

  return (
    <Pressable
      onPress={() => {
        if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
        router.push("/paywall");
      }}
      className="active:opacity-60"
    >
      <Glass radius={999} intensity={34} tintColor={empty ? alpha(theme.danger, 0.1) : undefined}>
        <View className="flex-row items-center px-3 py-1.5">
          <Gem size={13} color={color} strokeWidth={1.75} />
          <Text
            style={{
              color,
              fontSize: 14,
              fontWeight: "600",
              marginLeft: 5,
              letterSpacing: 0.2,
            }}
          >
            {crystals}
          </Text>
        </View>
      </Glass>
    </Pressable>
  );
}
