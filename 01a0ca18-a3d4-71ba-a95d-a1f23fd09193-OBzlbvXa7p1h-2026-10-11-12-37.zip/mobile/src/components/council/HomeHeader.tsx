import { useQuery } from "@tanstack/react-query";
import { LinearGradient } from "expo-linear-gradient";
import { ArrowRight, UsersRound } from "lucide-react-native";
import React from "react";
import { Pressable, ScrollView, Text, View } from "react-native";
import Animated, { FadeIn } from "react-native-reanimated";

import { sunSign, useI18n, type TKey } from "@/lib/council/i18n";
import {
  PERSONA_LIST,
  PersonaGlyph,
  type PersonaId,
} from "@/lib/council/personas";
import { councilApi } from "@/lib/council/api";
import { moonPhase } from "@/lib/council/moon";
import { memoryTexts, useCouncilStore, type DailyMessage } from "@/lib/council/store";
import { alpha } from "@/lib/council/theme";
import { useTheme } from "@/lib/council/useTheme";

import { Glass } from "./Glass";
import { MoonGlyph } from "./MoonGlyph";

type Preset = { key: string; title: TKey; sub: TKey; members: PersonaId[] };

const PRESETS: Preset[] = [
  {
    key: "outfit",
    title: "presetOutfit",
    sub: "presetOutfitSub",
    members: ["Nyx", "Momus", "Peitho"],
  },
  {
    key: "text",
    title: "presetText",
    sub: "presetTextSub",
    members: ["Hecate", "Metis", "Nemesis"],
  },
  {
    key: "cosmic",
    title: "presetCosmic",
    sub: "presetCosmicSub",
    members: ["Astraea", "Harmonia"],
  },
  {
    key: "rizz",
    title: "presetRizz",
    sub: "presetRizzSub",
    members: ["Peitho", "Metis", "Momus", "Harmonia"],
  },
];

const todayKey = (): string => {
  const d = new Date();
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
};

/** Today's personal message from one persona; fetched once per day, cached on device. */
function useDailyMessage(): DailyMessage | undefined {
  const lang = useCouncilStore((s) => s.language);
  const hydrated = useCouncilStore((s) => s.hydrated);
  const date = todayKey();
  const { data } = useQuery({
    queryKey: ["daily", date, lang],
    enabled: hydrated,
    staleTime: Infinity,
    retry: 1,
    queryFn: async (): Promise<DailyMessage> => {
      const { daily, birth, setDaily } = useCouncilStore.getState();
      if (daily?.date === date && daily.lang === lang) return daily;
      const res = await councilApi.daily({
        date,
        lang,
        birth: birth ?? undefined,
        memories: memoryTexts(),
      });
      const next: DailyMessage = { date, lang, persona: res.persona, message: res.message };
      setDaily(next);
      return next;
    },
  });
  return data;
}

/** Stable per-day number so the daily card doesn't change between opens. */
const daySeed = (): number => {
  const d = new Date();
  return d.getFullYear() * 372 + d.getMonth() * 31 + d.getDate();
};

export function HomeHeader({
  onSummon,
  onPreset,
  onPersona,
  onGrand,
  hasThreads,
}: {
  onSummon: () => void;
  onPreset: (members: PersonaId[]) => void;
  onPersona: (id: PersonaId) => void;
  onGrand: () => void;
  hasThreads: boolean;
}) {
  const theme = useTheme();
  const { t, up, lang, persona } = useI18n();
  const birth = useCouncilStore((s) => s.birth);

  const seed = daySeed();
  const moon = moonPhase();
  const dailyMsg = useDailyMessage();
  const daily = dailyMsg?.message ?? t(`daily${seed % 7}` as TKey);
  const hello = birth?.name?.trim()
    ? t("homeHelloName", { name: birth.name.trim() })
    : birth
    ? t("homeHello", { sign: sunSign(birth.date, lang) })
    : t("homeHelloNoSign");

  return (
    <View>
      {/* Daily energy hero */}
      <Animated.View entering={FadeIn.duration(220)}>
        <View style={{ borderRadius: 30, overflow: "hidden" }}>
          <LinearGradient
            colors={["#7B61FF", "#8A2BE2", "#B06CFF"]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={{ padding: 22 }}
          >
            <View className="flex-row items-start justify-between">
              <View className="flex-1 pr-3">
                <Text
                  style={{
                    color: "rgba(255,255,255,0.72)",
                    fontSize: 10.5,
                    letterSpacing: 2.8,
                  }}
                >
                  {up(t("homeEnergy"))}
                </Text>
                <Text
                  style={{
                    color: "#FFFFFF",
                    fontSize: 26,
                    fontWeight: "300",
                    letterSpacing: -0.8,
                    marginTop: 6,
                  }}
                >
                  {hello}
                </Text>
                {dailyMsg ? (
                  <Pressable
                    onPress={() => onPersona(dailyMsg.persona)}
                    className="mt-3 flex-row items-center active:opacity-70"
                    testID="daily-message-from"
                  >
                    <View
                      style={{
                        borderRadius: 12,
                        borderWidth: 1,
                        borderColor: "rgba(255,255,255,0.55)",
                      }}
                    >
                      <PersonaGlyph persona={dailyMsg.persona} size={22} />
                    </View>
                    <Text
                      style={{
                        color: "rgba(255,255,255,0.8)",
                        fontSize: 11.5,
                        fontWeight: "600",
                        letterSpacing: 0.4,
                        marginLeft: 7,
                      }}
                    >
                      {t("dailyFrom", { name: dailyMsg.persona })}
                    </Text>
                  </Pressable>
                ) : null}
                <Animated.Text
                  key={daily}
                  entering={FadeIn.duration(400)}
                  style={{
                    color: "rgba(255,255,255,0.9)",
                    fontSize: 14.5,
                    lineHeight: 21,
                    marginTop: dailyMsg ? 6 : 8,
                  }}
                  testID="daily-message"
                >
                  {daily}
                </Animated.Text>
              </View>
              <View className="items-center" style={{ width: 84 }} testID="moon-phase">
                <View
                  style={{
                    padding: 5,
                    borderRadius: 40,
                    backgroundColor: "rgba(255,255,255,0.12)",
                    borderWidth: 1,
                    borderColor: "rgba(255,255,255,0.3)",
                    shadowColor: "#FFFFFF",
                    shadowOpacity: 0.35,
                    shadowRadius: 14,
                    shadowOffset: { width: 0, height: 0 },
                  }}
                >
                  <MoonGlyph phase={moon.phase} size={58} />
                </View>
                <Text
                  numberOfLines={2}
                  style={{
                    color: "#FFFFFF",
                    fontSize: 12,
                    fontWeight: "600",
                    textAlign: "center",
                    marginTop: 8,
                  }}
                >
                  {t(moon.key)}
                </Text>
                <Text style={{ color: "rgba(255,255,255,0.7)", fontSize: 10.5, marginTop: 1 }}>
                  {t("moonLit", { n: Math.round(moon.illumination * 100) })}
                </Text>
              </View>
            </View>

            <Pressable
              onPress={onSummon}
              className="mt-5 active:opacity-80"
              testID="home-summon-button"
            >
              <View
                className="flex-row items-center justify-center"
                style={{
                  backgroundColor: "#FFFFFF",
                  borderRadius: 999,
                  paddingVertical: 14,
                }}
              >
                <UsersRound size={17} color={theme.accent} strokeWidth={2.2} />
                <Text
                  style={{
                    color: theme.accent,
                    fontSize: 16,
                    fontWeight: "700",
                    marginLeft: 8,
                    letterSpacing: -0.3,
                  }}
                >
                  {t("homeCta")}
                </Text>
              </View>
            </Pressable>
          </LinearGradient>
        </View>
      </Animated.View>

      {/* Grand Council: all eight members, one question */}
      <Animated.View entering={FadeIn.delay(60).duration(220)} className="mt-3">
        <Pressable onPress={onGrand} className="active:opacity-80" testID="grand-council-button">
          <View style={{ borderRadius: 26, overflow: "hidden" }}>
            <LinearGradient
              colors={["#140B2E", "#2A1260", "#3A1A80"]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={{ paddingHorizontal: 18, paddingVertical: 16 }}
            >
              <View className="flex-row items-center">
                <View className="flex-1 pr-3">
                  <Text style={{ color: "#FFFFFF", fontSize: 18, fontWeight: "700", letterSpacing: -0.4 }}>
                    {t("grandTitle")}
                  </Text>
                  <Text style={{ color: "rgba(220,210,255,0.72)", fontSize: 12.5, marginTop: 3 }}>
                    {t("grandSub")}
                  </Text>
                </View>
                <ArrowRight size={18} color="#D9CEFF" strokeWidth={2.2} />
              </View>
              <View className="mt-3 flex-row">
                {PERSONA_LIST.map((p, i) => (
                  <View
                    key={p.id}
                    style={{
                      marginLeft: i === 0 ? 0 : -9,
                      borderRadius: 18,
                      borderWidth: 1.5,
                      borderColor: "#2A1260",
                    }}
                  >
                    <PersonaGlyph persona={p.id} size={32} />
                  </View>
                ))}
              </View>
            </LinearGradient>
          </View>
        </Pressable>
      </Animated.View>

      {/* Quick council presets */}
      <SectionTitle>{up(t("homePresets"))}</SectionTitle>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={{ flexGrow: 0, marginHorizontal: -18 }}
        contentContainerStyle={{ paddingHorizontal: 18, gap: 10 }}
      >
        {PRESETS.map((p) => (
          <Pressable
            key={p.key}
            onPress={() => onPreset(p.members)}
            className="active:opacity-70"
            testID={`preset-${p.key}`}
          >
            <Glass radius={22} intensity={40} style={{ width: 164 }}>
              <View className="px-4 py-4">
                <View className="flex-row">
                  {p.members.map((id, i) => (
                    <View key={id} style={{ marginLeft: i === 0 ? 0 : -8 }}>
                      <PersonaGlyph persona={id} size={30} color={theme.base} />
                    </View>
                  ))}
                </View>
                <Text
                  style={{
                    color: theme.text,
                    fontSize: 15.5,
                    fontWeight: "700",
                    letterSpacing: -0.3,
                    marginTop: 12,
                  }}
                >
                  {t(p.title)}
                </Text>
                <View className="mt-1 flex-row items-center justify-between">
                  <Text
                    style={{ color: theme.textDim, fontSize: 12.5, flex: 1 }}
                    numberOfLines={1}
                  >
                    {t(p.sub)}
                  </Text>
                  <ArrowRight
                    size={14}
                    color={theme.accent}
                    strokeWidth={2.2}
                  />
                </View>
              </View>
            </Glass>
          </Pressable>
        ))}
      </ScrollView>

      {/* Member strip → 1-on-1 DMs */}
      <SectionTitle>{up(t("homeMembers"))}</SectionTitle>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={{ flexGrow: 0, marginHorizontal: -18 }}
        contentContainerStyle={{ paddingHorizontal: 18, gap: 12 }}
      >
        {PERSONA_LIST.map((p) => (
          <Pressable
            key={p.id}
            onPress={() => onPersona(p.id)}
            className="items-center active:opacity-70"
            style={{ width: 70 }}
            testID={`home-persona-${p.id}`}
          >
            <View
              style={{
                padding: 2.5,
                borderRadius: 34,
                borderWidth: 1.5,
                borderColor: alpha(theme.persona[p.id], 0.55),
              }}
            >
              <PersonaGlyph persona={p.id} size={56} />
            </View>
            <Text
              style={{
                color: theme.text,
                fontSize: 12,
                fontWeight: "600",
                marginTop: 6,
              }}
            >
              {p.id}
            </Text>
            <Text
              style={{ color: theme.textFaint, fontSize: 10 }}
              numberOfLines={1}
            >
              {persona(p.id).title}
            </Text>
          </Pressable>
        ))}
      </ScrollView>

      {hasThreads ? <SectionTitle>{up(t("homeRecent"))}</SectionTitle> : null}
    </View>
  );
}

function SectionTitle({ children }: { children: React.ReactNode }) {
  const theme = useTheme();
  return (
    <Text
      style={{
        color: theme.textFaint,
        fontSize: 10.5,
        letterSpacing: 3,
        marginTop: 26,
        marginBottom: 12,
        paddingHorizontal: 4,
      }}
    >
      {children}
    </Text>
  );
}
