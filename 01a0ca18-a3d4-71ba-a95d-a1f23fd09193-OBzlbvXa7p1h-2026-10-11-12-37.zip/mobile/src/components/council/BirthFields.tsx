import DateTimePicker, {
  type DateTimePickerEvent,
} from "@react-native-community/datetimepicker";
import { Calendar, Clock } from "lucide-react-native";
import React, { useState } from "react";
import {
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";

import type { BirthProfile, Language } from "@/lib/council/store";
import { LOCALE_TAG, useI18n } from "@/lib/council/i18n";
import { useTheme } from "@/lib/council/useTheme";

const pad = (n: number) => String(n).padStart(2, "0");

export const toBirth = (d: Date): BirthProfile => ({
  date: `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`,
  time: `${pad(d.getHours())}:${pad(d.getMinutes())}`,
});

export const fromBirth = (b: BirthProfile | null): Date => {
  if (!b) return new Date(2000, 0, 1, 12, 0);
  const [y, m, d] = b.date.split("-").map(Number);
  const [h, min] = b.time.split(":").map(Number);
  return new Date(y!, m! - 1, d!, h!, min!);
};

export const formatBirth = (
  b: BirthProfile,
  lang: Language = "tr",
): string => {
  const [y, m, d] = b.date.split("-");
  const date = lang === "en" ? `${m}/${d}/${y}` : `${d}.${m}.${y}`;
  return `${date} · ${b.time}`;
};

type Mode = "date" | "time";

/** Birth date + time rows. iOS shows compact native pickers inline. */
export function BirthFields({
  value,
  onChange,
}: {
  value: Date;
  onChange: (d: Date) => void;
}) {
  const theme = useTheme();
  const { t, lang } = useI18n();
  const [open, setOpen] = useState<Mode | null>(null);
  const b = toBirth(value);

  const onPick = (mode: Mode) => (e: DateTimePickerEvent, picked?: Date) => {
    if (Platform.OS === "android") setOpen(null);
    if (e.type !== "set" || !picked) return;
    const next = new Date(value);
    if (mode === "date")
      next.setFullYear(
        picked.getFullYear(),
        picked.getMonth(),
        picked.getDate(),
      );
    else next.setHours(picked.getHours(), picked.getMinutes());
    onChange(next);
  };

  const row = (mode: Mode) => {
    const Icon = mode === "date" ? Calendar : Clock;
    const label = mode === "date" ? t("birthDate") : t("birthTime");
    const text =
      mode === "date" ? formatBirth(b, lang).split(" · ")[0] : b.time;

    let control: React.ReactNode;
    if (Platform.OS === "ios") {
      control = (
        <DateTimePicker
          value={value}
          mode={mode}
          display="compact"
          accentColor={theme.accent}
          themeVariant={theme.blurTint}
          locale={LOCALE_TAG[lang]}
          maximumDate={mode === "date" ? new Date() : undefined}
          onChange={onPick(mode)}
        />
      );
    } else if (Platform.OS === "web") {
      control = (
        <TextInput
          defaultValue={mode === "date" ? b.date : b.time}
          placeholder={
            mode === "date" ? t("datePlaceholder") : t("timePlaceholder")
          }
          onEndEditing={(e) => {
            const v = e.nativeEvent.text.trim();
            const ok =
              mode === "date"
                ? /^\d{4}-\d{2}-\d{2}$/.test(v)
                : /^\d{2}:\d{2}$/.test(v);
            if (ok)
              onChange(
                fromBirth(
                  mode === "date" ? { ...b, date: v } : { ...b, time: v },
                ),
              );
          }}
          style={{
            color: theme.text,
            fontSize: 16,
            textAlign: "right",
            minWidth: 110,
          }}
        />
      );
    } else {
      control = (
        <Pressable onPress={() => setOpen(mode)} className="active:opacity-60">
          <Text
            style={{ color: theme.accent, fontSize: 16, fontWeight: "600" }}
          >
            {text}
          </Text>
        </Pressable>
      );
    }

    return (
      <View
        className="flex-row items-center px-5 py-3.5"
        style={{ minHeight: 60 }}
      >
        <Icon size={18} color={theme.accent} strokeWidth={1.9} />
        <Text
          style={{ color: theme.text, fontSize: 16, marginLeft: 12, flex: 1 }}
        >
          {label}
        </Text>
        {control}
      </View>
    );
  };

  return (
    <View>
      {row("date")}
      <View
        style={{
          height: StyleSheet.hairlineWidth,
          backgroundColor: theme.hairline,
          marginLeft: 50,
        }}
      />
      {row("time")}
      {Platform.OS === "android" && open ? (
        <DateTimePicker
          value={value}
          mode={open}
          maximumDate={open === "date" ? new Date() : undefined}
          onChange={onPick(open)}
        />
      ) : null}
    </View>
  );
}
