import React, { useEffect, useState } from "react";
import { KeyboardAvoidingView, Modal, Platform, Pressable, StyleSheet, Text, TextInput, View } from "react-native";

import { useI18n } from "@/lib/council/i18n";
import { useCouncilStore } from "@/lib/council/store";
import { useTheme } from "@/lib/council/useTheme";

/** Small modal for renaming a chat thread. */
export function RenameSheet({
  threadId,
  initial,
  visible,
  onClose,
}: {
  threadId: string;
  initial: string;
  visible: boolean;
  onClose: () => void;
}) {
  const theme = useTheme();
  const { t } = useI18n();
  const patchThread = useCouncilStore((s) => s.patchThread);
  const [value, setValue] = useState<string>(initial);

  useEffect(() => {
    if (visible) setValue(initial);
  }, [visible, initial]);

  const save = () => {
    const title = value.trim();
    if (title) patchThread(threadId, { title: title.slice(0, 60), named: true });
    onClose();
  };

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={{ flex: 1 }}>
        <Pressable
          style={[StyleSheet.absoluteFill, { backgroundColor: "rgba(8,6,14,0.55)" }]}
          onPress={onClose}
        />
        <View className="flex-1 justify-center px-8" pointerEvents="box-none">
          <View
            style={{
              backgroundColor: theme.base,
              borderRadius: 24,
              padding: 20,
              borderWidth: StyleSheet.hairlineWidth,
              borderColor: theme.hairline,
            }}
          >
            <Text style={{ color: theme.text, fontSize: 18, fontWeight: "600", letterSpacing: -0.4 }}>
              {t("renameTitle")}
            </Text>
            <TextInput
              value={value}
              onChangeText={setValue}
              placeholder={t("renamePlaceholder")}
              placeholderTextColor={theme.textFaint}
              autoFocus
              maxLength={60}
              returnKeyType="done"
              onSubmitEditing={save}
              testID="rename-input"
              style={{
                marginTop: 14,
                color: theme.text,
                fontSize: 16,
                paddingHorizontal: 14,
                paddingVertical: 12,
                borderRadius: 14,
                borderWidth: StyleSheet.hairlineWidth,
                borderColor: theme.hairline,
              }}
            />
            <View className="mt-4 flex-row justify-end" style={{ gap: 10 }}>
              <Pressable onPress={onClose} hitSlop={8} className="px-4 py-2.5 active:opacity-60">
                <Text style={{ color: theme.textDim, fontSize: 15, fontWeight: "600" }}>{t("renameCancel")}</Text>
              </Pressable>
              <Pressable
                onPress={save}
                className="rounded-full px-5 py-2.5 active:opacity-70"
                style={{ backgroundColor: theme.accent }}
                testID="rename-save"
              >
                <Text style={{ color: theme.onAccent, fontSize: 15, fontWeight: "700" }}>{t("renameSave")}</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}
