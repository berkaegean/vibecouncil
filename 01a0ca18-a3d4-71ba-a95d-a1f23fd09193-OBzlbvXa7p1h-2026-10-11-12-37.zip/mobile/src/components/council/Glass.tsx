import { BlurView } from "expo-blur";
import React from "react";
import { StyleSheet, View, type ViewStyle } from "react-native";

import { useTheme } from "@/lib/council/useTheme";

type GlassProps = {
  children?: React.ReactNode;
  radius?: number;
  intensity?: number;
  /** Brighter fill for elements that should float above the rest. */
  elevated?: boolean;
  style?: ViewStyle | ViewStyle[];
  tintColor?: string;
};

/**
 * Spatial glass panel: severe background blur over the mesh, a translucent
 * fill, a hairline border (silver in light / iridescent in dark) and a single
 * line of refracted light along the top edge.
 */
export function Glass({
  children,
  radius = 26,
  intensity = 42,
  elevated = false,
  style,
  tintColor,
}: GlassProps) {
  const theme = useTheme();

  return (
    <View
      style={[
        {
          borderRadius: radius,
          overflow: "hidden",
          backgroundColor: elevated ? theme.glassStrong : theme.glass,
        },
        style as ViewStyle,
      ]}
    >
      <BlurView
        intensity={intensity}
        tint={theme.blurTint}
        experimentalBlurMethod="dimezisBlurView"
        style={StyleSheet.absoluteFill}
      />
      {tintColor ? (
        <View style={[StyleSheet.absoluteFill, { backgroundColor: tintColor }]} />
      ) : null}

      {/* Inner light refraction */}
      <View
        pointerEvents="none"
        style={{
          position: "absolute",
          top: 0,
          left: radius * 0.5,
          right: radius * 0.5,
          height: StyleSheet.hairlineWidth,
          backgroundColor: theme.refraction,
        }}
      />
      <View
        pointerEvents="none"
        style={[
          StyleSheet.absoluteFill,
          {
            borderRadius: radius,
            borderWidth: StyleSheet.hairlineWidth,
            borderColor: theme.hairline,
          },
        ]}
      />

      {children}
    </View>
  );
}
