import { BlurView } from "expo-blur";
import { LinearGradient } from "expo-linear-gradient";
import { Gavel, Share2, X } from "lucide-react-native";
import React from "react";
import { Modal, Platform, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import Animated, { FadeIn, FadeInDown, FadeInUp } from "react-native-reanimated";
import { SafeAreaView } from "react-native-safe-area-context";

import { useI18n } from "@/lib/council/i18n";

/** Bright amethyst used for the verdict chrome regardless of theme. */
const AMETHYST = "#A98BFF";
const SERIF = Platform.select({ ios: "Didot", android: "serif", default: "Georgia, serif" });

/** Glowing amethyst pills for the council's diagnosed symptoms. */
export function SymptomPills({ symptoms, delay = 0 }: { symptoms: string[]; delay?: number }) {
  return (
    <View className="flex-row flex-wrap justify-center" style={{ gap: 8 }}>
      {symptoms.map((s, i) => (
        <Animated.View
          key={s}
          entering={FadeInUp.delay(delay + i * 90).duration(320)}
          style={{
            paddingHorizontal: 14,
            paddingVertical: 7,
            borderRadius: 999,
            backgroundColor: "rgba(142,108,255,0.22)",
            borderWidth: 1,
            borderColor: "rgba(190,165,255,0.7)",
            shadowColor: "#9B7BFF",
            shadowOpacity: 0.8,
            shadowRadius: 10,
            shadowOffset: { width: 0, height: 0 },
          }}
        >
          <Text style={{ color: "#E6DCFF", fontSize: 12.5, fontWeight: "700", letterSpacing: 0.4 }}>
            {s}
          </Text>
        </Animated.View>
      ))}
    </View>
  );
}

/** Full-screen "Konsey Kararı": heavy blur + smoky glass card, no scores. */
export function VerdictSheet({
  visible,
  verdict,
  symptoms,
  onClose,
  onShare,
}: {
  visible: boolean;
  verdict: string;
  symptoms: string[];
  onClose: () => void;
  onShare?: () => void;
}) {
  const { t, up } = useI18n();

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose} statusBarTranslucent>
      <BlurView intensity={100} tint="dark" style={StyleSheet.absoluteFill} />
      <View style={[StyleSheet.absoluteFill, { backgroundColor: "rgba(8,6,14,0.55)" }]} />
      <SafeAreaView style={{ flex: 1 }}>
        <Pressable style={StyleSheet.absoluteFill} onPress={onClose} />
        <View className="flex-1 justify-center px-5" pointerEvents="box-none">
          <Animated.View entering={FadeInDown.duration(420)} testID="verdict-sheet">
            <View
              style={{
                borderRadius: 32,
                overflow: "hidden",
                borderWidth: 1,
                borderColor: "rgba(200,180,255,0.22)",
                backgroundColor: "rgba(28,26,34,0.62)",
              }}
            >
              <BlurView intensity={60} tint="dark" style={StyleSheet.absoluteFill} />
              <LinearGradient
                colors={["rgba(169,139,255,0.18)", "rgba(20,18,26,0)", "rgba(169,139,255,0.08)"]}
                style={StyleSheet.absoluteFill}
              />
              <View style={{ height: 1, backgroundColor: "rgba(255,255,255,0.18)" }} />

              <View className="items-center px-7 pb-7 pt-8">
                <View
                  style={{
                    width: 46,
                    height: 46,
                    borderRadius: 23,
                    alignItems: "center",
                    justifyContent: "center",
                    borderWidth: 1,
                    borderColor: "rgba(190,165,255,0.5)",
                    backgroundColor: "rgba(142,108,255,0.14)",
                  }}
                >
                  <Gavel size={20} color={AMETHYST} strokeWidth={1.8} />
                </View>
                <Text style={{ color: AMETHYST, fontSize: 11, letterSpacing: 4, marginTop: 16, fontWeight: "600" }}>
                  {up(t("verdictLabel"))}
                </Text>
                <View style={{ width: 36, height: 1, backgroundColor: "rgba(190,165,255,0.45)", marginVertical: 18 }} />
                <Text style={{ color: "rgba(255,255,255,0.45)", fontSize: 10.5, letterSpacing: 3 }}>
                  {up(t("finalVerdict"))}
                </Text>
                <ScrollView style={{ maxHeight: 300, alignSelf: "stretch" }} showsVerticalScrollIndicator={false}>
                <Animated.Text
                  entering={FadeIn.delay(200).duration(600)}
                  style={{
                    color: "#F7F4FF",
                    fontFamily: SERIF,
                    fontSize: 22,
                    lineHeight: 31,
                    textAlign: "center",
                    marginTop: 12,
                    letterSpacing: -0.3,
                  }}
                >
                  {verdict}
                </Animated.Text>
                </ScrollView>

                {symptoms.length > 0 ? (
                  <View className="mt-7 items-center" style={{ alignSelf: "stretch" }}>
                    <Text style={{ color: "rgba(255,255,255,0.45)", fontSize: 10.5, letterSpacing: 3, marginBottom: 12 }}>
                      {up(t("detectedSymptoms"))}
                    </Text>
                    <SymptomPills symptoms={symptoms} delay={500} />
                  </View>
                ) : null}

                <View className="mt-8 flex-row" style={{ gap: 10 }}>
                  {onShare ? (
                    <Pressable
                      onPress={onShare}
                      className="flex-row items-center active:opacity-70"
                      style={{ paddingHorizontal: 18, height: 42, borderRadius: 21, backgroundColor: "#8E6CFF" }}
                      testID="verdict-sheet-share"
                    >
                      <Share2 size={15} color="#fff" />
                      <Text style={{ color: "#fff", fontWeight: "700", marginLeft: 8 }}>{t("verdictShare")}</Text>
                    </Pressable>
                  ) : null}
                  <Pressable
                    onPress={onClose}
                    className="flex-row items-center active:opacity-70"
                    style={{
                      paddingHorizontal: 18,
                      height: 42,
                      borderRadius: 21,
                      borderWidth: 1,
                      borderColor: "rgba(255,255,255,0.18)",
                    }}
                    testID="verdict-sheet-close"
                  >
                    <X size={15} color="#fff" />
                    <Text style={{ color: "#fff", fontWeight: "600", marginLeft: 6 }}>{t("verdictClose")}</Text>
                  </Pressable>
                </View>
              </View>
            </View>
          </Animated.View>
        </View>
      </SafeAreaView>
    </Modal>
  );
}
