import React, { useEffect } from "react";
import { Text, View } from "react-native";
import Animated, {
  Easing,
  FadeIn,
  FadeOut,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withRepeat,
  withSequence,
  withTiming,
} from "react-native-reanimated";

import type { PersonaId } from "@/lib/council/personas";
import { useI18n } from "@/lib/council/i18n";
import { useTheme } from "@/lib/council/useTheme";

import { PersonaAvatar } from "./ChatBubble";
import { Glass } from "./Glass";

function Dot({ delay, color }: { delay: number; color: string }) {
  const v = useSharedValue(0.25);

  useEffect(() => {
    v.value = withDelay(
      delay,
      withRepeat(
        withSequence(
          withTiming(1, { duration: 380, easing: Easing.out(Easing.quad) }),
          withTiming(0.25, { duration: 420, easing: Easing.in(Easing.quad) }),
        ),
        -1,
        false,
      ),
    );
  }, [delay, v]);

  const style = useAnimatedStyle(() => ({
    opacity: v.value,
    transform: [{ scale: 0.75 + v.value * 0.35 }],
  }));

  return (
    <Animated.View
      style={[
        {
          width: 6,
          height: 6,
          borderRadius: 3,
          backgroundColor: color,
          marginRight: 4,
        },
        style,
      ]}
    />
  );
}

export function TypingIndicator({ persona }: { persona: PersonaId }) {
  const theme = useTheme();
  const { t } = useI18n();
  const hue = theme.persona[persona];

  return (
    <Animated.View
      entering={FadeIn.duration(220)}
      exiting={FadeOut.duration(160)}
      className="mb-3 flex-row items-center"
    >
      <PersonaAvatar persona={persona} size={30} />
      <Glass radius={18} intensity={28} style={{ marginLeft: 10 }}>
        <View className="flex-row items-center px-3.5 py-2.5">
          <Dot delay={0} color={hue} />
          <Dot delay={140} color={hue} />
          <Dot delay={280} color={hue} />
          <Text style={{ color: theme.textDim, fontSize: 12.5, marginLeft: 6 }}>
            {t("typing", { name: persona })}
          </Text>
        </View>
      </Glass>
    </Animated.View>
  );
}
