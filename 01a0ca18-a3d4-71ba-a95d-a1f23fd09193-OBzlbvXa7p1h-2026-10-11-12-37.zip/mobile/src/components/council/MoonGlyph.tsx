import React from "react";
import Svg, { Circle, Defs, Path, RadialGradient, Stop } from "react-native-svg";

/** Draws the lit part of the moon for a phase in [0, 1). */
export function MoonGlyph({ phase, size = 48 }: { phase: number; size?: number }) {
  const r = size / 2;
  const waxing = phase < 0.5;
  const crescent = phase < 0.25 || phase > 0.75;
  // Terminator is a half-ellipse whose width follows the phase.
  const rx = Math.max(0.01, r * Math.abs(Math.cos(2 * Math.PI * phase)));
  const outer = waxing ? 1 : 0;
  const inner = crescent ? (waxing ? 0 : 1) : waxing ? 1 : 0;
  const lit = `M ${r} 0 A ${r} ${r} 0 0 ${outer} ${r} ${size} A ${rx} ${r} 0 0 ${inner} ${r} 0 Z`;

  return (
    <Svg width={size} height={size}>
      <Defs>
        <RadialGradient id="moonLit" cx="40%" cy="35%" r="75%">
          <Stop offset="0" stopColor="#FFFFFF" />
          <Stop offset="1" stopColor="#E4DAFF" />
        </RadialGradient>
      </Defs>
      <Circle cx={r} cy={r} r={r} fill="rgba(20,8,60,0.38)" />
      {phase > 0.005 && phase < 0.995 ? <Path d={lit} fill="url(#moonLit)" /> : null}
      <Circle cx={r} cy={r} r={r - 0.5} fill="none" stroke="rgba(255,255,255,0.45)" strokeWidth={1} />
    </Svg>
  );
}
