import React from "react";
import { useReanimatedKeyboardAnimation } from "react-native-keyboard-controller";
import Animated, { useAnimatedStyle } from "react-native-reanimated";
import { useSafeAreaInsets } from "react-native-safe-area-context";

/**
 * Lifts its content above the keyboard using the keyboard height directly.
 * Unlike KeyboardAvoidingView it never measures its own frame, so it can't
 * pick up a bogus offset while the screen is still sliding in.
 */
export function KeyboardPadded({ children }: { children: React.ReactNode }) {
  const { height } = useReanimatedKeyboardAnimation();
  const { bottom } = useSafeAreaInsets();
  const style = useAnimatedStyle(() => ({
    // height is negative while the keyboard is open; the composer already
    // pads for the home indicator, so don't count that twice.
    paddingBottom: Math.max(0, -height.value - bottom),
  }));
  return <Animated.View style={[{ flex: 1 }, style]}>{children}</Animated.View>;
}
