import { usePathname } from "expo-router";
import React, { useMemo } from "react";
import { StyleSheet, useWindowDimensions, View } from "react-native";
import Animated, {
  Easing,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withTiming,
} from "react-native-reanimated";

import { useTheme } from "@/lib/council/useTheme";

/**
 * One node of the mesh: a very large, very diffuse field of colour built from
 * concentric rings. No blur shader needed, so it renders identically on iOS,
 * Android and web — and at this scale the rings read as a soft gradient wash
 * rather than as a visible circle.
 */
// Fewer rings = far less overdraw for a field that animates every frame on
// every screen for the whole time the app is open — this was the main driver
// of GPU heat/battery drain. 8 rings still reads as a soft gradient at this scale.
function MeshNode({ size, color, rings = 8 }: { size: number; color: string; rings?: number }) {
  const layers = useMemo(
    () =>
      Array.from({ length: rings }, (_, i) => {
        const t = (i + 1) / rings; // 0 -> centre, 1 -> outer edge
        return {
          key: i,
          diameter: size * t,
          // Quadratic falloff keeps the edge from ever reading as a hard rim.
          opacity: 0.13 * (1 - t) * (1 - t),
        };
      }).reverse(),
    [rings, size]
  );

  return (
    <View style={{ width: size, height: size, alignItems: "center", justifyContent: "center" }}>
      {layers.map((l) => (
        <View
          key={l.key}
          style={{
            position: "absolute",
            width: l.diameter,
            height: l.diameter,
            borderRadius: l.diameter / 2,
            backgroundColor: color,
            opacity: l.opacity,
          }}
        />
      ))}
    </View>
  );
}

type NodeSpec = {
  color: string;
  size: number;
  x: number;
  y: number;
  dx: number;
  dy: number;
  duration: number;
};

function DriftingNode({ spec, animate }: { spec: NodeSpec; animate: boolean }) {
  const t = useSharedValue(0);

  React.useEffect(() => {
    if (!animate) {
      // Freeze mid-drift instead of animating. Screens stacked with several
      // live BlurViews (chat, paywall, roster) have to re-composite every blur
      // layer on every frame the backdrop changes, which is the main source of
      // GPU heat during long sessions — a static backdrop there lets the blur
      // be computed once and reused.
      t.value = 0.5;
      return;
    }
    t.value = withRepeat(
      withTiming(1, { duration: spec.duration, easing: Easing.inOut(Easing.sin) }),
      -1,
      true
    );
  }, [animate, spec.duration, t]);

  const style = useAnimatedStyle(() => ({
    transform: [{ translateX: t.value * spec.dx }, { translateY: t.value * spec.dy }],
  }));

  return (
    <Animated.View
      style={[
        { position: "absolute", left: spec.x - spec.size / 2, top: spec.y - spec.size / 2 },
        style,
      ]}
      pointerEvents="none"
    >
      <MeshNode size={spec.size} color={spec.color} />
    </Animated.View>
  );
}

/**
 * The slowly shifting mesh gradient field that sits behind every screen.
 * Colours come from the active palette, so it morphs between "Pearlescent" and "Midnight Amethyst" when the theme is toggled.
 */
export function Atmosphere() {
  const theme = useTheme();
  const { width, height } = useWindowDimensions();
  const pathname = usePathname();
  // These screens stack multiple live BlurViews (chat bubbles, paywall,
  // roster cards) on top of the mesh, which is the expensive combination —
  // freeze the drift there instead of on every screen.
  const heavyBlurScreen =
    pathname.startsWith("/council/") ||
    pathname.startsWith("/dm/") ||
    pathname === "/paywall" ||
    pathname === "/roster";

  const specs = useMemo<NodeSpec[]>(() => {
    // Nodes are wider than the screen and heavily overlapped, so the field
    // reads as one continuous gradient rather than four separate shapes.
    const span = Math.max(width, height);
    return [
      {
        color: theme.mesh[0]!,
        size: span * 1.5,
        x: width * 0.18,
        y: height * 0.12,
        dx: width * 0.16,
        dy: height * 0.07,
        duration: 21000,
      },
      {
        color: theme.mesh[1]!,
        size: span * 1.35,
        x: width * 0.92,
        y: height * 0.3,
        dx: -width * 0.18,
        dy: height * 0.1,
        duration: 26000,
      },
      {
        color: theme.mesh[2]!,
        size: span * 1.6,
        x: width * 0.08,
        y: height * 0.78,
        dx: width * 0.2,
        dy: -height * 0.09,
        duration: 31000,
      },
      {
        color: theme.mesh[3]!,
        size: span * 1.25,
        x: width * 0.85,
        y: height * 0.95,
        dx: -width * 0.14,
        dy: -height * 0.12,
        duration: 24000,
      },
    ];
  }, [theme, width, height]);

  return (
    <View style={StyleSheet.absoluteFill} pointerEvents="none">
      <View style={[StyleSheet.absoluteFill, { backgroundColor: theme.base }]} />
      {specs.map((spec, i) => (
        <DriftingNode key={`${theme.name}-${i}`} spec={spec} animate={!heavyBlurScreen} />
      ))}
    </View>
  );
}
