import { Image } from "expo-image";
import { Share2 } from "lucide-react-native";
import React, { useEffect, useRef } from "react";
import { Platform, Pressable, StyleSheet, Text, View } from "react-native";
import Animated, {
  Easing,
  FadeIn,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withTiming,
} from "react-native-reanimated";

import { PERSONAS, PersonaGlyph, type PersonaId } from "@/lib/council/personas";
import type { ChatMessage } from "@/lib/council/store";
import { useI18n } from "@/lib/council/i18n";
import { alpha } from "@/lib/council/theme";
import { useTheme } from "@/lib/council/useTheme";

import { Glass } from "./Glass";
import { ShareCard, shareCardImage } from "./ShareCard";
import { SymptomPills } from "./VerdictSheet";

const VERDICT_SERIF = Platform.select({ ios: "Didot", android: "serif", default: "Georgia, serif" });

export function PersonaAvatar({
  persona,
  size = 34,
}: {
  persona: PersonaId;
  size?: number;
}) {
  const theme = useTheme();
  const hue = theme.persona[persona];

  return (
    <View
      style={{
        width: size,
        height: size,
        borderRadius: size / 2,
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: alpha(hue, 0.1),
        borderWidth: StyleSheet.hairlineWidth,
        borderColor: alpha(hue, 0.3),
      }}
    >
      <PersonaGlyph persona={persona} size={size} />
    </View>
  );
}

export function ChatBubble({
  message,
  index = 0,
  members,
}: {
  message: ChatMessage;
  index?: number;
  /** Council members, shown on the shareable verdict card. */
  members?: PersonaId[];
}) {
  const theme = useTheme();
  const { up } = useI18n();

  if (message.kind === "verdict") {
    return <VerdictCard message={message} members={members ?? []} />;
  }
  if (message.kind === "vote") {
    return <VoteCard message={message} />;
  }

  if (message.kind === "user") {
    return (
      <Animated.View
        entering={FadeIn.duration(220).delay(Math.min(index, 6) * 24)}
        className="mb-3 items-end pl-14"
      >
        {message.imageUri ? (
          <Image
            source={{ uri: message.imageUri }}
            style={{
              width: 208,
              height: 268,
              borderRadius: 22,
              marginBottom: message.text ? 6 : 0,
              borderWidth: StyleSheet.hairlineWidth,
              borderColor: theme.hairline,
            }}
            contentFit="cover"
            transition={220}
          />
        ) : null}

        {message.text ? (
          <View
            style={{
              backgroundColor: theme.accentSoft,
              borderColor: alpha(theme.accent, 0.35),
              borderWidth: StyleSheet.hairlineWidth,
              borderRadius: 22,
              borderBottomRightRadius: 7,
            }}
            className="px-4 py-2.5"
          >
            <Text style={{ color: theme.text, fontSize: 15.5, lineHeight: 21 }}>
              {message.text}
            </Text>
          </View>
        ) : null}
      </Animated.View>
    );
  }

  const persona = message.persona ?? "Nyx";
  const hue = theme.persona[persona];

  return (
    <Animated.View
      entering={FadeIn.duration(220)}
      className="mb-3 flex-row items-end pr-12"
    >
      <PersonaAvatar persona={persona} />
      <View className="ml-2.5 flex-1">
        <Text
          style={{
            color: hue,
            fontSize: 11.5,
            letterSpacing: 0.9,
            fontWeight: "600",
          }}
          className="mb-1 ml-1.5"
        >
          {up(persona)}
        </Text>
        <Glass radius={22} intensity={30} style={{ borderBottomLeftRadius: 7 }}>
          <View className="px-4 py-2.5">
            <Text style={{ color: theme.text, fontSize: 15.5, lineHeight: 22 }}>
              {message.text}
            </Text>
          </View>
        </Glass>
      </View>
    </Animated.View>
  );
}

function ShareButton({ onPress, testID }: { onPress: () => void; testID: string }) {
  const theme = useTheme();
  const { t } = useI18n();
  return (
    <Pressable onPress={onPress} hitSlop={10} className="mt-5 active:opacity-60" testID={testID}>
      <View
        className="flex-row items-center px-4 py-2"
        style={{ borderRadius: 999, backgroundColor: alpha(theme.accent, 0.14) }}
      >
        <Share2 size={14} color={theme.accent} strokeWidth={2.2} />
        <Text style={{ color: theme.accent, fontSize: 13.5, fontWeight: "600", marginLeft: 6 }}>
          {t("voteShare")}
        </Text>
      </View>
    </Pressable>
  );
}

/** Off-screen story card so it can be captured without being visible. */
function Offscreen({ children }: { children: React.ReactNode }) {
  return (
    <View pointerEvents="none" style={{ position: "absolute", left: -10000, top: 0 }}>
      {children}
    </View>
  );
}

function VoteCard({ message }: { message: ChatMessage }) {
  const theme = useTheme();
  const { t, up } = useI18n();
  const cardRef = useRef<View>(null);
  const votes = message.votes ?? [];
  const yes = votes.filter((v) => v.vote === "yes").length;
  const ratio = votes.length ? yes / votes.length : 0;

  const fill = useSharedValue(0);
  useEffect(() => {
    fill.value = withDelay(250, withTiming(ratio, { duration: 900, easing: Easing.out(Easing.cubic) }));
  }, [fill, ratio]);
  const yesBar = useAnimatedStyle(() => ({ width: `${fill.value * 100}%` }));

  return (
    <Animated.View entering={FadeIn.duration(220)} className="mb-3 mt-2 px-2" testID="vote-card">
      <Glass radius={28} intensity={52} elevated tintColor={theme.accentSoft}>
        <View className="px-5 py-6">
          <Text style={{ color: theme.textFaint, fontSize: 10.5, letterSpacing: 2.6, textAlign: "center" }}>
            {up(t("voteLabel"))}
          </Text>
          <Text
            style={{ color: theme.text, fontSize: 18, fontWeight: "600", textAlign: "center", marginTop: 8 }}
          >
            {message.text}
          </Text>

          <View className="mt-4 flex-row items-end justify-between">
            <Text style={{ color: theme.accent, fontSize: 30, fontWeight: "200" }}>
              {yes} <Text style={{ fontSize: 13, fontWeight: "700" }}>{t("voteYesUp")}</Text>
            </Text>
            <Text style={{ color: theme.textDim, fontSize: 30, fontWeight: "200" }}>
              <Text style={{ fontSize: 13, fontWeight: "700" }}>{t("voteNoUp")}</Text> {votes.length - yes}
            </Text>
          </View>
          <View
            style={{
              height: 10,
              borderRadius: 5,
              marginTop: 8,
              overflow: "hidden",
              backgroundColor: alpha(theme.textDim, 0.18),
            }}
          >
            <Animated.View style={[{ height: 10, borderRadius: 5, backgroundColor: theme.accent }, yesBar]} />
          </View>

          <View className="mt-4" style={{ gap: 10 }}>
            {votes.map((v, i) => (
              <Animated.View
                key={v.persona}
                entering={FadeIn.duration(260).delay(300 + i * 180)}
                className="flex-row items-start"
              >
                <PersonaAvatar persona={v.persona} size={30} />
                <View className="ml-2.5 flex-1">
                  <View className="flex-row items-center">
                    <Text style={{ color: theme.persona[v.persona], fontSize: 12, fontWeight: "700" }}>
                      {up(v.persona)}
                    </Text>
                    <View
                      style={{
                        marginLeft: 8,
                        paddingHorizontal: 7,
                        paddingVertical: 1.5,
                        borderRadius: 999,
                        backgroundColor: v.vote === "yes" ? theme.accent : alpha(theme.textDim, 0.2),
                      }}
                    >
                      <Text
                        style={{
                          color: v.vote === "yes" ? theme.onAccent : theme.textDim,
                          fontSize: 10,
                          fontWeight: "800",
                          letterSpacing: 0.8,
                        }}
                      >
                        {t(v.vote === "yes" ? "voteYesUp" : "voteNoUp")}
                      </Text>
                    </View>
                  </View>
                  <Text style={{ color: theme.textDim, fontSize: 14, lineHeight: 19.5, marginTop: 2 }}>
                    {v.reason}
                  </Text>
                </View>
              </Animated.View>
            ))}
          </View>

          <View className="items-center">
            <ShareButton
              testID="vote-share-button"
              onPress={() =>
                shareCardImage(
                  cardRef.current,
                  `${message.text}\n${yes} ${t("voteYes")} · ${votes.length - yes} ${t("voteNo")} — ${t("shareSignature")}`,
                )
              }
            />
          </View>
        </View>
      </Glass>
      <Offscreen>
        <ShareCard ref={cardRef} data={{ kind: "vote", question: message.text, votes }} />
      </Offscreen>
    </Animated.View>
  );
}

function VerdictCard({ message, members }: { message: ChatMessage; members: PersonaId[] }) {
  const theme = useTheme();
  const { t, up } = useI18n();
  const cardRef = useRef<View>(null);
  const symptoms = message.symptoms ?? [];

  return (
    <Animated.View entering={FadeIn.duration(220)} className="mb-3 mt-2 px-2">
      <Glass radius={28} intensity={52} elevated tintColor={theme.accentSoft}>
        <View className="items-center px-6 py-7">
          <Text
            style={{
              color: theme.accent,
              fontSize: 10.5,
              letterSpacing: 3,
              fontWeight: "600",
            }}
          >
            {up(t("verdictLabel"))}
          </Text>
          <Text
            style={{
              color: theme.text,
              fontFamily: VERDICT_SERIF,
              fontSize: 21,
              lineHeight: 29,
              textAlign: "center",
              marginTop: 12,
            }}
          >
            {message.text}
          </Text>
          {symptoms.length > 0 ? (
            <View className="mt-5">
              <SymptomPills symptoms={symptoms} />
            </View>
          ) : null}
          <ShareButton
            testID="verdict-share-button"
            onPress={() =>
              shareCardImage(cardRef.current, `${message.text} — ${t("shareSignature")}`)
            }
          />
        </View>
      </Glass>
      <Offscreen>
        <ShareCard
          ref={cardRef}
          data={{ kind: "verdict", verdict: message.text, symptoms, members }}
        />
      </Offscreen>
    </Animated.View>
  );
}
