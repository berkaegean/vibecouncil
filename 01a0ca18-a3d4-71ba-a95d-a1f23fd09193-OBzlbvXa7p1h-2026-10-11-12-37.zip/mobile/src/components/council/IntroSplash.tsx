import { LinearGradient } from "expo-linear-gradient";
import React, { useEffect, useMemo } from "react";
import { StyleSheet, Text, View } from "react-native";
import Animated, {
  Easing,
  FadeOut,
  interpolate,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withRepeat,
  withSequence,
  withTiming,
  type SharedValue,
} from "react-native-reanimated";

import { useI18n } from "@/lib/council/i18n";
import {
  PERSONA_LIST,
  PersonaGlyph,
  type PersonaId,
} from "@/lib/council/personas";

const RADIUS = 118;
const AVATAR = 44;
const BOX = RADIUS * 2 + AVATAR;
const DURATION = 3000;

/** Deterministic star field so it doesn't jump between renders. */
const STARS = Array.from({ length: 34 }, (_, i) => ({
  x: (i * 73) % 100,
  y: (i * 41 + 13) % 100,
  size: i % 5 === 0 ? 2.4 : 1.4,
  delay: (i * 137) % 1400,
}));

/**
 * Branded 3-second intro. The eight members take their seats one by one
 * around a glowing oracle orb, then the whole council slowly orbits.
 */
export function IntroSplash({ onDone }: { onDone: () => void }) {
  const { t, up } = useI18n();
  const spin = useSharedValue(0);
  const glow = useSharedValue(0);
  const title = useSharedValue(0);
  const progress = useSharedValue(0);

  useEffect(() => {
    spin.value = withRepeat(
      withTiming(1, { duration: 16000, easing: Easing.linear }),
      -1,
    );
    glow.value = withRepeat(
      withSequence(
        withTiming(1, { duration: 1100, easing: Easing.inOut(Easing.sin) }),
        withTiming(0.35, { duration: 1100, easing: Easing.inOut(Easing.sin) }),
      ),
      -1,
    );
    title.value = withDelay(
      1100,
      withTiming(1, { duration: 700, easing: Easing.out(Easing.cubic) }),
    );
    progress.value = withTiming(1, {
      duration: DURATION - 200,
      easing: Easing.inOut(Easing.quad),
    });
    const id = setTimeout(onDone, DURATION);
    return () => clearTimeout(id);
  }, [onDone, glow, progress, spin, title]);

  const ring = useAnimatedStyle(() => ({
    transform: [{ rotate: `${spin.value * 360}deg` }],
  }));
  const halo = useAnimatedStyle(() => ({
    opacity: glow.value,
    transform: [{ scale: interpolate(glow.value, [0.35, 1], [0.9, 1.12]) }],
  }));
  const titleStyle = useAnimatedStyle(() => ({
    opacity: title.value,
    transform: [{ translateY: (1 - title.value) * 14 }],
  }));
  const bar = useAnimatedStyle(() => ({ width: `${progress.value * 100}%` }));

  return (
    <Animated.View
      exiting={FadeOut.duration(450)}
      style={[StyleSheet.absoluteFill, { zIndex: 100 }]}
      testID="intro-splash"
    >
      <LinearGradient
        colors={["#07050F", "#140B2E", "#2A1260", "#140B2E"]}
        locations={[0, 0.4, 0.75, 1]}
        style={StyleSheet.absoluteFill}
      />
      {STARS.map((s, i) => (
        <Star key={i} {...s} />
      ))}

      <View style={[StyleSheet.absoluteFill, styles.center]}>
        <View style={{ width: BOX, height: BOX }}>
          {/* Orbit guides */}
          <View style={[styles.orbit, { inset: AVATAR / 2 }]} />
          <View
            style={[
              styles.orbit,
              { inset: AVATAR / 2 + 34, borderStyle: "dashed", opacity: 0.5 },
            ]}
          />

          {/* Soft glow in the empty center */}
          <View style={[StyleSheet.absoluteFill, styles.center]}>
            <Animated.View style={[styles.halo, halo]} />
          </View>

          {/* The council, seated one by one, orbiting together */}
          <Animated.View style={[StyleSheet.absoluteFill, ring]}>
            {PERSONA_LIST.map((p, i) => (
              <Seat
                key={p.id}
                id={p.id}
                index={i}
                total={PERSONA_LIST.length}
                spin={spin}
              />
            ))}
          </Animated.View>
        </View>

        <Animated.View style={[styles.center, { marginTop: 44 }, titleStyle]}>
          <Text style={styles.eyebrow}>
            {up(t("councilGathering").replace(/…$/, ""))}
          </Text>
          <Text style={styles.title}>
            Vibe<Text style={{ fontWeight: "600" }}>Council</Text>
          </Text>
          <View style={styles.track}>
            <Animated.View style={[styles.fill, bar]} />
          </View>
        </Animated.View>
      </View>
    </Animated.View>
  );
}

function Seat({
  id,
  index,
  total,
  spin,
}: {
  id: PersonaId;
  index: number;
  total: number;
  spin: SharedValue<number>;
}) {
  // Counter-rotate so faces stay upright while the ring turns.
  const counter = useAnimatedStyle(() => ({
    transform: [{ rotate: `${-spin.value * 360}deg` }],
  }));
  const a = (index / total) * Math.PI * 2 - Math.PI / 2;
  const appear = useSharedValue(0);
  useEffect(() => {
    appear.value = withDelay(
      120 + index * 110,
      withTiming(1, { duration: 420, easing: Easing.out(Easing.back(1.6)) }),
    );
  }, [appear, index]);
  const style = useAnimatedStyle(() => ({
    opacity: appear.value,
    transform: [{ scale: 0.4 + appear.value * 0.6 }],
  }));
  return (
    <Animated.View
      style={[
        {
          position: "absolute",
          left: RADIUS + Math.cos(a) * RADIUS,
          top: RADIUS + Math.sin(a) * RADIUS,
        },
        counter,
      ]}
    >
      <Animated.View style={[styles.seat, style]}>
        <PersonaGlyph persona={id} size={AVATAR} />
      </Animated.View>
    </Animated.View>
  );
}

function Star({
  x,
  y,
  size,
  delay,
}: {
  x: number;
  y: number;
  size: number;
  delay: number;
}) {
  const t = useSharedValue(0.2);
  useEffect(() => {
    t.value = withDelay(
      delay,
      withRepeat(withTiming(1, { duration: 1200 }), -1, true),
    );
  }, [t, delay]);
  const style = useAnimatedStyle(() => ({ opacity: t.value }));
  const pos = useMemo(
    () => ({
      left: `${x}%` as const,
      top: `${y}%` as const,
      width: size,
      height: size,
      borderRadius: size,
    }),
    [x, y, size],
  );
  return <Animated.View style={[styles.star, pos, style]} />;
}

const styles = StyleSheet.create({
  center: { alignItems: "center", justifyContent: "center" },
  star: { position: "absolute", backgroundColor: "#FFFFFF" },
  orbit: {
    position: "absolute",
    borderRadius: 999,
    borderWidth: 1,
    borderColor: "rgba(190,170,255,0.28)",
  },
  halo: {
    position: "absolute",
    width: 150,
    height: 150,
    borderRadius: 75,
    backgroundColor: "rgba(123,97,255,0.16)",
    shadowColor: "#8A5CFF",
    shadowOpacity: 0.9,
    shadowRadius: 40,
    shadowOffset: { width: 0, height: 0 },
  },
  seat: {
    borderRadius: AVATAR,
    borderWidth: 1.5,
    borderColor: "rgba(210,195,255,0.75)",
    shadowColor: "#9B7BFF",
    shadowOpacity: 0.8,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 0 },
  },
  eyebrow: {
    color: "rgba(220,210,255,0.62)",
    fontSize: 10.5,
    letterSpacing: 3.6,
  },
  title: {
    color: "#FFFFFF",
    fontSize: 36,
    fontWeight: "200",
    letterSpacing: -1.4,
    marginTop: 6,
  },
  track: {
    width: 120,
    height: 2,
    borderRadius: 1,
    marginTop: 18,
    backgroundColor: "rgba(255,255,255,0.14)",
    overflow: "hidden",
  },
  fill: { height: 2, backgroundColor: "#B7A5FF" },
});
