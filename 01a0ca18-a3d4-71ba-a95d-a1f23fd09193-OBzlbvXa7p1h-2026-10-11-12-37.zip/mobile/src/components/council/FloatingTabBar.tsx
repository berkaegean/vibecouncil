import type { BottomTabBarProps } from "@react-navigation/bottom-tabs";
import * as Haptics from "expo-haptics";
import { MessagesSquare, Settings2, Users } from "lucide-react-native";
import React from "react";
import { Platform, Pressable, StyleSheet, Text, View } from "react-native";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from "react-native-reanimated";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useI18n, type TKey } from "@/lib/council/i18n";
import { alpha } from "@/lib/council/theme";
import { useTheme } from "@/lib/council/useTheme";

import { Glass } from "./Glass";

const ICONS: Record<
  string,
  React.ComponentType<{ size: number; color: string; strokeWidth?: number }>
> = {
  index: MessagesSquare,
  roster: Users,
  settings: Settings2,
};

const LABELS: Record<string, TKey> = {
  index: "tabChats",
  roster: "tabCouncil",
  settings: "tabSettings",
};

/**
 * A translucent glass capsule floating above the bottom edge, blurring the
 * mesh gradient behind it.
 */
export function FloatingTabBar({ state, navigation }: BottomTabBarProps) {
  const theme = useTheme();
  const { t } = useI18n();
  const insets = useSafeAreaInsets();

  return (
    <View
      style={{
        position: "absolute",
        left: 0,
        right: 0,
        bottom: Math.max(insets.bottom, 12),
        alignItems: "center",
      }}
      pointerEvents="box-none"
    >
      <Glass radius={999} intensity={72} elevated>
        <View className="flex-row items-center px-2 py-2">
          {state.routes.map((route, index) => {
            const focused = state.index === index;
            const Icon = ICONS[route.name] ?? MessagesSquare;

            const onPress = () => {
              const event = navigation.emit({
                type: "tabPress",
                target: route.key,
                canPreventDefault: true,
              });
              if (focused || event.defaultPrevented) return;
              if (Platform.OS !== "web")
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
              navigation.navigate(route.name);
            };

            return (
              <TabButton
                key={route.key}
                focused={focused}
                onPress={onPress}
                label={LABELS[route.name] ? t(LABELS[route.name]!) : route.name}
                icon={
                  <Icon
                    size={19}
                    color={focused ? theme.onAccent : theme.textDim}
                    strokeWidth={focused ? 2.3 : 1.9}
                  />
                }
                accent={theme.accent}
                onAccent={theme.onAccent}
                dim={theme.textDim}
                hairline={theme.hairline}
              />
            );
          })}
        </View>
      </Glass>
    </View>
  );
}

function TabButton({
  focused,
  onPress,
  label,
  icon,
  accent,
  onAccent,
  dim,
}: {
  focused: boolean;
  onPress: () => void;
  label: string;
  icon: React.ReactNode;
  accent: string;
  onAccent: string;
  dim: string;
  hairline: string;
}) {
  const progress = useSharedValue(focused ? 1 : 0);

  React.useEffect(() => {
    if (focused) {
      progress.value = withSpring(1, {
        damping: 18,
        stiffness: 190,
        overshootClamping: true,
      });
    } else {
      progress.value = 0;
    }
  }, [focused, progress]);

  const pillStyle = useAnimatedStyle(() => ({
    backgroundColor: accent,
    opacity: progress.value,
    transform: [{ scale: 0.86 + progress.value * 0.14 }],
  }));

  return (
    <Pressable onPress={onPress} className="active:opacity-70">
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          paddingHorizontal: focused ? 16 : 18,
          paddingVertical: 10,
          borderRadius: 999,
          overflow: "hidden",
        }}
      >
        <Animated.View
          style={[
            StyleSheet.absoluteFillObject,
            {
              borderRadius: 999,
              borderWidth: StyleSheet.hairlineWidth,
              borderColor: alpha(accent, 0.4),
            },
            pillStyle,
          ]}
        />
        {icon}
        {focused ? (
          <Text
            style={{
              color: onAccent,
              fontSize: 13,
              fontWeight: "700",
              marginLeft: 6,
              letterSpacing: -0.2,
            }}
          >
            {label}
          </Text>
        ) : (
          <Text
            style={{ color: dim, fontSize: 0 }}
            accessibilityLabel={label}
          />
        )}
      </View>
    </Pressable>
  );
}
