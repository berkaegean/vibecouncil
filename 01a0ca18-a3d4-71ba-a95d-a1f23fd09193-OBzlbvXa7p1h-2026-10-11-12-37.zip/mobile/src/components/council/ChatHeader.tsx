import { useRouter } from "expo-router";
import { ChevronLeft, Pencil } from "lucide-react-native";
import React from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { useTheme } from "@/lib/council/useTheme";

import { Glass } from "./Glass";

export function ChatHeader({
  title,
  subtitle,
  subtitleColor,
  avatar,
  right,
  onTitlePress,
}: {
  title: string;
  subtitle?: string;
  subtitleColor?: string;
  avatar?: React.ReactNode;
  right?: React.ReactNode;
  /** Tapping the title (e.g. to rename the chat). */
  onTitlePress?: () => void;
}) {
  const router = useRouter();
  const theme = useTheme();

  return (
    <View>
      <SafeAreaView edges={["top"]}>
        <View className="flex-row items-center px-3 pb-3 pt-1">
          <Pressable onPress={() => router.back()} hitSlop={12} className="mr-1 active:opacity-50">
            <Glass radius={999} intensity={30}>
              <View className="h-9 w-9 items-center justify-center">
                <ChevronLeft size={20} color={theme.text} strokeWidth={2.2} />
              </View>
            </Glass>
          </Pressable>

          {avatar ? <View className="ml-1.5">{avatar}</View> : null}

          <Pressable
            onPress={onTitlePress}
            disabled={!onTitlePress}
            className="ml-2.5 flex-1 active:opacity-60"
            testID="chat-title"
          >
            <View className="flex-row items-center">
              <Text
                numberOfLines={1}
                style={{ color: theme.text, fontSize: 17, fontWeight: "600", letterSpacing: -0.4, flexShrink: 1 }}
              >
                {title}
              </Text>
              {onTitlePress ? (
                <Pencil size={12} color={theme.textFaint} strokeWidth={2.2} style={{ marginLeft: 6 }} />
              ) : null}
            </View>
            {subtitle ? (
              <Text
                numberOfLines={1}
                style={{
                  color: subtitleColor ?? theme.textDim,
                  fontSize: 12,
                  marginTop: 1,
                  opacity: 0.85,
                }}
              >
                {subtitle}
              </Text>
            ) : null}
          </Pressable>

          {right}
        </View>
      </SafeAreaView>

      <View style={{ height: StyleSheet.hairlineWidth, backgroundColor: theme.hairline }} />
    </View>
  );
}
