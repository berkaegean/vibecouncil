import React from "react";
import { ScrollView, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { ChatHeader } from "@/components/council/ChatHeader";
import { MemoryList } from "@/components/council/MemorySettings";
import { useI18n } from "@/lib/council/i18n";

/** Everything the council remembers about the user; each deletion is confirmed. */
export default function MemoryScreen() {
  const { t } = useI18n();
  return (
    <View style={{ flex: 1 }} testID="memory-screen">
      <ChatHeader title={t("memorySection")} />
      <ScrollView
        contentContainerStyle={{ paddingHorizontal: 18, paddingTop: 8, paddingBottom: 40 }}
        showsVerticalScrollIndicator={false}
      >
        <MemoryList />
      </ScrollView>
      <SafeAreaView edges={["bottom"]} />
    </View>
  );
}
