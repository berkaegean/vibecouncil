import { formatDistanceToNowStrict } from "date-fns";
import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";
import { Plus, Trash2 } from "lucide-react-native";
import React, { useCallback, useRef } from "react";
import ReanimatedSwipeable, {
  type SwipeableMethods,
} from "react-native-gesture-handler/ReanimatedSwipeable";
import {
  Alert,
  FlatList,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import Animated, {
  FadeIn,
  interpolate,
  useAnimatedStyle,
  type SharedValue,
} from "react-native-reanimated";
import { SafeAreaView } from "react-native-safe-area-context";

import { PersonaAvatar } from "@/components/council/ChatBubble";
import { CrystalBadge } from "@/components/council/CrystalBadge";
import { Glass } from "@/components/council/Glass";
import { HomeHeader } from "@/components/council/HomeHeader";
import { useI18n } from "@/lib/council/i18n";
import {
  DEFAULT_COUNCIL,
  PERSONA_LIST,
  PersonaGlyph,
  type PersonaId,
} from "@/lib/council/personas";
import { useCouncilStore, type Thread } from "@/lib/council/store";
import { alpha } from "@/lib/council/theme";
import { useTheme } from "@/lib/council/useTheme";

export default function ChatsScreen() {
  const router = useRouter();
  const theme = useTheme();
  const { t, up } = useI18n();

  const threads = useCouncilStore((s) => s.threads);
  const createThread = useCouncilStore((s) => s.createThread);
  const patchThread = useCouncilStore((s) => s.patchThread);
  const deleteThread = useCouncilStore((s) => s.deleteThread);

  const startCouncil = useCallback(() => {
    if (Platform.OS !== "web")
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    const id = createThread("council");
    router.push({ pathname: "/council/[id]", params: { id } });
  }, [createThread, router]);

  const startPreset = useCallback(
    (members: PersonaId[]) => {
      if (Platform.OS !== "web")
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      const id = createThread("council");
      patchThread(id, { members });
      router.push({ pathname: "/council/[id]", params: { id } });
    },
    [createThread, patchThread, router],
  );

  const startGrand = useCallback(() => {
    if (Platform.OS !== "web")
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    const id = createThread("council");
    patchThread(id, { grand: true, members: PERSONA_LIST.map((p) => p.id) });
    router.push({ pathname: "/council/[id]", params: { id } });
  }, [createThread, patchThread, router]);

  const openPersona = useCallback(
    (persona: PersonaId) => {
      if (Platform.OS !== "web")
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      const existing = useCouncilStore
        .getState()
        .threads.find((t) => t.kind === "dm" && t.persona === persona);
      const id = existing?.id ?? createThread("dm", persona);
      router.push({ pathname: "/dm/[id]", params: { id } });
    },
    [createThread, router],
  );

  const openThread = useCallback(
    (thread: Thread) => {
      if (Platform.OS !== "web")
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      if (thread.kind === "dm") {
        router.push({ pathname: "/dm/[id]", params: { id: thread.id } });
      } else {
        router.push({ pathname: "/council/[id]", params: { id: thread.id } });
      }
    },
    [router],
  );

  const confirmDelete = useCallback(
    (thread: Thread, onCancel?: () => void) => {
      if (Platform.OS !== "web")
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      Alert.alert(
        t("deleteChatTitle"),
        t("deleteChatBody"),
        [
          { text: t("cancel"), style: "cancel", onPress: onCancel },
          {
            text: t("delete"),
            style: "destructive",
            onPress: () => deleteThread(thread.id),
          },
        ],
        { cancelable: true, onDismiss: onCancel },
      );
    },
    [deleteThread, t],
  );

  return (
    <View style={{ flex: 1 }}>
      <SafeAreaView edges={["top"]} style={{ flex: 1 }}>
        <View className="flex-row items-end justify-between px-6 pb-5 pt-2">
          <View className="flex-1">
            <Text
              style={{
                color: theme.textFaint,
                fontSize: 10.5,
                letterSpacing: 3.4,
              }}
            >
              {up(t("chatsEyebrow"))}
            </Text>
            <Text
              style={{
                color: theme.text,
                fontSize: 40,
                fontWeight: "200",
                letterSpacing: -2,
                marginTop: 2,
              }}
            >
              {t("chatsTitle")}
            </Text>
          </View>
          <View className="pb-3">
            <CrystalBadge />
          </View>
        </View>

        <FlatList
          data={threads}
          keyExtractor={(t) => t.id}
          contentContainerStyle={{ paddingHorizontal: 18, paddingBottom: 190 }}
          showsVerticalScrollIndicator={false}
          ListHeaderComponent={
            <HomeHeader
              onSummon={startCouncil}
              onPreset={startPreset}
              onPersona={openPersona}
              onGrand={startGrand}
              hasThreads={threads.length > 0}
            />
          }
          ListEmptyComponent={<EmptyState />}
          renderItem={({ item, index }) => (
            <ThreadRow
              thread={item}
              index={index}
              onPress={() => openThread(item)}
              onDelete={(onCancel) => confirmDelete(item, onCancel)}
            />
          )}
        />
      </SafeAreaView>

      {/* Floating action pill, seated just above the tab capsule */}
      <View
        className="absolute inset-x-0 items-center"
        style={{ bottom: 104 }}
        pointerEvents="box-none"
      >
        <Pressable onPress={startCouncil} className="active:opacity-80">
          <Glass
            radius={999}
            intensity={72}
            elevated
            tintColor={alpha(theme.accent, 0.14)}
          >
            <View className="flex-row items-center px-6 py-3.5">
              <Plus size={18} color={theme.accent} strokeWidth={2.4} />
              <Text
                style={{
                  color: theme.text,
                  fontSize: 16,
                  fontWeight: "600",
                  marginLeft: 8,
                  letterSpacing: -0.3,
                }}
              >
                {t("newCouncil")}
              </Text>
            </View>
          </Glass>
        </Pressable>
      </View>
    </View>
  );
}

function ThreadRow({
  thread,
  index,
  onPress,
  onDelete,
}: {
  thread: Thread;
  index: number;
  onPress: () => void;
  onDelete: (onCancel: () => void) => void;
}) {
  const theme = useTheme();
  const { t, dateLocale } = useI18n();
  const swipeRef = useRef<SwipeableMethods>(null);
  // True while a swipe is in progress or the row is open, so the finger
  // lifting at the end of a swipe never counts as a tap into the chat.
  const swiping = useRef<boolean>(false);
  const settle = useRef<ReturnType<typeof setTimeout> | null>(null);
  const markSwiping = () => {
    if (settle.current) clearTimeout(settle.current);
    swiping.current = true;
  };
  const onRowPress = () => {
    if (swiping.current) {
      swipeRef.current?.close();
      return;
    }
    onPress();
  };
  const last = thread.messages[thread.messages.length - 1];
  const preview =
    last?.kind === "verdict"
      ? last.text
      : last?.text || (last?.imageUri ? t("imageSent") : t("noMessagesYet"));

  const stamp = formatDistanceToNowStrict(new Date(thread.updatedAt), {
    addSuffix: false,
    locale: dateLocale,
  });

  return (
    <Animated.View
      entering={FadeIn.delay(Math.min(index, 8) * 40).duration(220)}
      className="mb-2.5"
    >
      <ReanimatedSwipeable
        ref={swipeRef}
        friction={1.6}
        rightThreshold={48}
        overshootRight={false}
        dragOffsetFromRightEdge={6}
        onSwipeableOpenStartDrag={markSwiping}
        onSwipeableCloseStartDrag={markSwiping}
        onSwipeableWillOpen={markSwiping}
        onSwipeableWillClose={() => {
          settle.current = setTimeout(() => {
            swiping.current = false;
          }, 400);
        }}
        onSwipeableClose={() => {
          settle.current = setTimeout(() => {
            swiping.current = false;
          }, 250);
        }}
        renderRightActions={(progress) => (
          <DeleteAction
            progress={progress}
            onPress={() => onDelete(() => swipeRef.current?.close())}
          />
        )}
      >
        <Pressable
          onPress={onRowPress}
          onLongPress={() => onDelete(() => swipeRef.current?.close())}
          delayLongPress={350}
          className="active:opacity-60"
        >
          <Glass radius={24} intensity={34}>
            <View className="flex-row items-center px-4 py-3.5">
              {thread.kind === "dm" && thread.persona ? (
                <PersonaAvatar persona={thread.persona} size={46} />
              ) : (
                <CouncilCrest members={thread.members} />
              )}

              <View className="ml-3.5 flex-1">
                <View className="flex-row items-center justify-between">
                  <Text
                    numberOfLines={1}
                    style={{
                      color: theme.text,
                      fontSize: 16,
                      fontWeight: "600",
                      letterSpacing: -0.3,
                      flex: 1,
                    }}
                  >
                    {thread.kind === "council" && thread.title === "Yeni Konsey"
                      ? t("newCouncil")
                      : thread.title}
                  </Text>
                  <Text
                    style={{
                      color: theme.textFaint,
                      fontSize: 11.5,
                      marginLeft: 8,
                    }}
                  >
                    {stamp}
                  </Text>
                </View>
                <Text
                  numberOfLines={1}
                  style={{ color: theme.textDim, fontSize: 13.5, marginTop: 3 }}
                >
                  {preview}
                </Text>
              </View>
            </View>
          </Glass>
        </Pressable>
      </ReanimatedSwipeable>
    </Animated.View>
  );
}

/** Four sigils stacked into a 2x2 crest — the group council's face. */
export function CouncilCrest({
  size = 46,
  members = DEFAULT_COUNCIL,
}: {
  size?: number;
  members?: PersonaId[];
}) {
  const theme = useTheme();
  const list = members.slice(0, 4);
  const n = list.length;
  // Portrait size and centre offsets (as fractions of `size`) per member count,
  // placed absolutely so the group always sits dead-centre in the circle.
  const glyph = size * (n === 1 ? 0.7 : n === 2 ? 0.44 : 0.38);
  const d = 0.2;
  const layout: [number, number][] =
    n === 1
      ? [[0, 0]]
      : n === 2
      ? [[-0.13, -0.13], [0.13, 0.13]]
      : n === 3
      ? [[0, -0.18], [-d, 0.14], [d, 0.14]]
      : [[-d, -d], [d, -d], [-d, d], [d, d]];

  return (
    <View
      style={{
        width: size,
        height: size,
        borderRadius: size / 2,
        borderWidth: StyleSheet.hairlineWidth,
        borderColor: alpha(theme.accent, 0.3),
        backgroundColor: alpha(theme.accent, 0.07),
      }}
    >
      {list.map((id, i) => {
        const [x, y] = layout[i]!;
        return (
          <View
            key={id}
            style={{
              position: "absolute",
              left: size / 2 + x * size - glyph / 2,
              top: size / 2 + y * size - glyph / 2,
            }}
          >
            <PersonaGlyph persona={id} size={glyph} color={theme.persona[id]} />
          </View>
        );
      })}
    </View>
  );
}

function EmptyState() {
  const theme = useTheme();
  const { t } = useI18n();

  return (
    <View className="items-center px-8 pt-8">
      <Text
        style={{
          color: theme.text,
          fontSize: 17,
          fontWeight: "500",
          textAlign: "center",
        }}
      >
        {t("emptyTitle")}
      </Text>
      <Text
        style={{
          color: theme.textDim,
          fontSize: 13.5,
          lineHeight: 20,
          textAlign: "center",
          marginTop: 6,
        }}
      >
        {t("emptyBody")}
      </Text>
    </View>
  );
}

/** Red delete pill that fades and scales in as the row is dragged open. */
function DeleteAction({
  progress,
  onPress,
}: {
  progress: SharedValue<number>;
  onPress: () => void;
}) {
  const theme = useTheme();
  const { t } = useI18n();
  const style = useAnimatedStyle(() => ({
    opacity: interpolate(progress.value, [0, 0.15, 1], [0, 0.15, 1], "clamp"),
    transform: [
      { scale: interpolate(progress.value, [0, 1], [0.85, 1], "clamp") },
    ],
  }));
  return (
    <Pressable
      onPress={onPress}
      className="active:opacity-70"
      style={{ width: 88, paddingLeft: 10 }}
      testID="thread-delete-action"
    >
      <Animated.View
        style={[
          {
            flex: 1,
            borderRadius: 24,
            alignItems: "center",
            justifyContent: "center",
            backgroundColor: theme.danger,
          },
          style,
        ]}
      >
        <Trash2 size={20} color="#FFFFFF" strokeWidth={2} />
        <Text
          style={{
            color: "#FFFFFF",
            fontSize: 12.5,
            fontWeight: "600",
            marginTop: 4,
          }}
        >
          {t("delete")}
        </Text>
      </Animated.View>
    </Pressable>
  );
}
