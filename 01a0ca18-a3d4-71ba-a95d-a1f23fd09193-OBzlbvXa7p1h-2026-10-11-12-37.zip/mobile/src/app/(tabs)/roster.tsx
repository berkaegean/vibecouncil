import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";
import { MessageCircle } from "lucide-react-native";
import React, { useCallback } from "react";
import {
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import Animated, {
  Easing,
  FadeIn,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withTiming,
} from "react-native-reanimated";
import { SafeAreaView } from "react-native-safe-area-context";

import { Glass } from "@/components/council/Glass";
import {
  PERSONA_LIST,
  PersonaGlyph,
  type PersonaMeta,
} from "@/lib/council/personas";
import { useI18n } from "@/lib/council/i18n";
import { useCouncilStore } from "@/lib/council/store";
import { alpha } from "@/lib/council/theme";
import { useTheme } from "@/lib/council/useTheme";

export default function RosterScreen() {
  const router = useRouter();
  const theme = useTheme();
  const { t, up } = useI18n();
  const createThread = useCouncilStore((s) => s.createThread);
  const threads = useCouncilStore((s) => s.threads);

  const openDm = useCallback(
    (persona: PersonaMeta) => {
      if (Platform.OS !== "web")
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      // Reuse an existing DM with this persona instead of piling up empty threads.
      const existing = threads.find(
        (t) => t.kind === "dm" && t.persona === persona.id,
      );
      const id = existing?.id ?? createThread("dm", persona.id);
      router.push({ pathname: "/dm/[id]", params: { id } });
    },
    [threads, createThread, router],
  );

  return (
    <SafeAreaView edges={["top"]} style={{ flex: 1 }}>
      <ScrollView
        contentContainerStyle={{ paddingBottom: 130 }}
        showsVerticalScrollIndicator={false}
      >
        <View className="px-6 pb-6 pt-2">
          <Text
            style={{
              color: theme.textFaint,
              fontSize: 10.5,
              letterSpacing: 3.4,
            }}
          >
            {up(t("rosterEyebrow"))}
          </Text>
          <Text
            style={{
              color: theme.text,
              fontSize: 40,
              fontWeight: "200",
              letterSpacing: -2,
              marginTop: 2,
            }}
          >
            {t("rosterTitle")}
          </Text>
          <Text
            style={{
              color: theme.textDim,
              fontSize: 14.5,
              lineHeight: 21,
              marginTop: 8,
            }}
          >
            {t("rosterBody")}
          </Text>
        </View>

        <View className="flex-row flex-wrap px-4">
          {PERSONA_LIST.map((p, i) => (
            <Animated.View
              key={p.id}
              entering={FadeIn.delay(i * 40).duration(220)}
              style={{ width: "50%", padding: 5 }}
            >
              <ProfileCard persona={p} onPress={() => openDm(p)} />
            </Animated.View>
          ))}
        </View>

        <Text
          style={{
            color: theme.textFaint,
            fontSize: 12.5,
            lineHeight: 19,
            textAlign: "center",
            paddingHorizontal: 40,
            marginTop: 18,
          }}
        >
          {t("rosterFooter")}
        </Text>
        <View style={{ height: 1, backgroundColor: alpha(theme.accent, 0) }} />
      </ScrollView>
    </SafeAreaView>
  );
}

function ProfileCard({
  persona,
  onPress,
}: {
  persona: PersonaMeta;
  onPress: () => void;
}) {
  const theme = useTheme();
  const { t, up, persona: copy } = useI18n();
  const hue = theme.persona[persona.id];

  const shimmer = useSharedValue(0);
  React.useEffect(() => {
    shimmer.value = withRepeat(
      withTiming(1, { duration: 4200, easing: Easing.inOut(Easing.sin) }),
      -1,
      true,
    );
  }, [shimmer]);

  const haloStyle = useAnimatedStyle(() => ({
    opacity: 0.1 + shimmer.value * 0.22,
    transform: [{ scale: 1 + shimmer.value * 0.07 }],
  }));

  return (
    <Pressable
      onPress={onPress}
      className="active:opacity-80"
      style={{ flex: 1 }}
    >
      <Glass
        radius={26}
        intensity={44}
        elevated
        tintColor={alpha(hue, 0.05)}
        style={{ flex: 1 }}
      >
        <View
          className="items-center px-3.5 pb-4 pt-5"
          style={{ minHeight: 214 }}
        >
          {/* Sigil with a breathing halo */}
          <View
            style={{
              width: 70,
              height: 70,
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Animated.View
              style={[
                {
                  position: "absolute",
                  width: 70,
                  height: 70,
                  borderRadius: 35,
                  backgroundColor: hue,
                },
                haloStyle,
              ]}
            />
            <View
              style={{
                width: 56,
                height: 56,
                borderRadius: 28,
                alignItems: "center",
                justifyContent: "center",
                backgroundColor: alpha(hue, 0.12),
                borderWidth: StyleSheet.hairlineWidth,
                borderColor: alpha(hue, 0.42),
              }}
            >
              <PersonaGlyph
                persona={persona.id}
                size={56}
                color={alpha(hue, 0.42)}
              />
            </View>
          </View>

          <Text
            style={{
              color: theme.text,
              fontSize: 19,
              fontWeight: "600",
              letterSpacing: -0.5,
              marginTop: 12,
            }}
          >
            {persona.id}
          </Text>
          <Text
            style={{
              color: hue,
              fontSize: 10.5,
              letterSpacing: 1.4,
              marginTop: 3,
              fontWeight: "700",
            }}
          >
            {up(copy(persona.id).title)}
          </Text>
          <Text
            numberOfLines={3}
            style={{
              color: theme.textDim,
              fontSize: 12.5,
              lineHeight: 17,
              marginTop: 8,
              textAlign: "center",
            }}
          >
            {copy(persona.id).tagline}
          </Text>

          <View className="mt-auto flex-row items-center pt-3">
            <MessageCircle size={13} color={hue} strokeWidth={2.2} />
            <Text
              style={{
                color: hue,
                fontSize: 12,
                fontWeight: "600",
                marginLeft: 5,
              }}
            >
              {t("sendMessage")}
            </Text>
          </View>
        </View>
      </Glass>
    </Pressable>
  );
}
