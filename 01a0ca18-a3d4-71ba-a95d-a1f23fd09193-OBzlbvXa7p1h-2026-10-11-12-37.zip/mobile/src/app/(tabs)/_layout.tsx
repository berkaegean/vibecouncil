import { Tabs } from "expo-router";
import React from "react";

import { FloatingTabBar } from "@/components/council/FloatingTabBar";
import { useI18n } from "@/lib/council/i18n";

export default function TabLayout() {
  const { t } = useI18n();
  return (
    <Tabs
      tabBar={(props) => <FloatingTabBar {...props} />}
      screenOptions={{
        headerShown: false,
        sceneStyle: { backgroundColor: "transparent" },
      }}
    >
      <Tabs.Screen name="index" options={{ title: t("tabChats") }} />
      <Tabs.Screen name="roster" options={{ title: t("tabCouncil") }} />
      <Tabs.Screen name="settings" options={{ title: t("tabSettings") }} />
    </Tabs>
  );
}
