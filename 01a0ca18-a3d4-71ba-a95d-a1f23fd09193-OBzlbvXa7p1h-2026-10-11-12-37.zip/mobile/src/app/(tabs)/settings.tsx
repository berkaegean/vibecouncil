import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";
import { Info, Moon, ShoppingBag, Sun, Trash2, Gem } from "lucide-react-native";
import React, { useCallback } from "react";
import {
  Alert,
  Linking,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import Animated, { FadeIn } from "react-native-reanimated";
import { SafeAreaView } from "react-native-safe-area-context";

import {
  BirthFields,
  fromBirth,
  toBirth,
} from "@/components/council/BirthFields";
import { Glass } from "@/components/council/Glass";
import { MemoryRow, ReminderRow } from "@/components/council/MemorySettings";
import { NameField } from "@/components/council/NameField";
import { LANGUAGE_OPTIONS, useI18n } from "@/lib/council/i18n";
import { useCouncilStore, type Language } from "@/lib/council/store";
import { alpha, type ThemeName } from "@/lib/council/theme";
import { useTheme } from "@/lib/council/useTheme";

const TERMS_URL = "https://www.apple.com/legal/internet-services/itunes/dev/stdeula/";
const PRIVACY_URL = "https://www.berkaegean.com/privacy-vibecouncil.html";

const LANGUAGES = LANGUAGE_OPTIONS;

export default function SettingsScreen() {
  const router = useRouter();
  const theme = useTheme();
  const { t, up } = useI18n();

  const crystals = useCouncilStore((s) => s.crystals);
  const threadCount = useCouncilStore((s) => s.threads.length);
  const birth = useCouncilStore((s) => s.birth);
  const setBirth = useCouncilStore((s) => s.setBirth);
  const name = useCouncilStore((s) => s.birth?.name ?? "");
  const setName = useCouncilStore((s) => s.setName);
  const clearHistory = useCouncilStore((s) => s.clearHistory);
  const language = useCouncilStore((s) => s.language);
  const setLanguage = useCouncilStore((s) => s.setLanguage);

  const themeName = useCouncilStore((s) => s.themeName);
  const setThemeName = useCouncilStore((s) => s.setThemeName);

  const onSelectTheme = useCallback(
    (next: ThemeName) => {
      if (next === themeName) return;
      if (Platform.OS !== "web") Haptics.selectionAsync();
      setThemeName(next);
    },
    [themeName, setThemeName],
  );

  const onSelectLanguage = useCallback(
    (next: Language) => {
      if (next === language) return;
      if (Platform.OS !== "web") Haptics.selectionAsync();
      setLanguage(next);
    },
    [language, setLanguage],
  );

  const onClearHistory = useCallback(() => {
    if (threadCount === 0) return;
    if (Platform.OS !== "web")
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    Alert.alert(
      t("clearAllTitle"),
      t(threadCount === 1 ? "clearAllBodyOne" : "clearAllBodyMany", {
        n: threadCount,
      }),
      [
        { text: t("cancel"), style: "cancel" },
        {
          text: t("clearAllConfirm"),
          style: "destructive",
          onPress: clearHistory,
        },
      ],
    );
  }, [threadCount, clearHistory, t]);

  return (
    <SafeAreaView edges={["top"]} style={{ flex: 1 }}>
      <ScrollView
        contentContainerStyle={{ paddingBottom: 130, paddingHorizontal: 18 }}
        showsVerticalScrollIndicator={false}
      >
        <View className="px-3 pb-6 pt-2">
          <Text
            style={{
              color: theme.textFaint,
              fontSize: 10.5,
              letterSpacing: 3.4,
            }}
          >
            {up(t("settingsEyebrow"))}
          </Text>
          <Text
            style={{
              color: theme.text,
              fontSize: 40,
              fontWeight: "200",
              letterSpacing: -2,
              marginTop: 2,
            }}
          >
            {t("settingsTitle")}
          </Text>
        </View>

        {/* Crystal balance */}
        <Animated.View entering={FadeIn.duration(220)}>
          <Glass
            radius={28}
            intensity={50}
            elevated
            tintColor={alpha(theme.accent, 0.06)}
          >
            <View className="px-6 py-6">
              <View className="flex-row items-center justify-between">
                <View>
                  <Text
                    style={{
                      color: theme.textFaint,
                      fontSize: 10.5,
                      letterSpacing: 2.6,
                    }}
                  >
                    {up(t("crystalBalance"))}
                  </Text>
                  <View className="mt-2 flex-row items-center">
                    <Gem size={22} color={theme.accent} strokeWidth={1.75} />
                    <Text
                      style={{
                        color: theme.text,
                        fontSize: 44,
                        fontWeight: "200",
                        letterSpacing: -2.2,
                        marginLeft: 8,
                        lineHeight: 44,
                      }}
                    >
                      {crystals}
                    </Text>
                  </View>
                </View>

                <Pressable
                  onPress={() => {
                    if (Platform.OS !== "web")
                      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
                    router.push("/paywall");
                  }}
                  className="active:opacity-75"
                >
                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      backgroundColor: theme.accent,
                      borderRadius: 999,
                      paddingVertical: 11,
                      paddingHorizontal: 18,
                    }}
                  >
                    <ShoppingBag
                      size={15}
                      color={theme.onAccent}
                      strokeWidth={2.2}
                    />
                    <Text
                      style={{
                        color: theme.onAccent,
                        fontSize: 14.5,
                        fontWeight: "700",
                        marginLeft: 7,
                        letterSpacing: -0.2,
                      }}
                    >
                      {t("store")}
                    </Text>
                  </View>
                </Pressable>
              </View>

              <View
                style={{
                  height: StyleSheet.hairlineWidth,
                  backgroundColor: theme.hairline,
                  marginVertical: 16,
                }}
              />

              <View className="flex-row items-center">
                <Info size={13} color={theme.textDim} />
                <Text
                  style={{ color: theme.textDim, fontSize: 13, marginLeft: 7 }}
                >
                  {t("crystalInfo")}
                </Text>
              </View>
            </View>
          </Glass>
        </Animated.View>

        {/* Profile */}
        <SectionLabel>{t("nameSection")}</SectionLabel>
        <Glass radius={26} intensity={40}>
          <NameField value={name} onChange={setName} />
        </Glass>

        {/* Appearance */}
        <SectionLabel>{t("themeSection")}</SectionLabel>
        <Animated.View entering={FadeIn.delay(20).duration(220)}>
          <Glass radius={26} intensity={40}>
            <View className="flex-row p-1.5" style={{ gap: 6 }}>
              {(["pearlescent", "midnight"] as const).map((value) => {
                const selected = value === themeName;
                const Icon = value === "pearlescent" ? Sun : Moon;
                const color = selected ? theme.onAccent : theme.text;
                return (
                  <Pressable
                    key={value}
                    testID={`theme-${value === "pearlescent" ? "light" : "dark"}`}
                    accessibilityRole="button"
                    accessibilityState={{ selected }}
                    onPress={() => onSelectTheme(value)}
                    className="flex-1 active:opacity-75"
                  >
                    <View
                      style={{
                        flexDirection: "row",
                        alignItems: "center",
                        justifyContent: "center",
                        borderRadius: 999,
                        paddingVertical: 12,
                        backgroundColor: selected
                          ? theme.accent
                          : "transparent",
                      }}
                    >
                      <Icon size={16} color={color} strokeWidth={2} />
                      <Text
                        style={{
                          color,
                          fontSize: 15,
                          fontWeight: selected ? "700" : "500",
                          letterSpacing: -0.2,
                          marginLeft: 7,
                        }}
                      >
                        {t(value === "pearlescent" ? "themeLight" : "themeDark")}
                      </Text>
                    </View>
                  </Pressable>
                );
              })}
            </View>
          </Glass>
        </Animated.View>

        {/* Language */}
        <SectionLabel>{t("languageSection")}</SectionLabel>
        <Animated.View entering={FadeIn.delay(35).duration(220)}>
          <Glass radius={26} intensity={40}>
            <View className="flex-row flex-wrap p-1.5" style={{ gap: 6 }}>
              {LANGUAGES.map((option) => {
                const selected = option.value === language;
                return (
                  <Pressable
                    key={option.value}
                    testID={`language-${option.value}`}
                    accessibilityRole="button"
                    accessibilityState={{ selected }}
                    onPress={() => onSelectLanguage(option.value)}
                    className="active:opacity-75"
                    style={{ width: "48.5%", flexGrow: 1 }}
                  >
                    <View
                      style={{
                        alignItems: "center",
                        justifyContent: "center",
                        borderRadius: 999,
                        paddingVertical: 12,
                        backgroundColor: selected
                          ? theme.accent
                          : "transparent",
                      }}
                    >
                      <Text
                        style={{
                          color: selected ? theme.onAccent : theme.text,
                          fontSize: 15,
                          fontWeight: selected ? "700" : "500",
                          letterSpacing: -0.2,
                        }}
                      >
                        {option.flag} {option.label}
                      </Text>
                    </View>
                  </Pressable>
                );
              })}
            </View>
          </Glass>
        </Animated.View>

        {/* Astrological profile */}
        <SectionLabel>{t("birthChart")}</SectionLabel>
        <Animated.View entering={FadeIn.delay(70).duration(220)}>
          <Glass radius={26} intensity={40}>
            <BirthFields
              value={fromBirth(birth)}
              onChange={(d) => setBirth(toBirth(d))}
            />
          </Glass>
          <Text
            style={{
              color: theme.textFaint,
              fontSize: 12,
              marginTop: 8,
              paddingHorizontal: 12,
            }}
          >
            {t("birthChartNote")}
          </Text>
        </Animated.View>

        {/* On-device memory */}
        <SectionLabel>{t("memorySection")}</SectionLabel>
        <MemoryRow />

        {/* Daily reminder */}
        <SectionLabel>{t("reminderSection")}</SectionLabel>
        <ReminderRow />

        {/* Data */}
        <SectionLabel>{t("dataSection")}</SectionLabel>
        <Animated.View entering={FadeIn.delay(140).duration(220)}>
          <Pressable
            onPress={onClearHistory}
            disabled={threadCount === 0}
            className="active:opacity-70"
            style={{ opacity: threadCount === 0 ? 0.45 : 1 }}
          >
            <Glass radius={26} intensity={40}>
              <View className="flex-row items-center px-5 py-4">
                <View
                  style={{
                    width: 40,
                    height: 40,
                    borderRadius: 20,
                    alignItems: "center",
                    justifyContent: "center",
                    backgroundColor: alpha(theme.danger, 0.12),
                    borderWidth: StyleSheet.hairlineWidth,
                    borderColor: alpha(theme.danger, 0.3),
                  }}
                >
                  <Trash2 size={18} color={theme.danger} strokeWidth={1.9} />
                </View>
                <View className="ml-3.5 flex-1">
                  <Text
                    style={{
                      color: theme.danger,
                      fontSize: 16,
                      fontWeight: "600",
                      letterSpacing: -0.3,
                    }}
                  >
                    {t("clearHistory")}
                  </Text>
                  <Text
                    style={{ color: theme.textDim, fontSize: 13, marginTop: 2 }}
                  >
                    {threadCount > 0
                      ? t(
                          threadCount === 1
                            ? "savedChatsOne"
                            : "savedChatsMany",
                          { n: threadCount },
                        )
                      : t("noSavedChats")}
                  </Text>
                </View>
              </View>
            </Glass>
          </Pressable>
        </Animated.View>

        <View
          className="flex-row items-center justify-center"
          style={{ marginTop: 26 }}
        >
          <Pressable
            onPress={() => Linking.openURL(TERMS_URL)}
            hitSlop={8}
            className="active:opacity-50"
            testID="terms-link"
          >
            <Text style={{ color: theme.textDim, fontSize: 12.5, textDecorationLine: "underline" }}>
              {t("termsOfUse")}
            </Text>
          </Pressable>
          <Text style={{ color: theme.textFaint, fontSize: 12.5, marginHorizontal: 10 }}>·</Text>
          <Pressable
            onPress={() => Linking.openURL(PRIVACY_URL)}
            hitSlop={8}
            className="active:opacity-50"
            testID="privacy-link"
          >
            <Text style={{ color: theme.textDim, fontSize: 12.5, textDecorationLine: "underline" }}>
              {t("privacyPolicy")}
            </Text>
          </Pressable>
        </View>

        <Text
          style={{
            color: theme.textFaint,
            fontSize: 12,
            textAlign: "center",
            marginTop: 14,
            letterSpacing: 0.3,
          }}
        >
          {t("footer")}
        </Text>
        <Text
          testID="app-version"
          style={{
            color: theme.textFaint,
            fontSize: 10.5,
            textAlign: "center",
            marginTop: 6,
            letterSpacing: 0.6,
            opacity: 0.7,
          }}
        >
          v1.0.1
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}

function SectionLabel({ children }: { children: string }) {
  const theme = useTheme();
  const { up } = useI18n();
  return (
    <Text
      style={{ color: theme.textFaint, fontSize: 10.5, letterSpacing: 3 }}
      className="mb-3 mt-7 px-3"
    >
      {up(children)}
    </Text>
  );
}
