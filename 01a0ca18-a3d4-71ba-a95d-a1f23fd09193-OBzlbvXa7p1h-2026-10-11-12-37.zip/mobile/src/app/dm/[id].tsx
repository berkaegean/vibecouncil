import * as Haptics from "expo-haptics";
import { useLocalSearchParams, useRouter } from "expo-router";
import { ArrowUp, Gavel, ImagePlus, Share2, X } from "lucide-react-native";
import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Platform,
  Pressable,
  Text,
  TextInput,
  View,
} from "react-native";
import { Image } from "expo-image";
import Animated, { FadeIn } from "react-native-reanimated";
import { SafeAreaView } from "react-native-safe-area-context";

import { ChatBubble, PersonaAvatar } from "@/components/council/ChatBubble";
import { ChatHeader } from "@/components/council/ChatHeader";
import { Glass } from "@/components/council/Glass";
import { RenameSheet } from "@/components/council/RenameSheet";
import { ShareCard, shareCardImage } from "@/components/council/ShareCard";
import { VerdictSheet } from "@/components/council/VerdictSheet";
import { pickImage, type PickedImage } from "@/lib/council/image";
import { KeyboardPadded } from "@/components/council/KeyboardPadded";
import { TypingIndicator } from "@/components/council/TypingIndicator";
import { councilApi } from "@/lib/council/api";
import { useI18n } from "@/lib/council/i18n";
import { PERSONAS } from "@/lib/council/personas";
import { makeId, useCouncilStore, useThread, memoryTexts } from "@/lib/council/store";
import { useStickToBottom } from "@/lib/council/useStickToBottom";
import { useTheme } from "@/lib/council/useTheme";

/** A user turn for the model; photos are noted so later turns keep the context. */
const toTurn = (m: { text: string; imageUri?: string }) => ({
  role: "user" as const,
  content: [m.imageUri ? "[fotoğraf paylaştı]" : "", m.text].filter(Boolean).join(" ") || "[fotoğraf paylaştı]",
});

export default function DirectChatScreen() {
  const theme = useTheme();
  const { t, persona: copy } = useI18n();
  const { id } = useLocalSearchParams<{ id: string }>();
  const thread = useThread(id);
  const appendMessage = useCouncilStore((s) => s.appendMessage);
  const patchThread = useCouncilStore((s) => s.patchThread);
  const spendCrystal = useCouncilStore((s) => s.spendCrystal);
  const router = useRouter();

  const [draft, setDraft] = useState<string>("");
  const [busy, setBusy] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [picked, setPicked] = useState<PickedImage | null>(null);
  const [judging, setJudging] = useState<boolean>(false);
  const [verdictOpen, setVerdictOpen] = useState<boolean>(false);
  const [renaming, setRenaming] = useState<boolean>(false);
  const shareRef = useRef<View>(null);

  const listRef = useRef<FlatList>(null);
  const stick = useStickToBottom(listRef);
  const alive = useRef<boolean>(true);
  useEffect(() => {
    alive.current = true;
    return () => {
      alive.current = false;
      // Opened and left without writing → don't keep an empty chat around.
      if (id) useCouncilStore.getState().discardIfEmpty(id);
    };
  }, [id]);

  const messages = thread?.messages ?? [];

  useEffect(() => {
    if (messages.length > 0 || busy) {
      requestAnimationFrame(() =>
        listRef.current?.scrollToEnd({ animated: true }),
      );
    }
  }, [messages.length, busy]);

  const persona = thread?.persona;
  const meta = persona && PERSONAS[persona] ? copy(persona) : undefined;
  const hue = persona ? theme.persona[persona] : theme.accent;

  const send = useCallback(async () => {
    const text = draft.trim();
    const image = picked;
    if (!thread || !persona || (!text && !image) || busy) return;

    // 1 crystal per message; out of crystals → the paywall takes over.
    if (!spendCrystal()) {
      if (Platform.OS !== "web")
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
      router.push("/paywall");
      return;
    }

    setDraft("");
    setPicked(null);
    setError(null);
    setBusy(true);
    if (Platform.OS !== "web")
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

    appendMessage(thread.id, {
      id: makeId(),
      kind: "user",
      text,
      imageUri: image?.uri,
      createdAt: Date.now(),
    });

    if (thread.messages.length === 0 && text && !thread.named) {
      patchThread(thread.id, { title: `${persona} · ${text.slice(0, 30)}` });
    }

    // Keep the last 16 turns so the persona remembers the conversation.
    const history = [
      ...thread.messages,
      { kind: "user" as const, text, imageUri: image?.uri, persona: undefined },
    ]
      .filter((m) => m.kind === "user" || m.kind === "persona")
      .slice(-16)
      .map(toTurn);

    try {
      const reply = await councilApi.dm({
        persona,
        messages: history,
        imageDataUrl: image?.dataUrl,
        birth: useCouncilStore.getState().birth ?? undefined,
        lang: useCouncilStore.getState().language,
        memories: memoryTexts(),
      });
      if (reply.memory) useCouncilStore.getState().addMemory(reply.memory);
      if (!alive.current) return;
      appendMessage(thread.id, {
        id: makeId(),
        kind: "persona",
        persona,
        text: reply.message,
        createdAt: Date.now(),
      });
      if (Platform.OS !== "web")
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Soft);
    } catch (e) {
      if (!alive.current) return;
      setError(e instanceof Error ? e.message : t("genericError"));
      if (image) setPicked(image);
      // Refund — the persona never replied.
      useCouncilStore.getState().grantCrystals(1);
    } finally {
      if (alive.current) setBusy(false);
    }
  }, [draft, picked, thread, persona, busy, appendMessage, patchThread, spendCrystal, router, t]);

  const onPickImage = useCallback(async () => {
    if (Platform.OS !== "web")
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    const result = await pickImage();
    if (result) setPicked(result);
  }, []);

  const verdict = thread?.verdict;
  const symptoms = useMemo(
    () => messages.find((m) => m.kind === "verdict")?.symptoms ?? [],
    [messages],
  );
  const canJudge =
    !verdict && !busy && !judging && messages.some((m) => m.kind === "persona");

  /** "Karar Ver": the persona closes the chat with one clear ruling. Free, like council verdicts. */
  const decide = useCallback(async () => {
    if (!thread || !persona || !canJudge) return;
    if (Platform.OS !== "web")
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
    setError(null);
    setJudging(true);
    try {
      const result = await councilApi.verdict({
        history: thread.messages
          .filter((m) => m.kind === "user" || m.kind === "persona")
          .slice(-120)
          .map((m) =>
            m.kind === "user"
              ? toTurn(m)
              : { role: "assistant" as const, content: `${persona}: ${m.text}` },
          ),
        personas: [persona],
        lang: useCouncilStore.getState().language,
      });
      if (!alive.current) return;
      appendMessage(thread.id, {
        id: makeId(),
        kind: "verdict",
        text: result.final_verdict,
        symptoms: result.diagnostics.detected_symptoms,
        createdAt: Date.now(),
      });
      patchThread(thread.id, { verdict: result.final_verdict });
      setVerdictOpen(true);
      if (Platform.OS !== "web")
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (e) {
      if (!alive.current) return;
      setError(e instanceof Error ? e.message : t("genericError"));
    } finally {
      if (alive.current) setJudging(false);
    }
  }, [thread, persona, canJudge, appendMessage, patchThread, t]);

  const onShare = useCallback(() => {
    if (!verdict) return;
    shareCardImage(shareRef.current, `${verdict} — ${t("shareSignature")}`);
  }, [verdict, t]);

  if (!thread || !persona || !meta) {
    return (
      <View className="flex-1 items-center justify-center">
        <Text style={{ color: theme.textDim }}>{t("chatNotFound")}</Text>
      </View>
    );
  }

  const canSend = (draft.trim().length > 0 || Boolean(picked)) && !busy && !verdict;

  return (
    <View style={{ flex: 1 }}>
      <ChatHeader
        title={thread.named ? thread.title : persona}
        subtitle={thread.named ? `${persona} · ${meta.title}` : meta.title}
        subtitleColor={hue}
        avatar={<PersonaAvatar persona={persona} size={34} />}
        onTitlePress={() => setRenaming(true)}
        right={
          verdict ? (
            <View className="flex-row">
              <Pressable onPress={() => setVerdictOpen(true)} hitSlop={12} className="ml-2 active:opacity-50">
                <Glass radius={999} intensity={30}>
                  <View className="h-9 w-9 items-center justify-center">
                    <Gavel size={16} color={hue} />
                  </View>
                </Glass>
              </Pressable>
              <Pressable onPress={onShare} hitSlop={12} className="ml-2 active:opacity-50">
                <Glass radius={999} intensity={30}>
                  <View className="h-9 w-9 items-center justify-center">
                    <Share2 size={16} color={hue} />
                  </View>
                </Glass>
              </Pressable>
            </View>
          ) : messages.some((m) => m.kind === "persona") ? (
            <Pressable
              onPress={decide}
              disabled={!canJudge}
              hitSlop={8}
              className="ml-2 active:opacity-60"
              style={{ opacity: canJudge || judging ? 1 : 0.4 }}
              testID="dm-decide"
            >
              <View
                className="flex-row items-center"
                style={{ height: 34, paddingHorizontal: 12, borderRadius: 17, backgroundColor: hue }}
              >
                {judging ? (
                  <ActivityIndicator size="small" color={theme.onAccent} />
                ) : (
                  <Gavel size={14} color={theme.onAccent} strokeWidth={2.2} />
                )}
                <Text style={{ color: theme.onAccent, fontSize: 12.5, fontWeight: "700", marginLeft: 6 }}>
                  {t("dmDecide")}
                </Text>
              </View>
            </Pressable>
          ) : null
        }
      />

      <KeyboardPadded>
        <FlatList
          ref={listRef}
          onContentSizeChange={stick.onContentSizeChange}
          keyboardDismissMode="interactive"
          keyboardShouldPersistTaps="handled"
          data={messages}
          keyExtractor={(m) => m.id}
          contentContainerStyle={{
            paddingHorizontal: 14,
            paddingTop: 16,
            paddingBottom: 12,
          }}
          showsVerticalScrollIndicator={false}
          renderItem={({ item, index }) => (
            <ChatBubble message={item} index={index} members={[persona]} />
          )}
          ListEmptyComponent={
            <Animated.View
              entering={FadeIn.delay(80).duration(220)}
              className="items-center px-6 pt-16"
            >
              <PersonaAvatar persona={persona} size={84} />
              <Text
                style={{
                  color: theme.text,
                  fontSize: 26,
                  fontWeight: "200",
                  letterSpacing: -0.9,
                  marginTop: 18,
                }}
              >
                {persona}
              </Text>
              <Text
                style={{
                  color: hue,
                  fontSize: 13,
                  marginTop: 5,
                  letterSpacing: 0.3,
                }}
              >
                {meta.title}
              </Text>
              <Text
                style={{
                  color: theme.textDim,
                  fontSize: 14.5,
                  lineHeight: 21,
                  textAlign: "center",
                  marginTop: 14,
                }}
              >
                {t("dmIntro", { tagline: meta.tagline })}
              </Text>
            </Animated.View>
          }
          ListFooterComponent={
            <View>
              {busy ? <TypingIndicator persona={persona} /> : null}
              {judging ? (
                <Animated.View entering={FadeIn} className="flex-row items-center justify-center py-3">
                  <Gavel size={14} color={hue} />
                  <Text style={{ color: theme.textDim, fontSize: 13, marginLeft: 6 }}>
                    {t("dmVerdictPending", { name: persona })}
                  </Text>
                </Animated.View>
              ) : null}
              {error ? (
                <Animated.View entering={FadeIn} className="items-center py-3">
                  <Text style={{ color: "#FF8B80", fontSize: 13 }}>
                    {error}
                  </Text>
                </Animated.View>
              ) : null}
            </View>
          }
        />

        <SafeAreaView edges={["bottom"]}>
          {verdict ? (
            <View className="items-center px-6 pb-3 pt-2">
              <Text style={{ color: theme.textDim, fontSize: 13, textAlign: "center" }}>
                {t("dmDone", { name: persona })}
              </Text>
            </View>
          ) : (
          <View className="px-3 pb-1 pt-2">
            {picked ? (
              <Animated.View entering={FadeIn} className="mb-2 ml-2 self-start">
                <Image
                  source={{ uri: picked.uri }}
                  style={{ width: 64, height: 80, borderRadius: 14 }}
                  contentFit="cover"
                />
                <Pressable
                  onPress={() => setPicked(null)}
                  hitSlop={10}
                  style={{
                    position: "absolute",
                    top: -6,
                    right: -6,
                    width: 22,
                    height: 22,
                    borderRadius: 11,
                    alignItems: "center",
                    justifyContent: "center",
                    backgroundColor: theme.base,
                  }}
                >
                  <X size={13} color={theme.text} strokeWidth={2.4} />
                </Pressable>
              </Animated.View>
            ) : null}
            <Glass radius={26} intensity={52} elevated>
              <View className="flex-row items-end px-2.5 py-2">
                <Pressable
                  onPress={onPickImage}
                  disabled={busy}
                  hitSlop={8}
                  className="h-9 w-9 items-center justify-center active:opacity-50"
                  testID="dm-pick-image"
                >
                  <ImagePlus size={20} color={picked ? hue : theme.textDim} strokeWidth={1.9} />
                </Pressable>
                <TextInput
                  value={draft}
                  onChangeText={setDraft}
                  editable={!busy}
                  placeholder={t("dmPlaceholder", { name: persona })}
                  placeholderTextColor={theme.textFaint}
                  multiline
                  style={{
                    flex: 1,
                    color: theme.text,
                    fontSize: 16,
                    maxHeight: 110,
                    paddingTop: Platform.OS === "ios" ? 8 : 4,
                    paddingBottom: 8,
                    paddingHorizontal: 6,
                  }}
                />
                <Pressable
                  onPress={send}
                  disabled={!canSend}
                  hitSlop={8}
                  style={{
                    width: 36,
                    height: 36,
                    borderRadius: 18,
                    alignItems: "center",
                    justifyContent: "center",
                    backgroundColor: canSend ? hue : "rgba(255,255,255,0.07)",
                  }}
                  className="active:opacity-70"
                >
                  {busy ? (
                    <ActivityIndicator size="small" color={theme.onAccent} />
                  ) : (
                    <ArrowUp
                      size={19}
                      color={canSend ? theme.onAccent : theme.textFaint}
                      strokeWidth={2.6}
                    />
                  )}
                </Pressable>
              </View>
            </Glass>
          </View>
          )}
        </SafeAreaView>
      </KeyboardPadded>
      {verdict ? (
        <View pointerEvents="none" style={{ position: "absolute", left: -10000, top: 0 }}>
          <ShareCard ref={shareRef} data={{ kind: "verdict", verdict, symptoms, members: [persona] }} />
        </View>
      ) : null}
      {verdict ? (
        <VerdictSheet
          visible={verdictOpen}
          verdict={verdict}
          symptoms={symptoms}
          onClose={() => setVerdictOpen(false)}
          onShare={onShare}
        />
      ) : null}
      <RenameSheet
        threadId={thread.id}
        initial={thread.named ? thread.title : ""}
        visible={renaming}
        onClose={() => setRenaming(false)}
      />
    </View>
  );
}
