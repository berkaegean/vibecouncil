import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";
import { Check, Gem } from "lucide-react-native";
import React from "react";
import {
  Alert,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import RevenueCatUI from "react-native-purchases-ui";
import Animated, {
  Easing,
  FadeIn,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withTiming,
} from "react-native-reanimated";

import { Glass } from "@/components/council/Glass";
import { useI18n, type TKey } from "@/lib/council/i18n";
import { PERSONA_LIST, PersonaGlyph } from "@/lib/council/personas";
import {
  CRYSTAL_PACKS,
  grantForProduct,
  loadPackPrices,
  purchasesAvailable,
  purchaseCrystalPack,
} from "@/lib/council/purchases";
import { useCouncilStore } from "@/lib/council/store";
import { useTheme } from "@/lib/council/useTheme";

const PERKS: TKey[] = ["perk1", "perk2", "perk3", "perk4"];

/** RevenueCat-designed paywall; the custom sheet below is the fallback (web, no store). */
export default function PaywallScreen() {
  const router = useRouter();
  if (!purchasesAvailable()) return <PaywallSheet />;
  return (
    <View style={{ flex: 1 }} testID="revenuecat-paywall">
      <RevenueCatUI.Paywall
        options={{ displayCloseButton: true }}
        onPurchaseCompleted={({ storeTransaction }) => {
          grantForProduct(storeTransaction.productIdentifier);
          if (Platform.OS !== "web")
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        }}
        onDismiss={() => router.back()}
      />
    </View>
  );
}

function PaywallSheet() {
  const theme = useTheme();
  const { t, up } = useI18n();
  const router = useRouter();
  const crystals = useCouncilStore((s) => s.crystals);

  const glow = useSharedValue(0);
  React.useEffect(() => {
    glow.value = withRepeat(
      withTiming(1, { duration: 2600, easing: Easing.inOut(Easing.sin) }),
      -1,
      true,
    );
  }, [glow]);

  const glowStyle = useAnimatedStyle(() => ({
    opacity: 0.35 + glow.value * 0.45,
    transform: [{ scale: 1 + glow.value * 0.06 }],
  }));

  const [buying, setBuying] = React.useState(false);
  const [selected, setSelected] = React.useState(
    Math.max(0, CRYSTAL_PACKS.findIndex((p) => p.popular)),
  );
  const [prices, setPrices] = React.useState<Record<string, string>>({});
  React.useEffect(() => {
    loadPackPrices().then(setPrices);
  }, []);
  const pack = CRYSTAL_PACKS[selected];
  const priceOf = (p: (typeof CRYSTAL_PACKS)[number]) => prices[p.productId] ?? p.price;

  const onPurchase = async () => {
    if (buying) return;
    if (Platform.OS !== "web")
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setBuying(true);
    try {
      const result = await purchaseCrystalPack(pack);
      if (result === "success") {
        if (Platform.OS !== "web")
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        router.back();
      } else if (result === "unavailable") {
        Alert.alert(t("storeUnavailableTitle"), t("storeUnavailableBody"));
      }
    } catch {
      Alert.alert(t("purchaseFailedTitle"), t("purchaseFailedBody"));
    } finally {
      setBuying(false);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: theme.base }}>
      {/* Sheet grabber */}
      <View className="items-center pb-1 pt-3">
        <View
          style={{
            width: 38,
            height: 5,
            borderRadius: 3,
            backgroundColor: theme.hairline,
          }}
        />
      </View>

      <ScrollView
        contentContainerStyle={{
          paddingHorizontal: 22,
          paddingTop: 18,
          paddingBottom: 34,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Crest */}
        <Animated.View entering={FadeIn.duration(220)} className="items-center">
          <View
            className="items-center justify-center"
            style={{ height: 96, width: 96 }}
          >
            <Animated.View
              style={[
                {
                  position: "absolute",
                  width: 96,
                  height: 96,
                  borderRadius: 48,
                  backgroundColor: "rgba(123,97,255,0.16)",
                },
                glowStyle,
              ]}
            />
            <View
              style={{
                width: 70,
                height: 70,
                borderRadius: 35,
                alignItems: "center",
                justifyContent: "center",
                backgroundColor: "rgba(123,97,255,0.10)",
                borderWidth: StyleSheet.hairlineWidth,
                borderColor: "rgba(123,97,255,0.38)",
              }}
            >
              <Gem size={28} color={theme.accent} strokeWidth={1.75} />
            </View>
          </View>

          <Text
            style={{
              color: theme.text,
              fontSize: 30,
              fontWeight: "200",
              letterSpacing: -1.1,
              marginTop: 14,
              textAlign: "center",
            }}
          >
            {crystals <= 0 ? t("outOfCrystals") : t("upgradeCrystals")}
          </Text>
          <Text
            style={{
              color: theme.textDim,
              fontSize: 14.5,
              lineHeight: 21,
              textAlign: "center",
              marginTop: 8,
            }}
          >
            {t("paywallSubtitle")}
          </Text>
        </Animated.View>

        {/* Offer */}
        <Animated.View
          entering={FadeIn.delay(90).duration(220)}
          className="mt-7"
        >
          <Glass
            radius={30}
            intensity={58}
            elevated
            tintColor="rgba(123,97,255,0.07)"
          >
            <View className="px-6 py-6">
              <Text
                style={{
                  color: theme.textFaint,
                  fontSize: 10.5,
                  letterSpacing: 2.8,
                  marginBottom: 12,
                }}
              >
                {up(t("crystalPack"))}
              </Text>
              {CRYSTAL_PACKS.map((p, i) => {
                const active = i === selected;
                return (
                  <Pressable
                    key={p.productId}
                    onPress={() => {
                      if (Platform.OS !== "web") Haptics.selectionAsync();
                      setSelected(i);
                    }}
                    disabled={buying}
                    className="active:opacity-70"
                    testID={`pack-${p.amount}`}
                  >
                    <View
                      className="flex-row items-center justify-between"
                      style={{
                        marginBottom: 10,
                        paddingHorizontal: 16,
                        paddingVertical: 14,
                        borderRadius: 18,
                        borderWidth: active ? 1.5 : StyleSheet.hairlineWidth,
                        borderColor: active ? theme.accent : theme.hairline,
                        backgroundColor: active ? "rgba(123,97,255,0.10)" : "transparent",
                      }}
                    >
                      <View>
                        <Text
                          style={{
                            color: theme.text,
                            fontSize: 22,
                            fontWeight: "300",
                            letterSpacing: -0.8,
                          }}
                        >
                          {t("crystalsAmount", { n: p.amount })}
                        </Text>
                        {p.popular ? (
                          <Text
                            style={{
                              color: theme.accent,
                              fontSize: 11,
                              fontWeight: "600",
                              letterSpacing: 0.4,
                              marginTop: 2,
                            }}
                          >
                            {t("popularPack")}
                          </Text>
                        ) : null}
                      </View>
                      <Text
                        style={{
                          color: active ? theme.accent : theme.textDim,
                          fontSize: 19,
                          fontWeight: "400",
                          letterSpacing: -0.4,
                        }}
                      >
                        {priceOf(p)}
                      </Text>
                    </View>
                  </Pressable>
                );
              })}

              <View
                style={{
                  height: StyleSheet.hairlineWidth,
                  backgroundColor: theme.hairline,
                  marginVertical: 18,
                }}
              />

              {PERKS.map((perk) => (
                <View key={perk} className="mb-2.5 flex-row items-center">
                  <View
                    style={{
                      width: 19,
                      height: 19,
                      borderRadius: 10,
                      alignItems: "center",
                      justifyContent: "center",
                      backgroundColor: "rgba(123,97,255,0.14)",
                    }}
                  >
                    <Check size={11} color={theme.accent} strokeWidth={3} />
                  </View>
                  <Text
                    style={{
                      color: theme.text,
                      fontSize: 14.5,
                      marginLeft: 11,
                    }}
                  >
                    {t(perk)}
                  </Text>
                </View>
              ))}
            </View>
          </Glass>
        </Animated.View>

        {/* Roster reminder */}
        <View
          className="mt-6 flex-row flex-wrap items-center justify-center"
          style={{ rowGap: 14 }}
        >
          {PERSONA_LIST.map((p) => (
            <View key={p.id} className="items-center" style={{ width: "25%" }}>
              <PersonaGlyph
                persona={p.id}
                size={34}
                color={theme.persona[p.id]}
              />
              <Text
                style={{
                  color: theme.textFaint,
                  fontSize: 10,
                  marginTop: 6,
                  letterSpacing: 0.6,
                }}
              >
                {up(p.id)}
              </Text>
            </View>
          ))}
        </View>

        {/* CTA */}
        <Animated.View
          entering={FadeIn.delay(170).duration(220)}
          className="mt-8"
        >
          <Pressable
            onPress={onPurchase}
            disabled={buying}
            className="active:opacity-80"
          >
            <View
              style={{
                backgroundColor: theme.accent,
                borderRadius: 999,
                paddingVertical: 17,
                alignItems: "center",
              }}
            >
              <Text
                style={{
                  color: theme.onAccent,
                  fontSize: 17,
                  fontWeight: "700",
                  letterSpacing: -0.3,
                }}
              >
                {buying
                  ? t("processing")
                  : t("buyCrystals", {
                      n: pack.amount,
                      price: priceOf(pack),
                    })}
              </Text>
            </View>
          </Pressable>

          <Pressable
            onPress={() => router.back()}
            className="mt-3 items-center py-2 active:opacity-50"
          >
            <Text style={{ color: theme.textDim, fontSize: 14.5 }}>
              {t("notNow")}
            </Text>
          </Pressable>
        </Animated.View>
      </ScrollView>
    </View>
  );
}
