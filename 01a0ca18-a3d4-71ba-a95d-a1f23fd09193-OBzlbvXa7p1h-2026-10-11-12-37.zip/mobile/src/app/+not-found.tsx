import { Link, Stack } from "expo-router";
import { Text, View } from "react-native";

import { useI18n } from "@/lib/council/i18n";

export default function NotFoundScreen() {
  const { t } = useI18n();
  return (
    <>
      <Stack.Screen options={{ title: t("notFoundTitle") }} />
      <View
        testID="not-found-screen"
        className="flex-1 items-center justify-center bg-white p-5 dark:bg-black"
      >
        <Text className="text-xl font-bold text-black dark:text-white">
          {t("notFoundText")}
        </Text>

        <Link href="/" testID="go-home-link" className="mt-4 py-4">
          <Text className="text-sm text-blue-500">{t("notFoundHome")}</Text>
        </Link>
      </View>
    </>
  );
}
