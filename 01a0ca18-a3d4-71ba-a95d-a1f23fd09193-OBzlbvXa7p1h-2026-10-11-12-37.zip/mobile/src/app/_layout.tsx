import { DefaultTheme, ThemeProvider } from '@react-navigation/native';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Stack } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { StatusBar } from 'expo-status-bar';
import { useTheme } from '@/lib/council/useTheme';
import React, { useCallback, useEffect, useState } from 'react';
import { View } from 'react-native';
import * as SystemUI from 'expo-system-ui';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { KeyboardProvider } from 'react-native-keyboard-controller';

import { Atmosphere } from '@/components/council/Atmosphere';
import { IntroSplash } from '@/components/council/IntroSplash';
import { initPurchases } from '@/lib/council/purchases';
import { useCouncilStore } from '@/lib/council/store';
import { enableDailyReminder } from '@/lib/council/reminder';
import { PEARLESCENT } from '@/lib/council/theme';

export const unstable_settings = {
  initialRouteName: '(tabs)',
};

// Prevent the splash screen from auto-hiding before asset loading is complete.
SplashScreen.preventAutoHideAsync();

const queryClient = new QueryClient();

const navTheme = {
  ...DefaultTheme,
  colors: { ...DefaultTheme.colors, background: 'transparent', card: 'transparent' },
};

function RootLayoutNav() {
  const hydrated = useCouncilStore((s) => s.hydrated);
  const hasBirth = useCouncilStore((s) => s.birth !== null);

  useEffect(() => {
    if (hydrated) SplashScreen.hideAsync();
  }, [hydrated]);

  useEffect(() => {
    initPurchases();
  }, []);

  // Keep the daily reminder scheduled (and in the current language) across launches.
  const reminderOn = useCouncilStore((s) => s.dailyReminder);
  const reminderTime = useCouncilStore((s) => s.reminderTime);
  const language = useCouncilStore((s) => s.language);
  useEffect(() => {
    if (hydrated && reminderOn) enableDailyReminder(reminderTime, false).catch(() => undefined);
  }, [hydrated, reminderOn, reminderTime, language]);

  if (!hydrated) return null;

  return (
    <ThemeProvider value={navTheme}>
      <Stack
        screenOptions={{
          headerShown: false,
          contentStyle: { backgroundColor: 'transparent' },
          animation: 'slide_from_right',
        }}>
        <Stack.Protected guard={hasBirth}>
          <Stack.Screen name="(tabs)" />
          <Stack.Screen name="council/[id]" />
          <Stack.Screen name="dm/[id]" />
          <Stack.Screen name="memory" />
          <Stack.Screen
            name="paywall"
            options={{
              presentation: 'modal',
              animation: 'slide_from_bottom',
              contentStyle: { backgroundColor: 'transparent' },
            }}
          />
        </Stack.Protected>
        <Stack.Protected guard={!hasBirth}>
          <Stack.Screen name="onboarding" options={{ animation: 'fade' }} />
        </Stack.Protected>
      </Stack>
    </ThemeProvider>
  );
}

// On wide screens (unfolded foldables, iPad) keep content in a readable centered column
// while the atmosphere background stays full-bleed.
const MAX_CONTENT_WIDTH = 640;

export default function RootLayout() {
  const theme = useTheme();
  const hydrated = useCouncilStore((s) => s.hydrated);
  // Paint the native root view in the theme colour so any area outside the
  // React tree (e.g. while unfolding/resizing) never flashes black.
  useEffect(() => {
    SystemUI.setBackgroundColorAsync(theme.base).catch(() => undefined);
  }, [theme.base]);
  const [showIntro, setShowIntro] = useState<boolean>(true);
  const hideIntro = useCallback(() => setShowIntro(false), []);
  return (
    <QueryClientProvider client={queryClient}>
      <GestureHandlerRootView style={{ flex: 1, backgroundColor: theme.base }}>
        <KeyboardProvider>
          <StatusBar style={showIntro ? 'light' : theme.statusBar} />
          <View style={{ flex: 1, backgroundColor: theme.base }}>
            <Atmosphere />
            <View style={{ flex: 1, width: '100%', maxWidth: MAX_CONTENT_WIDTH, alignSelf: 'center' }}>
              <RootLayoutNav />
            </View>
            {showIntro && hydrated ? <IntroSplash onDone={hideIntro} /> : null}
          </View>
        </KeyboardProvider>
      </GestureHandlerRootView>
    </QueryClientProvider>
  );
}
