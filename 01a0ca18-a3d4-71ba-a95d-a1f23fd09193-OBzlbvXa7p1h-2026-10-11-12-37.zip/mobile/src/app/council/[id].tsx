import * as Haptics from "expo-haptics";
import { Image } from "expo-image";
import { useLocalSearchParams, useRouter } from "expo-router";
import { ArrowUp, Check, Gavel, ImagePlus, Share2, Vote, X } from "lucide-react-native";
import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import Animated, { FadeIn } from "react-native-reanimated";
import { SafeAreaView } from "react-native-safe-area-context";

import { ChatBubble } from "@/components/council/ChatBubble";
import { ChatHeader } from "@/components/council/ChatHeader";
import { Glass } from "@/components/council/Glass";
import { KeyboardPadded } from "@/components/council/KeyboardPadded";
import { ShareCard, shareCardImage } from "@/components/council/ShareCard";
import { TypingIndicator } from "@/components/council/TypingIndicator";
import { RenameSheet } from "@/components/council/RenameSheet";
import { VerdictSheet } from "@/components/council/VerdictSheet";
import { councilApi } from "@/lib/council/api";
import { useI18n } from "@/lib/council/i18n";
import { pickImage, type PickedImage } from "@/lib/council/image";
import {
  DEFAULT_COUNCIL,
  MAX_COUNCIL,
  PERSONA_LIST,
  PERSONAS,
  PersonaGlyph,
  type PersonaId,
} from "@/lib/council/personas";
import { makeId, memoryTexts, useCouncilStore, useThread, type ChatMessage } from "@/lib/council/store";
import { alpha } from "@/lib/council/theme";
import { useStickToBottom } from "@/lib/council/useStickToBottom";
import { useTheme } from "@/lib/council/useTheme";

const sleep = (ms: number) =>
  new Promise<void>((resolve) => setTimeout(resolve, ms));

/** Chat turns in the shape the backend expects; persona turns are "Persona: message". */
const toHistory = (messages: ChatMessage[]) =>
  messages
    .filter((m) => m.kind !== "verdict")
    .map((m) =>
      m.kind === "vote"
        ? {
            role: "assistant" as const,
            content: `Oylama "${m.text}": ${(m.votes ?? []).map((v) => `${v.persona} ${v.vote === "yes" ? "evet" : "hayır"}`).join(", ")}`,
          }
        : m.kind === "user"
        ? {
            role: "user" as const,
            content:
              [m.imageUri ? "[fotoğraf paylaştı]" : "", m.text]
                .filter(Boolean)
                .join(" ") || "[fotoğraf paylaştı]",
          }
        : { role: "assistant" as const, content: `${m.persona}: ${m.text}` },
    );

export default function CouncilChatScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const theme = useTheme();
  const { t } = useI18n();
  const thread = useThread(id);

  const appendMessage = useCouncilStore((s) => s.appendMessage);
  const patchThread = useCouncilStore((s) => s.patchThread);
  const spendCrystals = useCouncilStore((s) => s.spendCrystals);
  const crystals = useCouncilStore((s) => s.crystals);

  const [draft, setDraft] = useState<string>("");
  const [picked, setPicked] = useState<PickedImage | null>(null);
  const [typing, setTyping] = useState<PersonaId | null>(null);
  const [busy, setBusy] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [voteMode, setVoteMode] = useState<boolean>(false);
  const [judging, setJudging] = useState<boolean>(false);
  /** Verdict errors cost nothing, so no refund note. */
  const [verdictFailed, setVerdictFailed] = useState<boolean>(false);
  const [verdictOpen, setVerdictOpen] = useState<boolean>(false);
  const [renaming, setRenaming] = useState<boolean>(false);
  const shareRef = useRef<View>(null);

  const listRef = useRef<FlatList>(null);
  const stick = useStickToBottom(listRef);
  const alive = useRef<boolean>(true);
  useEffect(() => {
    alive.current = true;
    return () => {
      alive.current = false;
      // Opened and left without writing → don't keep an empty chat around.
      if (id) useCouncilStore.getState().discardIfEmpty(id);
    };
  }, [id]);

  const messages = thread?.messages ?? [];
  const verdict = thread?.verdict;
  const done = Boolean(verdict);
  const grand = Boolean(thread?.grand);
  const members = grand
    ? PERSONA_LIST.map((p) => p.id)
    : thread?.members?.length
    ? thread.members
    : DEFAULT_COUNCIL;
  // Summoning all eight costs 2; every later message is 1, like any council.
  const cost = grand ? 2 : 1;
  const locked = messages.length > 0 || busy;

  const toggleMember = useCallback(
    (id: PersonaId) => {
      if (!thread || locked || grand) return;
      const has = members.includes(id);
      if (has && members.length === 1) return;
      if (!has && members.length >= MAX_COUNCIL) {
        if (Platform.OS !== "web")
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
        return;
      }
      if (Platform.OS !== "web") Haptics.selectionAsync();
      const next = has
        ? members.filter((m) => m !== id)
        : PERSONA_LIST.map((p) => p.id).filter(
            (p) => p === id || members.includes(p),
          );
      patchThread(thread.id, { members: next });
    },
    [thread, locked, grand, members, patchThread],
  );

  const scrollToEnd = useCallback(() => {
    requestAnimationFrame(() =>
      listRef.current?.scrollToEnd({ animated: true }),
    );
  }, []);

  useEffect(() => {
    if (messages.length > 0 || typing) scrollToEnd();
  }, [messages.length, typing, scrollToEnd]);

  const onPickImage = useCallback(async () => {
    if (Platform.OS !== "web")
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    const result = await pickImage();
    if (result) setPicked(result);
  }, []);

  const canSend =
    (Boolean(picked) || draft.trim().length > 0) && !busy;

  const summon = useCallback(async () => {
    if (!thread || !canSend) return;

    // Out of crystals — the paywall takes over.
    if (crystals < cost || !spendCrystals(cost)) {
      if (Platform.OS !== "web")
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
      router.push("/paywall");
      return;
    }

    const context = draft.trim();
    const image = picked;
    // Earlier turns give the council memory of the whole group chat.
    const history = toHistory(thread.messages).slice(-40);

    setDraft("");
    setPicked(null);
    setError(null);
    setVerdictFailed(false);
    setBusy(true);
    if (Platform.OS !== "web")
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    appendMessage(thread.id, {
      id: makeId(),
      kind: "user",
      text: context,
      imageUri: image?.uri,
      createdAt: Date.now(),
    });

    if (context && history.length === 0 && !thread.named)
      patchThread(thread.id, { title: context.slice(0, 42) });

    const remember = (memory?: string) => {
      if (memory) useCouncilStore.getState().addMemory(memory);
    };

    if (voteMode) {
      setVoteMode(false);
      try {
        const result = await councilApi.vote({
          imageDataUrl: image?.dataUrl,
          context: context || undefined,
          birth: useCouncilStore.getState().birth ?? undefined,
          personas: members,
          lang: useCouncilStore.getState().language,
          memories: memoryTexts(),
          grand,
        });
        remember(result.memory);
        if (!alive.current) return;
        appendMessage(thread.id, {
          id: makeId(),
          kind: "vote",
          text: result.question,
          votes: result.votes,
          createdAt: Date.now(),
        });
        if (Platform.OS !== "web")
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        if (useCouncilStore.getState().crystals <= 0) {
          await sleep(1400);
          if (alive.current) router.push("/paywall");
        }
      } catch (e) {
        if (!alive.current) return;
        setError(e instanceof Error ? e.message : t("genericError"));
        useCouncilStore.getState().grantCrystals(1);
      } finally {
        if (alive.current) setBusy(false);
      }
      return;
    }

    try {
      const analysis = await councilApi.analyze({
        imageDataUrl: image?.dataUrl,
        context: context || undefined,
        birth: useCouncilStore.getState().birth ?? undefined,
        personas: members,
        lang: useCouncilStore.getState().language,
        history: history.length > 0 ? history : undefined,
        memories: memoryTexts(),
        mode: grand ? "grand" : undefined,
      });
      remember(analysis.memory);

      for (const line of analysis.chat_sequence) {
        if (!alive.current) return;
        setTyping(line.persona);
        await sleep(line.delay_ms);
        if (!alive.current) return;
        setTyping(null);
        appendMessage(thread.id, {
          id: makeId(),
          kind: "persona",
          persona: line.persona,
          text: line.message,
          createdAt: Date.now(),
        });
        if (Platform.OS !== "web")
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Soft);
        await sleep(220);
      }

      // That was the last crystal — surface the store once the council has spoken.
      if (useCouncilStore.getState().crystals <= 0) {
        await sleep(900);
        if (alive.current) router.push("/paywall");
      }
    } catch (e) {
      if (!alive.current) return;
      setTyping(null);
      setError(e instanceof Error ? e.message : t("genericError"));
      // Refund — the council never spoke.
      useCouncilStore.getState().grantCrystals(cost);
    } finally {
      if (alive.current) setBusy(false);
    }
  }, [
    thread,
    canSend,
    crystals,
    spendCrystals,
    cost,
    grand,
    draft,
    picked,
    members,
    appendMessage,
    patchThread,
    router,
    t,
    voteMode,
  ]);

  const symptoms = useMemo(
    () => messages.find((m) => m.kind === "verdict")?.symptoms ?? [],
    [messages],
  );
  const canJudge =
    !done && !busy && !judging && messages.some((m) => m.kind !== "user");

  /** "Kararı Açıkla": closes the session with one joint ruling over the whole chat. */
  const revealVerdict = useCallback(async () => {
    if (!thread || !canJudge) return;
    if (Platform.OS !== "web")
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
    setError(null);
    setVerdictFailed(false);
    setJudging(true);
    try {
      const result = await councilApi.verdict({
        history: toHistory(thread.messages).slice(-120),
        personas: members,
        lang: useCouncilStore.getState().language,
      });
      if (!alive.current) return;
      appendMessage(thread.id, {
        id: makeId(),
        kind: "verdict",
        text: result.final_verdict,
        symptoms: result.diagnostics.detected_symptoms,
        createdAt: Date.now(),
      });
      patchThread(thread.id, { verdict: result.final_verdict });
      setVerdictOpen(true);
      if (Platform.OS !== "web")
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (e) {
      if (!alive.current) return;
      setVerdictFailed(true);
      setError(e instanceof Error ? e.message : t("genericError"));
    } finally {
      if (alive.current) setJudging(false);
    }
  }, [thread, canJudge, members, appendMessage, patchThread, t]);

  /** Warn first: revealing the verdict closes the session for good. */
  const confirmVerdict = useCallback(() => {
    if (!canJudge) return;
    if (Platform.OS !== "web") Haptics.selectionAsync();
    if (Platform.OS === "web") {
      revealVerdict();
      return;
    }
    Alert.alert(t("verdictConfirmTitle"), t("verdictConfirmBody"), [
      { text: t("verdictConfirmCancel"), style: "cancel" },
      { text: t("endSession"), style: "destructive", onPress: revealVerdict },
    ]);
  }, [canJudge, revealVerdict, t]);

  const createThread = useCouncilStore((s) => s.createThread);
  /** Same council setup, fresh session. */
  const startNewSession = useCallback(() => {
    if (Platform.OS !== "web")
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    const id = createThread("council");
    patchThread(id, grand ? { grand: true, members } : { members });
    router.replace({ pathname: "/council/[id]", params: { id } });
  }, [createThread, patchThread, grand, members, router]);

  const onShare = useCallback(() => {
    if (!verdict) return;
    shareCardImage(shareRef.current, `${verdict} — ${t("shareSignature")}`);
  }, [verdict, t]);

  if (!thread) {
    return (
      <View className="flex-1 items-center justify-center">
        <Text style={{ color: theme.textDim }}>{t("chatNotFound")}</Text>
      </View>
    );
  }

  return (
    <View style={{ flex: 1 }}>
      <ChatHeader
        title={thread.named ? thread.title : grand ? t("grandTitle") : t("council")}
        onTitlePress={() => setRenaming(true)}
        subtitle={done ? verdict : members.join(" · ")}
        subtitleColor={done ? theme.accent : undefined}
        avatar={
          <View className="flex-row">
            {members
              .slice(0, grand ? 5 : 4)
              .map((id) => PERSONAS[id])
              .map((p, i) => (
                <View
                  key={p.id}
                  style={{
                    marginLeft: i === 0 ? 0 : -9,
                    width: 28,
                    height: 28,
                    borderRadius: 14,
                    alignItems: "center",
                    justifyContent: "center",
                    backgroundColor: theme.base,
                    borderWidth: StyleSheet.hairlineWidth,
                    borderColor: alpha(theme.persona[p.id], 0.45),
                  }}
                >
                  <PersonaGlyph
                    persona={p.id}
                    size={28}
                    color={theme.persona[p.id]}
                  />
                </View>
              ))}
          </View>
        }
        right={
          done ? (
            <View className="flex-row">
              <Pressable
                onPress={() => setVerdictOpen(true)}
                hitSlop={12}
                className="ml-2 active:opacity-50"
                testID="reopen-verdict"
              >
                <Glass radius={999} intensity={30}>
                  <View className="h-9 w-9 items-center justify-center">
                    <Gavel size={16} color={theme.accent} />
                  </View>
                </Glass>
              </Pressable>
              <Pressable
                onPress={onShare}
                hitSlop={12}
                className="ml-2 active:opacity-50"
              >
                <Glass radius={999} intensity={30}>
                  <View className="h-9 w-9 items-center justify-center">
                    <Share2 size={16} color={theme.accent} />
                  </View>
                </Glass>
              </Pressable>
            </View>
          ) : messages.length > 0 ? (
            <Pressable
              onPress={confirmVerdict}
              disabled={!canJudge}
              hitSlop={8}
              className="ml-2 active:opacity-60"
              style={{ opacity: canJudge || judging ? 1 : 0.4 }}
              testID="reveal-verdict"
              accessibilityHint={t("endSessionHint")}
            >
              <View
                className="flex-row items-center"
                style={{
                  height: 34,
                  paddingHorizontal: 12,
                  borderRadius: 17,
                  backgroundColor: theme.accent,
                }}
              >
                {judging ? (
                  <ActivityIndicator size="small" color={theme.onAccent} />
                ) : (
                  <Gavel size={14} color={theme.onAccent} strokeWidth={2.2} />
                )}
                <Text
                  style={{
                    color: theme.onAccent,
                    fontSize: 12.5,
                    fontWeight: "700",
                    marginLeft: 6,
                  }}
                >
                  {t("endSession")}
                </Text>
              </View>
            </Pressable>
          ) : undefined
        }
      />

      <KeyboardPadded>
        <FlatList
          ref={listRef}
          onContentSizeChange={stick.onContentSizeChange}
          keyboardDismissMode="interactive"
          keyboardShouldPersistTaps="handled"
          data={messages}
          keyExtractor={(m) => m.id}
          contentContainerStyle={{
            paddingHorizontal: 14,
            paddingTop: 16,
            paddingBottom: 12,
          }}
          showsVerticalScrollIndicator={false}
          renderItem={({ item, index }) => (
            <ChatBubble message={item} index={index} members={members} />
          )}
          ListEmptyComponent={
            grand ? (
              <GrandPrimer />
            ) : (
              <CouncilPrimer members={members} onToggle={toggleMember} />
            )
          }
          ListFooterComponent={
            <View>
              {typing ? <TypingIndicator persona={typing} /> : null}
              {judging ? (
                <Animated.View
                  entering={FadeIn}
                  className="flex-row items-center justify-center py-3"
                >
                  <Gavel size={14} color={theme.accent} />
                  <Text
                    style={{
                      color: theme.accent,
                      fontSize: 13,
                      marginLeft: 8,
                      letterSpacing: 0.3,
                    }}
                  >
                    {t("verdictPending")}
                  </Text>
                </Animated.View>
              ) : null}
              {busy && !typing ? (
                <Animated.View
                  entering={FadeIn}
                  className="flex-row items-center py-2 pl-2"
                >
                  <ActivityIndicator size="small" color={theme.accent} />
                  <Text
                    style={{
                      color: theme.textDim,
                      fontSize: 13,
                      marginLeft: 10,
                    }}
                  >
                    {t("councilGathering")}
                  </Text>
                </Animated.View>
              ) : null}
              {error ? (
                <Animated.View entering={FadeIn} className="items-center py-3">
                  <Text
                    style={{
                      color: theme.danger,
                      fontSize: 13,
                      textAlign: "center",
                    }}
                  >
                    {error}
                  </Text>
                  {verdictFailed ? null : (
                  <Text
                    style={{
                      color: theme.textFaint,
                      fontSize: 12,
                      marginTop: 4,
                    }}
                  >
                    {t("crystalRefunded")}
                  </Text>
                  )}
                </Animated.View>
              ) : null}
            </View>
          }
        />

        {done ? (
          <SafeAreaView edges={["bottom"]}>
            <Text
              style={{
                color: theme.textFaint,
                fontSize: 12.5,
                textAlign: "center",
                paddingVertical: 14,
                letterSpacing: 0.3,
              }}
            >
              {t("sessionClosed")}
            </Text>
            <View className="items-center pb-3">
              <Pressable
                onPress={startNewSession}
                className="active:opacity-80"
                testID="new-session"
              >
                <View
                  className="flex-row items-center"
                  style={{
                    paddingHorizontal: 22,
                    paddingVertical: 13,
                    borderRadius: 999,
                    backgroundColor: theme.accent,
                  }}
                >
                  <Gavel size={15} color={theme.onAccent} />
                  <Text
                    style={{
                      color: theme.onAccent,
                      fontSize: 15.5,
                      fontWeight: "700",
                      marginLeft: 8,
                      letterSpacing: -0.2,
                    }}
                  >
                    {t("newSession")}
                  </Text>
                </View>
              </Pressable>
            </View>
          </SafeAreaView>
        ) : (
        <Composer
          grand={grand}
          draft={draft}
          setDraft={setDraft}
          picked={picked}
          clearPicked={() => setPicked(null)}
          onPickImage={onPickImage}
          onSend={summon}
          canSend={canSend}
          busy={busy}
          hasMessages={messages.length > 0}
          members={members}
          voteMode={voteMode}
          onToggleVote={() => {
            if (Platform.OS !== "web") Haptics.selectionAsync();
            setVoteMode((v) => !v);
          }}
        />
        )}
      </KeyboardPadded>
      {verdict ? (
        <View pointerEvents="none" style={{ position: "absolute", left: -10000, top: 0 }}>
          <ShareCard
            ref={shareRef}
            data={{ kind: "verdict", verdict, symptoms, members }}
          />
        </View>
      ) : null}
      {verdict ? (
        <VerdictSheet
          visible={verdictOpen}
          verdict={verdict}
          symptoms={symptoms}
          onClose={() => setVerdictOpen(false)}
          onShare={onShare}
        />
      ) : null}
      <RenameSheet
        threadId={thread.id}
        initial={thread.named ? thread.title : ""}
        visible={renaming}
        onClose={() => setRenaming(false)}
      />
    </View>
  );
}

function GrandPrimer() {
  const theme = useTheme();
  const { t, up } = useI18n();
  return (
    <Animated.View entering={FadeIn.delay(80).duration(220)} className="px-1 pb-4 pt-4">
      <Glass radius={26} intensity={40} tintColor={theme.accentSoft}>
        <View className="items-center px-5 py-6" testID="grand-primer">
          <Text style={{ color: theme.textFaint, fontSize: 10.5, letterSpacing: 2.6 }}>
            {up(t("grandTitle"))} · {t("grandCost")}
          </Text>
          <View className="mt-4 flex-row flex-wrap justify-center" style={{ gap: 10, maxWidth: 260 }}>
            {PERSONA_LIST.map((p, i) => (
              <Animated.View key={p.id} entering={FadeIn.delay(120 + i * 70).duration(260)}>
                <PersonaGlyph persona={p.id} size={48} color={theme.persona[p.id]} />
              </Animated.View>
            ))}
          </View>
          <Text
            style={{
              color: theme.text,
              fontSize: 18,
              fontWeight: "300",
              lineHeight: 25,
              textAlign: "center",
              marginTop: 16,
            }}
          >
            {t("grandBody")}
          </Text>
        </View>
      </Glass>
    </Animated.View>
  );
}

function CouncilPrimer({
  members,
  onToggle,
}: {
  members: PersonaId[];
  onToggle: (id: PersonaId) => void;
}) {
  const theme = useTheme();
  const { t, up, persona: copy } = useI18n();

  return (
    <Animated.View
      entering={FadeIn.delay(80).duration(220)}
      className="px-1 pb-4 pt-4"
    >
      <Glass radius={26} intensity={40}>
        <View className="px-5 py-5">
          <View className="flex-row items-center justify-between">
            <Text
              style={{
                color: theme.textFaint,
                fontSize: 10.5,
                letterSpacing: 2.6,
              }}
            >
              {up(t("chooseCouncil"))}
            </Text>
            <Text
              style={{ color: theme.accent, fontSize: 12.5, fontWeight: "700" }}
            >
              {members.length}/{MAX_COUNCIL}
            </Text>
          </View>
          <Text
            style={{
              color: theme.text,
              fontSize: 20,
              fontWeight: "300",
              letterSpacing: -0.6,
              marginTop: 8,
              lineHeight: 27,
            }}
          >
            {t("chooseCouncilBody")}
          </Text>

          <View
            className="mt-4 flex-row flex-wrap"
            style={{ marginHorizontal: -4 }}
          >
            {PERSONA_LIST.map((p) => {
              const on = members.includes(p.id);
              const hue = theme.persona[p.id];
              return (
                <View key={p.id} style={{ width: "50%", padding: 4 }}>
                  <Pressable
                    onPress={() => onToggle(p.id)}
                    className="active:opacity-70"
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      borderRadius: 16,
                      paddingVertical: 10,
                      paddingHorizontal: 10,
                      borderWidth: on ? 1.2 : StyleSheet.hairlineWidth,
                      borderColor: on ? hue : theme.hairline,
                      backgroundColor: on ? alpha(hue, 0.1) : "transparent",
                    }}
                  >
                    <PersonaGlyph
                      persona={p.id}
                      size={30}
                      color={on ? hue : undefined}
                    />
                    <View className="ml-2 flex-1">
                      <Text
                        style={{
                          color: on ? theme.text : theme.textDim,
                          fontSize: 13.5,
                          fontWeight: "700",
                        }}
                      >
                        {p.id}
                      </Text>
                      <Text
                        numberOfLines={1}
                        style={{ color: theme.textFaint, fontSize: 11 }}
                      >
                        {copy(p.id).title}
                      </Text>
                    </View>
                    {on ? (
                      <Check size={14} color={hue} strokeWidth={2.6} />
                    ) : null}
                  </Pressable>
                </View>
              );
            })}
          </View>
        </View>
      </Glass>
    </Animated.View>
  );
}

function Composer({
  draft,
  setDraft,
  picked,
  clearPicked,
  onPickImage,
  onSend,
  canSend,
  busy,
  hasMessages,
  members,
  voteMode,
  onToggleVote,
  grand,
}: {
  draft: string;
  setDraft: (v: string) => void;
  picked: PickedImage | null;
  clearPicked: () => void;
  onPickImage: () => void;
  onSend: () => void;
  canSend: boolean;
  busy: boolean;
  hasMessages: boolean;
  members: PersonaId[];
  voteMode: boolean;
  onToggleVote: () => void;
  grand: boolean;
}) {
  const theme = useTheme();
  const { t, persona } = useI18n();

  // "@", optionally followed by a partial name, at the very end of the draft.
  const mentionQuery = draft.match(/(?:^|\s)@([\p{L}]*)$/u)?.[1];
  const suggestions =
    mentionQuery === undefined
      ? []
      : members.filter((id) =>
          id
            .toLocaleLowerCase("tr-TR")
            .startsWith(mentionQuery.toLocaleLowerCase("tr-TR")),
        );
  const insertMention = (id: PersonaId) => {
    if (Platform.OS !== "web") Haptics.selectionAsync();
    setDraft(draft.replace(/@[\p{L}]*$/u, `@${id} `));
  };

  return (
    <SafeAreaView edges={["bottom"]}>
      <View className="px-3 pb-1 pt-2">
        {picked ? (
          <Animated.View
            entering={FadeIn.duration(220)}
            className="mb-2 ml-1 flex-row"
          >
            <View>
              <Image
                source={{ uri: picked.uri }}
                style={{
                  width: 66,
                  height: 66,
                  borderRadius: 16,
                  borderWidth: StyleSheet.hairlineWidth,
                  borderColor: theme.hairline,
                }}
                contentFit="cover"
              />
              <Pressable
                onPress={clearPicked}
                hitSlop={10}
                style={{
                  position: "absolute",
                  top: -6,
                  right: -6,
                  width: 22,
                  height: 22,
                  borderRadius: 11,
                  backgroundColor: theme.base,
                  alignItems: "center",
                  justifyContent: "center",
                  borderWidth: StyleSheet.hairlineWidth,
                  borderColor: theme.hairline,
                }}
              >
                <X size={12} color={theme.text} strokeWidth={2.4} />
              </Pressable>
            </View>
          </Animated.View>
        ) : null}

        {suggestions.length > 0 ? (
          <Animated.View
            entering={FadeIn.duration(160)}
            className="mb-2"
            testID="mention-menu"
          >
            <Glass radius={22} intensity={70} elevated>
              <View className="py-1.5">
                {suggestions.map((id) => (
                  <Pressable
                    key={id}
                    onPress={() => insertMention(id)}
                    className="flex-row items-center px-3 py-2 active:opacity-60"
                    testID={`mention-${id}`}
                  >
                    <PersonaGlyph
                      persona={id}
                      size={30}
                      color={theme.persona[id]}
                    />
                    <Text
                      style={{
                        color: theme.text,
                        fontSize: 15,
                        fontWeight: "600",
                        marginLeft: 10,
                      }}
                    >
                      @{id}
                    </Text>
                    <Text
                      numberOfLines={1}
                      style={{
                        color: theme.textFaint,
                        fontSize: 12.5,
                        marginLeft: 8,
                        flex: 1,
                      }}
                    >
                      {persona(id).title}
                    </Text>
                  </Pressable>
                ))}
              </View>
            </Glass>
          </Animated.View>
        ) : null}

        <Glass radius={26} intensity={60} elevated>
          <View className="flex-row items-end px-2 py-2">
            <Pressable
              onPress={onPickImage}
              disabled={busy}
              hitSlop={8}
              className="h-9 w-9 items-center justify-center active:opacity-50"
            >
              <ImagePlus
                size={20}
                color={picked ? theme.accent : theme.textDim}
                strokeWidth={1.9}
              />
            </Pressable>

            {(
            <Pressable
              onPress={onToggleVote}
              disabled={busy}
              hitSlop={8}
              className="h-9 w-9 items-center justify-center active:opacity-50"
              style={{
                borderRadius: 18,
                backgroundColor: voteMode ? alpha(theme.accent, 0.16) : "transparent",
              }}
              testID="vote-mode-toggle"
            >
              <Vote
                size={19}
                color={voteMode ? theme.accent : theme.textDim}
                strokeWidth={1.9}
              />
            </Pressable>
            )}

            <TextInput
              value={draft}
              onChangeText={setDraft}
              editable={!busy}
              placeholder={t(
                grand
                  ? "grandPlaceholder"
                  : voteMode
                  ? "votePlaceholder"
                  : hasMessages
                  ? "councilReplyPlaceholder"
                  : "describePlaceholder",
              )}
              placeholderTextColor={theme.textFaint}
              multiline
              style={{
                flex: 1,
                color: theme.text,
                fontSize: 16,
                maxHeight: 110,
                paddingTop: Platform.OS === "ios" ? 8 : 4,
                paddingBottom: 8,
                paddingHorizontal: 6,
              }}
            />

            <Pressable
              onPress={onSend}
              disabled={!canSend}
              hitSlop={8}
              style={{
                width: 36,
                height: 36,
                borderRadius: 18,
                alignItems: "center",
                justifyContent: "center",
                backgroundColor: canSend
                  ? theme.accent
                  : alpha(theme.accent, 0.14),
              }}
              className="active:opacity-70"
            >
              {busy ? (
                <ActivityIndicator size="small" color={theme.onAccent} />
              ) : (
                <ArrowUp
                  size={19}
                  color={canSend ? theme.onAccent : theme.textFaint}
                  strokeWidth={2.6}
                />
              )}
            </Pressable>
          </View>
        </Glass>
      </View>
    </SafeAreaView>
  );
}
