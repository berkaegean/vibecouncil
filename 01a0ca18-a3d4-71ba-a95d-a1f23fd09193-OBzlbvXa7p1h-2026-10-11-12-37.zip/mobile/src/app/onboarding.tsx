import * as Haptics from "expo-haptics";
import { ArrowRight, Check } from "lucide-react-native";
import React, { useState } from "react";
import { Platform, Pressable, Text, View } from "react-native";
import Animated, { FadeIn } from "react-native-reanimated";
import { SafeAreaView } from "react-native-safe-area-context";

import {
  BirthFields,
  fromBirth,
  toBirth,
} from "@/components/council/BirthFields";
import { Glass } from "@/components/council/Glass";
import { NameField } from "@/components/council/NameField";
import { LANGUAGE_OPTIONS, useI18n } from "@/lib/council/i18n";
import { PERSONA_LIST, PersonaGlyph } from "@/lib/council/personas";
import { useCouncilStore, type Language } from "@/lib/council/store";
import { alpha } from "@/lib/council/theme";
import { useTheme } from "@/lib/council/useTheme";

const PICKER_COPY: Record<Language, { title: string; sub: string; cta: string }> = {
  en: { title: "Choose your language", sub: "Which language do you prefer?", cta: "Continue" },
  tr: { title: "Dilini seç", sub: "Hangi dili tercih ediyorsun?", cta: "Devam" },
  es: { title: "Elige tu idioma", sub: "¿Qué idioma prefieres?", cta: "Continuar" },
  de: { title: "Wähle deine Sprache", sub: "Welche Sprache bevorzugst du?", cta: "Weiter" },
  pt: { title: "Escolha seu idioma", sub: "Qual idioma você prefere?", cta: "Continuar" },
  fr: { title: "Choisis ta langue", sub: "Quelle langue préfères-tu ?", cta: "Continuer" },
};

export default function OnboardingScreen() {
  const theme = useTheme();
  const { t, up } = useI18n();
  const setBirth = useCouncilStore((s) => s.setBirth);
  const [value, setValue] = useState<Date>(() => fromBirth(null));
  const [name, setName] = useState<string>("");
  const [langChosen, setLangChosen] = useState<boolean>(false);
  const [consented, setConsented] = useState<boolean>(false);
  const language = useCouncilStore((s) => s.language);
  const setLanguage = useCouncilStore((s) => s.setLanguage);

  const pickLanguage = (lang: Language) => {
    if (Platform.OS !== "web") Haptics.selectionAsync();
    setLanguage(lang);
  };

  const canContinue = name.trim().length > 0 && consented;

  const onContinue = () => {
    if (!canContinue) return;
    if (Platform.OS !== "web")
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    // Guard flips → the router swaps to the tabs automatically.
    setBirth({ ...toBirth(value), name: name.trim() });
  };

  if (!langChosen) {
    const options = LANGUAGE_OPTIONS;
    const copy = PICKER_COPY[language];
    return (
      <SafeAreaView style={{ flex: 1 }}>
        <View className="flex-1 justify-center px-6">
          <Animated.View entering={FadeIn.duration(220)} className="items-center">
            <Text
              style={{
                color: theme.text,
                fontSize: 30,
                fontWeight: "200",
                letterSpacing: -1.2,
                textAlign: "center",
              }}
            >
              {copy.title}
            </Text>
            <Text
              style={{
                color: theme.textDim,
                fontSize: 15,
                textAlign: "center",
                marginTop: 10,
              }}
            >
              {copy.sub}
            </Text>
          </Animated.View>
          <Animated.View entering={FadeIn.delay(90).duration(220)} className="mt-9" style={{ gap: 12 }}>
            {options.map((o) => {
              const selected = o.value === language;
              return (
                <Pressable
                  key={o.value}
                  testID={`onb-language-${o.value}`}
                  onPress={() => pickLanguage(o.value)}
                  className="active:opacity-80"
                >
                  <Glass radius={22} intensity={60} elevated>
                    <View
                      style={{
                        flexDirection: "row",
                        alignItems: "center",
                        paddingVertical: 18,
                        paddingHorizontal: 20,
                        borderRadius: 22,
                        borderWidth: 1.5,
                        borderColor: selected ? theme.accent : "transparent",
                      }}
                    >
                      <Text style={{ fontSize: 26 }}>{o.flag}</Text>
                      <Text
                        style={{
                          color: theme.text,
                          fontSize: 18,
                          fontWeight: selected ? "600" : "400",
                          marginLeft: 14,
                          flex: 1,
                        }}
                      >
                        {o.label}
                      </Text>
                      {selected ? (
                        <Check size={20} color={theme.accent} strokeWidth={2.4} />
                      ) : null}
                    </View>
                  </Glass>
                </Pressable>
              );
            })}
          </Animated.View>
        </View>
        <View className="px-6 pb-4">
          <Pressable
            testID="onb-language-continue"
            onPress={() => setLangChosen(true)}
            className="active:opacity-80"
          >
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "center",
                backgroundColor: theme.accent,
                borderRadius: 999,
                paddingVertical: 17,
              }}
            >
              <Text
                style={{
                  color: theme.onAccent,
                  fontSize: 17,
                  fontWeight: "700",
                  marginRight: 8,
                  letterSpacing: -0.3,
                }}
              >
                {copy.cta}
              </Text>
              <ArrowRight size={17} color={theme.onAccent} strokeWidth={2.1} />
            </View>
          </Pressable>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={{ flex: 1 }}>
      <View className="flex-1 justify-center px-6">
        <Animated.View entering={FadeIn.duration(220)} className="items-center">
          <View className="flex-row" style={{ gap: 8 }}>
            {PERSONA_LIST.map((p) => (
              <View
                key={p.id}
                style={{
                  width: 36,
                  height: 36,
                  borderRadius: 18,
                  alignItems: "center",
                  justifyContent: "center",
                  backgroundColor: alpha(theme.accent, 0.08),
                  borderWidth: 1,
                  borderColor: theme.hairline,
                }}
              >
                <PersonaGlyph
                  persona={p.id}
                  size={36}
                  color={theme.persona[p.id]}
                />
              </View>
            ))}
          </View>

          <Text
            style={{
              color: theme.textFaint,
              fontSize: 10.5,
              letterSpacing: 3.4,
              marginTop: 34,
            }}
          >
            {up("VibeCouncil")}
          </Text>
          <Text
            style={{
              color: theme.text,
              fontSize: 34,
              fontWeight: "200",
              letterSpacing: -1.4,
              textAlign: "center",
              marginTop: 8,
            }}
          >
            {t("onbTitle")}
          </Text>
          <Text
            style={{
              color: theme.textDim,
              fontSize: 15.5,
              lineHeight: 22,
              textAlign: "center",
              marginTop: 12,
              maxWidth: 310,
            }}
          >
            {t("onbBody")}
          </Text>
        </Animated.View>

        <Animated.View
          entering={FadeIn.delay(90).duration(220)}
          className="mt-9"
        >
          <Glass radius={26} intensity={60} elevated style={{ marginBottom: 12 }}>
            <NameField value={name} onChange={setName} />
          </Glass>
          <Glass radius={26} intensity={60} elevated>
            <BirthFields value={value} onChange={setValue} />
          </Glass>
          <Text
            style={{
              color: theme.textFaint,
              fontSize: 12,
              textAlign: "center",
              marginTop: 12,
            }}
          >
            {t("onbPrivacy")}
          </Text>
          <Pressable
            testID="onb-ai-consent"
            onPress={() => {
              if (Platform.OS !== "web") Haptics.selectionAsync();
              setConsented((v) => !v);
            }}
            className="active:opacity-80"
            style={{ flexDirection: "row", alignItems: "center", marginTop: 14, paddingHorizontal: 4 }}
          >
            <View
              style={{
                width: 22,
                height: 22,
                borderRadius: 7,
                alignItems: "center",
                justifyContent: "center",
                borderWidth: 1.5,
                borderColor: consented ? theme.accent : theme.hairline,
                backgroundColor: consented ? theme.accent : "transparent",
              }}
            >
              {consented ? (
                <Check size={14} color={theme.onAccent} strokeWidth={3} />
              ) : null}
            </View>
            <Text
              style={{ color: theme.textDim, fontSize: 13, lineHeight: 18, marginLeft: 10, flex: 1 }}
            >
              {t("onbConsent")}
            </Text>
          </Pressable>
        </Animated.View>
      </View>

      <Animated.View
        entering={FadeIn.delay(170).duration(220)}
        className="px-6 pb-4"
      >
        <Pressable
          onPress={onContinue}
          disabled={!canContinue}
          className="active:opacity-80"
        >
          <View
            style={{
              opacity: canContinue ? 1 : 0.4,
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "center",
              backgroundColor: theme.accent,
              borderRadius: 999,
              paddingVertical: 17,
            }}
          >
            <ArrowRight size={17} color={theme.onAccent} strokeWidth={2.1} />
            <Text
              style={{
                color: theme.onAccent,
                fontSize: 17,
                fontWeight: "700",
                marginLeft: 8,
                letterSpacing: -0.3,
              }}
            >
              {t("onbCta")}
            </Text>
          </View>
        </Pressable>
      </Animated.View>
    </SafeAreaView>
  );
}
