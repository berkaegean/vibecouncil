import AsyncStorage from "@react-native-async-storage/async-storage";
import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";

import { DEFAULT_COUNCIL, type PersonaId } from "./personas";
import { readCrystals, writeCrystals } from "./secureCrystals";
import type { ThemeName } from "./theme";

export type Language = "tr" | "en" | "es" | "de" | "pt" | "fr";

export type ThreadKind = "council" | "dm";

export type ChatMessage = {
  id: string;
  /** "user" = the person, "persona" = a council member, "verdict" = the council's closing ruling, "vote" = a council poll */
  kind: "user" | "persona" | "verdict" | "vote";
  persona?: PersonaId;
  text: string;
  imageUri?: string;
  /** Only on "verdict" messages: symptoms the council diagnosed. */
  symptoms?: string[];
  /** Only on "vote" messages. */
  votes?: CouncilVote[];
  createdAt: number;
};

export type CouncilVote = { persona: PersonaId; vote: "yes" | "no"; reason: string };

/** Something the council learned about the user; lives only on this device. */
export type Memory = { id: string; text: string; createdAt: number };

export type DailyMessage = { date: string; persona: PersonaId; message: string; lang: Language };

export const MAX_MEMORIES = 30;

export type Thread = {
  id: string;
  kind: ThreadKind;
  /** Only set for 1-on-1 DM threads. */
  persona?: PersonaId;
  /** Council members chosen for a group session (1–4). */
  members?: PersonaId[];
  /** Grand Council: a one-shot session with all eight members. */
  grand?: boolean;
  title: string;
  /** True once the user renamed the chat; auto-titles stop overwriting it. */
  named?: boolean;
  messages: ChatMessage[];
  verdict?: string;
  createdAt: number;
  updatedAt: number;
};

export const STARTING_CRYSTALS = 5;

/** Astrological profile. date = "YYYY-MM-DD", time = "HH:mm". */
export type BirthProfile = { date: string; time: string; name?: string };

type CouncilState = {
  hydrated: boolean;
  crystals: number;
  threads: Thread[];
  themeName: ThemeName;
  birth: BirthProfile | null;
  language: Language;
  memories: Memory[];
  daily: DailyMessage | null;
  dailyReminder: boolean;
  /** "HH:mm", local time of the daily-message notification. */
  reminderTime: string;
  setReminderTime: (time: string) => void;
  addMemory: (text: string) => void;
  removeMemory: (id: string) => void;
  clearMemories: () => void;
  setDaily: (daily: DailyMessage) => void;
  setDailyReminder: (on: boolean) => void;
  setLanguage: (language: Language) => void;
  setBirth: (birth: BirthProfile) => void;
  setName: (name: string) => void;
  setHydrated: () => void;
  /** Internal: applies a crystals value already verified by secureCrystals, without re-signing it. */
  _setCrystalsFromSecureStore: (crystals: number) => void;
  setThemeName: (name: ThemeName) => void;
  toggleTheme: () => void;
  clearHistory: () => void;
  createThread: (kind: ThreadKind, persona?: PersonaId) => string;
  appendMessage: (threadId: string, message: ChatMessage) => void;
  patchThread: (
    threadId: string,
    patch: Partial<Pick<Thread, "title" | "named" | "verdict" | "members" | "grand">>,
  ) => void;
  deleteThread: (threadId: string) => void;
  /** Removes a thread the user opened but never wrote in (or named). */
  discardIfEmpty: (threadId: string) => void;
  spendCrystal: () => boolean;
  /** Spends `n` crystals at once, or none if the balance is short. */
  spendCrystals: (n: number) => boolean;
  grantCrystals: (amount: number) => void;
};

export const makeId = (): string =>
  `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 9)}`;

export const useCouncilStore = create<CouncilState>()(
  persist(
    (set, get) => ({
      hydrated: false,
      crystals: STARTING_CRYSTALS,
      threads: [],
      themeName: "pearlescent",
      birth: null,
      language: "en",
      memories: [],
      daily: null,
      dailyReminder: false,
      reminderTime: "09:00",
      setReminderTime: (reminderTime) => set({ reminderTime }),

      addMemory: (text) => {
        const clean = text.trim();
        const key = clean.toLocaleLowerCase("tr-TR");
        const existing = get().memories;
        if (!clean || existing.some((m) => m.text.toLocaleLowerCase("tr-TR") === key)) return;
        // Oldest memories fall off once the cap is reached.
        set({
          memories: [...existing, { id: makeId(), text: clean, createdAt: Date.now() }].slice(-MAX_MEMORIES),
        });
      },
      removeMemory: (id) => set({ memories: get().memories.filter((m) => m.id !== id) }),
      clearMemories: () => set({ memories: [] }),
      setDaily: (daily) => set({ daily }),
      setDailyReminder: (dailyReminder) => set({ dailyReminder }),

      setLanguage: (language) => set({ language }),

      // Keeps the saved name when only the date/time changes.
      setBirth: (birth) =>
        set({ birth: { ...birth, name: birth.name ?? get().birth?.name } }),

      setName: (name) => {
        const birth = get().birth;
        if (birth) set({ birth: { ...birth, name: name || undefined } });
      },

      setHydrated: () => set({ hydrated: true }),

      _setCrystalsFromSecureStore: (crystals) => set({ crystals }),

      setThemeName: (name) => set({ themeName: name }),

      toggleTheme: () =>
        set({
          themeName:
            get().themeName === "midnight" ? "pearlescent" : "midnight",
        }),

      clearHistory: () => set({ threads: [] }),

      createThread: (kind, persona) => {
        const now = Date.now();
        const thread: Thread = {
          id: makeId(),
          kind,
          persona,
          members: kind === "council" ? [...DEFAULT_COUNCIL] : undefined,
          title: kind === "dm" && persona ? persona : "Yeni Konsey",
          messages: [],
          createdAt: now,
          updatedAt: now,
        };
        set({ threads: [thread, ...get().threads] });
        return thread.id;
      },

      appendMessage: (threadId, message) =>
        set({
          threads: get().threads.map((t) =>
            t.id === threadId
              ? {
                  ...t,
                  messages: [...t.messages, message],
                  updatedAt: Date.now(),
                }
              : t,
          ),
        }),

      patchThread: (threadId, patch) =>
        set({
          threads: get().threads.map((t) =>
            t.id === threadId ? { ...t, ...patch, updatedAt: Date.now() } : t,
          ),
        }),

      deleteThread: (threadId) =>
        set({ threads: get().threads.filter((t) => t.id !== threadId) }),

      discardIfEmpty: (threadId) =>
        set({
          threads: get().threads.filter(
            (t) => t.id !== threadId || t.messages.length > 0 || t.named,
          ),
        }),

      spendCrystal: () => {
        const { crystals } = get();
        if (crystals <= 0) return false;
        const next = crystals - 1;
        set({ crystals: next });
        writeCrystals(next).catch(() => undefined);
        return true;
      },

      spendCrystals: (n) => {
        const { crystals } = get();
        if (crystals < n) return false;
        const next = crystals - n;
        set({ crystals: next });
        writeCrystals(next).catch(() => undefined);
        return true;
      },

      grantCrystals: (amount) => {
        const next = get().crystals + amount;
        set({ crystals: next });
        writeCrystals(next).catch(() => undefined);
      },
    }),
    {
      name: "vibecouncil-v1",
      storage: createJSONStorage(() => AsyncStorage),
      // `hydrated` is ephemeral — never persist it. `crystals` lives in SecureStore instead
      // (see secureCrystals.ts), signed against tampering, so it's excluded here.
      partialize: (state) => ({
        threads: state.threads,
        themeName: state.themeName,
        birth: state.birth,
        language: state.language,
        memories: state.memories,
        daily: state.daily,
        dailyReminder: state.dailyReminder,
        reminderTime: state.reminderTime,
      }),
      onRehydrateStorage: () => (state) => {
        readCrystals(STARTING_CRYSTALS)
          .then((crystals) => state?._setCrystalsFromSecureStore(crystals))
          .catch(() => undefined)
          .finally(() => state?.setHydrated());
      },
    },
  ),
);

export const useThread = (threadId: string | undefined): Thread | undefined =>
  useCouncilStore((s) => s.threads.find((t) => t.id === threadId));

/** Memory texts to send along with any AI request. */
export const memoryTexts = (): string[] =>
  useCouncilStore.getState().memories.map((m) => m.text);
