import * as Notifications from "expo-notifications";
import { Platform } from "react-native";

import { t } from "./i18n";

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowBanner: true,
    shouldShowList: true,
    shouldPlaySound: false,
    shouldSetBadge: false,
  }),
});

/**
 * Schedules the daily-message nudge at `time` ("HH:mm"), replacing any earlier one.
 * Asks for permission only when `ask` is set. Returns false without permission.
 */
export async function enableDailyReminder(time: string, ask = true): Promise<boolean> {
  if (Platform.OS === "web") return false;
  const current = await Notifications.getPermissionsAsync();
  const granted =
    current.granted || (ask && (await Notifications.requestPermissionsAsync()).granted);
  if (!granted) return false;
  const [hour = 9, minute = 0] = time.split(":").map(Number);
  await Notifications.cancelAllScheduledNotificationsAsync();
  await Notifications.scheduleNotificationAsync({
    content: { title: t("reminderTitle"), body: t("reminderBody"), sound: "default" },
    trigger: { type: Notifications.SchedulableTriggerInputTypes.DAILY, hour, minute },
  });
  return true;
}

export async function disableDailyReminder(): Promise<void> {
  if (Platform.OS === "web") return;
  await Notifications.cancelAllScheduledNotificationsAsync();
}
