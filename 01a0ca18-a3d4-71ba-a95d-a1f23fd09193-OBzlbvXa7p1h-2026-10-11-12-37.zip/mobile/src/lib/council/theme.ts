import type { PersonaId } from "./personas";

export type ThemeName = "pearlescent" | "midnight";

export type Palette = {
  name: ThemeName;
  /** Base canvas colour sitting under the mesh. */
  base: string;
  /** Slowly shifting mesh field colours. */
  mesh: string[];
  /** Translucent card fill. */
  glass: string;
  glassStrong: string;
  /** Hairline border — silver in light, iridescent in dark. */
  hairline: string;
  /** Top-edge light refraction on glass. */
  refraction: string;
  text: string;
  textDim: string;
  textFaint: string;
  /** Matte rose gold in light, silver in dark. */
  accent: string;
  accentSoft: string;
  onAccent: string;
  danger: string;
  blurTint: "light" | "dark";
  statusBar: "light" | "dark";
  persona: Record<PersonaId, string>;
};

/** "Opal & Amethyst" — the single light design system. */
export const PEARLESCENT: Palette = {
  name: "pearlescent",
  base: "#FFFFFF",
  mesh: ["#F4EEFF", "#F9F9FB", "#FFFFFF", "#EFE8FF"],
  glass: "rgba(255,255,255,0.70)",
  glassStrong: "rgba(255,255,255,0.82)",
  hairline: "rgba(138,43,226,0.40)",
  refraction: "rgba(255,255,255,0.95)",
  text: "#1C1C1E",
  textDim: "rgba(28,28,30,0.60)",
  textFaint: "rgba(28,28,30,0.36)",
  accent: "#7B61FF",
  accentSoft: "rgba(123,97,255,0.12)",
  onAccent: "#FFFFFF",
  danger: "#D0463B",
  blurTint: "light",
  statusBar: "dark",
  persona: {
    Nyx: "#8A2BE2",
    Astraea: "#7B61FF",
    Metis: "#6A4BD8",
    Harmonia: "#9B7BFF",
    Hecate: "#5B3FD9",
    Momus: "#A45BFF",
    Peitho: "#C04FD8",
    Nemesis: "#7A2BB8",
  },
};

/** "Amethyst Night" — dark companion keeping the same amethyst accent. */
export const MIDNIGHT: Palette = {
  name: "midnight",
  base: "#0E0B18",
  mesh: ["#1A1330", "#0E0B18", "#130F22", "#221640"],
  glass: "rgba(34,26,58,0.62)",
  glassStrong: "rgba(40,31,68,0.82)",
  hairline: "rgba(160,110,255,0.38)",
  refraction: "rgba(255,255,255,0.10)",
  text: "#F4F1FF",
  textDim: "rgba(244,241,255,0.64)",
  textFaint: "rgba(244,241,255,0.38)",
  accent: "#8E78FF",
  accentSoft: "rgba(142,120,255,0.16)",
  onAccent: "#FFFFFF",
  danger: "#FF6B5E",
  blurTint: "dark",
  statusBar: "light",
  persona: {
    Nyx: "#A55BFF",
    Astraea: "#8E78FF",
    Metis: "#8B6DF2",
    Harmonia: "#B09AFF",
    Hecate: "#7C62F0",
    Momus: "#B97BFF",
    Peitho: "#D66FEA",
    Nemesis: "#9A4DD6",
  },
};

export const PALETTES: Record<ThemeName, Palette> = {
  pearlescent: PEARLESCENT,
  midnight: MIDNIGHT,
};

/** Appends an 8-bit alpha suffix to a #RRGGBB colour. */
export const alpha = (hex: string, a: number): string =>
  `${hex}${Math.round(Math.min(1, Math.max(0, a)) * 255)
    .toString(16)
    .padStart(2, "0")}`;
