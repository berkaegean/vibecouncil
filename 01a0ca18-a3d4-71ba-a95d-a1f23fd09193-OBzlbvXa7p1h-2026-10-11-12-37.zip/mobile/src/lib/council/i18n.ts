import { de as deLocale, enUS, es as esLocale, fr as frLocale, ptBR, tr as trLocale } from "date-fns/locale";

import { dePersona, deSigns, deStrings } from "./locales/de";
import { esPersona, esSigns, esStrings } from "./locales/es";
import { frPersona, frSigns, frStrings } from "./locales/fr";
import { ptPersona, ptSigns, ptStrings } from "./locales/pt";

import type { PersonaId } from "./personas";
import { useCouncilStore, type Language } from "./store";

/**
 * Locale-correct upper-casing. CSS/`className="uppercase"` uses the default
 * locale and turns Turkish "i" into "I" instead of "İ" — always use this.
 */
export const upper = (text: string, lang: Language): string =>
  text.toLocaleUpperCase(LOCALE_TAG[lang]);

export const LOCALE_TAG: Record<Language, string> = {
  tr: "tr-TR",
  en: "en-US",
  es: "es-ES",
  de: "de-DE",
  pt: "pt-BR",
  fr: "fr-FR",
};

/** Language picker options, shown in each language's own name. */
export const LANGUAGE_OPTIONS: { value: Language; label: string; flag: string }[] = [
  { value: "en", label: "English", flag: "🇬🇧" },
  { value: "tr", label: "Türkçe", flag: "🇹🇷" },
  { value: "es", label: "Español", flag: "🇪🇸" },
  { value: "de", label: "Deutsch", flag: "🇩🇪" },
  { value: "pt", label: "Português", flag: "🇧🇷" },
  { value: "fr", label: "Français", flag: "🇫🇷" },
];

const SIGNS: Record<"tr" | "en", string[]> = {
  tr: [
    "Oğlak",
    "Kova",
    "Balık",
    "Koç",
    "Boğa",
    "İkizler",
    "Yengeç",
    "Aslan",
    "Başak",
    "Terazi",
    "Akrep",
    "Yay",
  ],
  en: [
    "Capricorn",
    "Aquarius",
    "Pisces",
    "Aries",
    "Taurus",
    "Gemini",
    "Cancer",
    "Leo",
    "Virgo",
    "Libra",
    "Scorpio",
    "Sagittarius",
  ],
};
// Start day of each sign within its month, indexed from Capricorn (Dec 22).
const SIGN_STARTS: [number, number][] = [
  [1, 20],
  [2, 19],
  [3, 21],
  [4, 20],
  [5, 21],
  [6, 21],
  [7, 23],
  [8, 23],
  [9, 23],
  [10, 23],
  [11, 22],
  [12, 22],
];

/** Sun sign name from a "YYYY-MM-DD" birth date. */
export function sunSign(date: string, lang: Language): string {
  const [, m, d] = date.split("-").map(Number);
  let idx = 0; // Capricorn
  SIGN_STARTS.forEach(([sm, sd], i) => {
    if (m! > sm || (m === sm && d! >= sd)) idx = (i + 1) % 12;
  });
  const all: Record<Language, string[]> = { ...SIGNS, es: esSigns, de: deSigns, pt: ptSigns, fr: frSigns };
  return all[lang][idx]!;
}

export type PersonaCopy = { title: string; tagline: string; bio: string };

const tr = {
  // Home
  homeHello: "Selam, {sign}",
  homeHelloName: "Selam {name}",
  nameLabel: "Adın",
  namePlaceholder: "Sana nasıl hitap edelim?",
  nameSection: "Profil",
  homeHelloNoSign: "Selam",
  homeEnergy: "Günün Enerjisi",
  moonToday: "Bugün ay",
  moonLit: "%{n} aydınlık",
  moonNew: "Yeni Ay",
  moonWaxingCrescent: "Büyüyen Hilal",
  moonFirstQuarter: "İlk Dördün",
  moonWaxingGibbous: "Büyüyen Ay",
  moonFull: "Dolunay",
  moonWaningGibbous: "Küçülen Ay",
  moonLastQuarter: "Son Dördün",
  moonWaningCrescent: "Küçülen Hilal",
  homeCta: "Konseyi Topla",
  homePresets: "Hızlı Konseyler",
  homeMembers: "Konsey Üyeleri",
  homeRecent: "Son Sohbetler",
  homeSeeAll: "Tümü",
  presetOutfit: "Kombin Kontrolü",
  presetOutfitSub: "Stil ve imaj yargısı",
  presetText: "Mesaj Analizi",
  presetTextSub: "Kırmızı bayrak avı",
  presetCosmic: "Kozmik Okuma",
  presetCosmicSub: "Yıldızlar ne diyor?",
  presetRizz: "Flört Rehberi",
  presetRizzSub: "Doğru hamle ne?",
  daily0: "Bugün sezgilerin keskin. İlk hissine güven.",
  daily1: "Sessiz kalmak bugün en güçlü hamlen olabilir.",
  daily2: "Işığın parlıyor; görünür olmaktan çekinme.",
  daily3: "Eski bir konu geri dönebilir. Sınırlarını koru.",
  daily4: "Küçük bir risk, büyük bir kapı açabilir.",
  daily5: "Bugün cevapları değil, soruları dinle.",
  daily6: "Enerjin yüksek ama sabır kazandırır.",
  // Common
  cancel: "Vazgeç",
  delete: "Sil",
  genericError: "Bir şeyler ters gitti",
  networkError: "Bağlantı kurulamadı, tekrar dene",
  chatNotFound: "Sohbet bulunamadı",
  council: "Konsey",
  // Tabs
  tabChats: "Sohbetler",
  tabCouncil: "Konsey",
  tabSettings: "Ayarlar",
  // Not found
  notFoundTitle: "Hata!",
  notFoundText: "Bu ekran mevcut değil.",
  notFoundHome: "Ana ekrana dön",
  // Onboarding
  onbTitle: "Yıldız haritanı çıkarıyoruz",
  onbBody:
    "Konseyin seni tanıması için doğum tarihini ve saatini gir. Astraea yorumlarında bunu kullanacak.",
  onbPrivacy: "✨ Konseyin sana cevap verebilmesi için mesajların OpenAI'ın yapay zekâsına iletilir. Bilgilerin bu telefonda kalır.",
  onbConsent: "Kabul ediyorum",
  onbCta: "Konseye Katıl",
  // Birth fields
  birthDate: "Doğum Tarihi",
  birthTime: "Doğum Saati",
  datePlaceholder: "YYYY-AA-GG",
  timePlaceholder: "SS:DD",
  // Paywall
  perk1: "Büyük Konsey: 8 karakter bir arada",
  perk2: "Konsey Oylaması ve Nihai Karar",
  perk3: "Karakterlerle birebir özel sohbet",
  perk4: "Fotoğraf yorumu ve red flag teşhisi",
  storeUnavailableTitle: "Mağaza şu an kullanılamıyor",
  storeUnavailableBody:
    "Kristal paketi henüz yüklenemedi. Lütfen biraz sonra tekrar dene.",
  purchaseFailedTitle: "Satın alma tamamlanamadı",
  purchaseFailedBody: "Bir sorun oluştu, tekrar dene.",
  outOfCrystals: "Kristalin bitti",
  upgradeCrystals: "Kristal yükle",
  paywallSubtitle: "Her konsey mesajı 1, Büyük Konsey mesajı 2 kristal.",
  crystalPack: "Kristal Paketi",
  popularPack: "En popüler",
  crystalsAmount: "{n} Kristal",
  processing: "İşleniyor…",
  buyCrystals: "{n} Kristal Al · {price}",
  notNow: "Şimdi değil",
  // Chats
  chatsEyebrow: "Mitolojik Meclis",
  chatsTitle: "Sohbetler",
  deleteChatTitle: "Sohbeti sil",
  deleteChatBody: "Bu sohbet kalıcı olarak silinecek.",
  newCouncil: "Yeni Konsey",
  imageSent: "Görsel gönderildi",
  noMessagesYet: "Henüz mesaj yok",
  emptyTitle: "Konsey seni bekliyor",
  emptyBody:
    "Bir ekran görüntüsü yükle, dört antik ses durumu yargılasın. Ya da Konsey sekmesinden biriyle tek tek konuş.",
  // Roster
  rosterEyebrow: "Sekiz Elit Ses",
  rosterTitle: "Konsey",
  rosterBody:
    "Birine dokun, birebir konuşmaya başla.",
  rosterFooter:
    "4 tanesini aynı anda konuşturmak için Sohbetler sekmesinden konsey topla.",
  sendMessage: "Mesaj at",
  // Settings
  settingsEyebrow: "Tercihler",
  settingsTitle: "Ayarlar",
  crystalBalance: "Kristal Bakiyen",
  store: "Mağaza",
  crystalInfo: "Konseye ve karakterlere gönderdiğin her mesaj 1 kristal.",
  languageSection: "Dil / Language",
  themeSection: "Görünüm",
  themeLight: "Açık",
  themeDark: "Karanlık",
  birthChart: "Yıldız Haritan",
  birthChartNote: "Astraea yorumlarında bu bilgiyi kullanır.",
  dataSection: "Veriler",
  clearHistory: "Sohbet geçmişini sil",
  savedChatsOne: "{n} sohbet kayıtlı",
  savedChatsMany: "{n} sohbet kayıtlı",
  noSavedChats: "Kayıtlı sohbet yok",
  clearAllTitle: "Tüm sohbetleri sil",
  clearAllBodyOne: "{n} sohbet kalıcı olarak silinecek. Kristallerin korunur.",
  clearAllBodyMany: "{n} sohbet kalıcı olarak silinecek. Kristallerin korunur.",
  clearAllConfirm: "Hepsini sil",
  footer: "VibeCouncil · Verilerini saklamıyoruz, satmıyoruz",
  termsOfUse: "Kullanım Koşulları",
  privacyPolicy: "Gizlilik Politikası",
  // Council chat
  councilGathering: "Konsey toplanıyor…",
  crystalRefunded: "Kristalin iade edildi.",
  councilDone: "Konsey kararını verdi. Yeni bir durum için yeni konsey topla.",
  chooseCouncil: "Konseyini Seç",
  chooseCouncilBody: "En fazla 4 üye seç, sonra görsel yükleyip durumu anlat.",
  describePlaceholder: "Durumu açıkla…",
  councilReplyPlaceholder: "Konseye yaz…",
  shareSignature: "Konsey",
  verdictLabel: "Konsey Kararı",
  finalVerdict: "Nihai Karar",
  detectedSymptoms: "Tespit Edilen Semptomlar",
  endSession: "Kararı Açıkla",
  endSessionHint: "Oturumu sonlandır ve konseyin ortak kararını al.",
  verdictPending: "Konsey müzakere ediyor…",
  verdictClose: "Kapat",
  verdictShare: "Paylaş",
  sessionClosed: "Oturum kapandı. Karar kesindir.",
  verdictConfirmTitle: "Konsey oturumu kapatıyor",
  verdictConfirmBody: "Karar açıklandıktan sonra bu oturuma devam edemezsin.",
  verdictConfirmCancel: "Vazgeç",
  newSession: "Yeni Oturum Başlat",
  voteLabel: "Konsey Oylaması",
  grandTitle: "Büyük Konsey",
  grandSub: "8 karakterin hepsi · mesaj başı 2 kristal",
  grandBody: "Sekiz karakterin hepsi toplanır. Her mesaj ve oylama 2 kristal; en az 4 karakter cevap verir, \"herkes\" dersen hepsi konuşur.",
  grandPlaceholder: "Büyük Konsey'e sorunu sor…",
  grandCost: "mesaj başı 2 kristal",
  voteYes: "evet",
  voteNo: "hayır",
  voteYesUp: "EVET",
  voteNoUp: "HAYIR",
  voteMode: "Oylama",
  votePlaceholder: "Konseye evet/hayır sorusu sor…",
  voteShare: "Paylaş",
  shareCta: "Sen de konseye sor · VibeCouncil",
  dailyFrom: "Bugünün mesajı · {name}",
  memorySection: "Konseyin Hafızası",
  memoryEmpty: "Sohbet ettikçe konsey seninle ilgili önemli şeyleri hatırlayacak. Hepsi sadece bu telefonda saklanır.",
  memoryHint: "Bunlar yalnızca bu cihazda saklanır. Silmek için dokun.",
  memoryCountOne: "{n} anı kayıtlı",
  memoryCountMany: "{n} anı kayıtlı",
  memoryNone: "Henüz bir şey hatırlamıyor",
  memoryDeleteTitle: "Bu anı silinsin mi?",
  memoryDeleteBody: "Konsey bunu artık hatırlamayacak.",
  memoryClearTitle: "Tüm hafıza silinsin mi?",
  memoryClearBody: "Konseyin seninle ilgili hatırladığı her şey kalıcı olarak silinecek.",
  memoryClear: "Hafızayı temizle",
  reminderSection: "Bildirimler",
  reminderDaily: "Günün mesajı hatırlatıcısı",
  reminderSub: "Her gün {time}",
  reminderTimeLabel: "Saat",
  reminderTitle: "Konseyin bugünkü mesajı hazır",
  reminderBody: "Bugün sana ne söyleyecekler? Hemen bak.",
  // DM
  dmIntro: "{tagline}. Sor, çekinme.",
  dmPlaceholder: "{name} ile konuş…",
  typing: "{name} yazıyor…",
  renameTitle: "Sohbeti İsimlendir",
  renamePlaceholder: "Sohbet adı",
  renameSave: "Kaydet",
  renameCancel: "Vazgeç",
  dmVerdictPending: "{name} karar veriyor…",
  dmDecide: "Karar Ver",
  dmDone: "{name} kararını verdi.",
} satisfies Record<string, string>;

export type TKey = keyof typeof tr;

const en: Record<TKey, string> = {
  // Home
  homeHello: "Hey, {sign}",
  homeHelloName: "Hey {name}",
  nameLabel: "Your name",
  namePlaceholder: "What should we call you?",
  nameSection: "Profile",
  homeHelloNoSign: "Hey there",
  homeEnergy: "Today's Energy",
  moonToday: "Moon today",
  moonLit: "{n}% lit",
  moonNew: "New Moon",
  moonWaxingCrescent: "Waxing Crescent",
  moonFirstQuarter: "First Quarter",
  moonWaxingGibbous: "Waxing Gibbous",
  moonFull: "Full Moon",
  moonWaningGibbous: "Waning Gibbous",
  moonLastQuarter: "Last Quarter",
  moonWaningCrescent: "Waning Crescent",
  homeCta: "Summon the Council",
  homePresets: "Quick Councils",
  homeMembers: "Council Members",
  homeRecent: "Recent Chats",
  homeSeeAll: "All",
  presetOutfit: "Outfit Check",
  presetOutfitSub: "Style and image verdict",
  presetText: "Text Analysis",
  presetTextSub: "Red flag hunt",
  presetCosmic: "Cosmic Reading",
  presetCosmicSub: "What do the stars say?",
  presetRizz: "Dating Guide",
  presetRizzSub: "What's the right move?",
  daily0: "Your intuition is sharp today. Trust your first feeling.",
  daily1: "Staying silent may be your strongest move today.",
  daily2: "You're glowing; don't shy away from being seen.",
  daily3: "An old issue may resurface. Guard your boundaries.",
  daily4: "A small risk could open a big door.",
  daily5: "Today, listen to the questions, not the answers.",
  daily6: "Your energy is high, but patience pays off.",
  cancel: "Cancel",
  delete: "Delete",
  genericError: "Something went wrong",
  networkError: "Couldn't connect, please try again",
  chatNotFound: "Chat not found",
  council: "Council",
  tabChats: "Chats",
  tabCouncil: "Council",
  tabSettings: "Settings",
  notFoundTitle: "Oops!",
  notFoundText: "This screen doesn't exist.",
  notFoundHome: "Go to home screen",
  onbTitle: "Mapping your stars",
  onbBody:
    "Enter your birth date and time so the council can get to know you. Astraea will use it in her readings.",
  onbPrivacy: "✨ So the council can answer you, your messages are passed to OpenAI's AI. Your details stay on this phone.",
  onbConsent: "I agree",
  onbCta: "Join the Council",
  birthDate: "Birth Date",
  birthTime: "Birth Time",
  datePlaceholder: "YYYY-MM-DD",
  timePlaceholder: "HH:MM",
  perk1: "Grand Council: all 8 members at once",
  perk2: "Council Votes and the Final Verdict",
  perk3: "Private one-on-one chats with members",
  perk4: "Photo readings and red-flag diagnosis",
  storeUnavailableTitle: "Store unavailable right now",
  storeUnavailableBody:
    "The crystal pack couldn't be loaded yet. Please try again in a moment.",
  purchaseFailedTitle: "Purchase couldn't be completed",
  purchaseFailedBody: "Something went wrong, please try again.",
  outOfCrystals: "You're out of crystals",
  upgradeCrystals: "Top up crystals",
  paywallSubtitle: "Each council message is 1 crystal, Grand Council is 2.",
  crystalPack: "Crystal Pack",
  popularPack: "Most popular",
  crystalsAmount: "{n} Crystals",
  processing: "Processing…",
  buyCrystals: "Buy {n} Crystals · {price}",
  notNow: "Not now",
  chatsEyebrow: "Mythic Assembly",
  chatsTitle: "Chats",
  deleteChatTitle: "Delete chat",
  deleteChatBody: "This chat will be permanently deleted.",
  newCouncil: "New Council",
  imageSent: "Image sent",
  noMessagesYet: "No messages yet",
  emptyTitle: "The council awaits",
  emptyBody:
    "Upload a screenshot and let four ancient voices judge the situation. Or talk to one of them in the Council tab.",
  rosterEyebrow: "Eight Elite Voices",
  rosterTitle: "Council",
  rosterBody: "Tap one to start a private chat.",
  rosterFooter:
    "To hear 4 of them at once, gather a council from the Chats tab.",
  sendMessage: "Message",
  settingsEyebrow: "Preferences",
  settingsTitle: "Settings",
  crystalBalance: "Crystal Balance",
  store: "Store",
  crystalInfo: "Each message to the council or a persona costs 1 crystal.",
  languageSection: "Dil / Language",
  themeSection: "Appearance",
  themeLight: "Light",
  themeDark: "Dark",
  birthChart: "Your Birth Chart",
  birthChartNote: "Astraea uses this in her readings.",
  dataSection: "Data",
  clearHistory: "Clear chat history",
  savedChatsOne: "{n} chat saved",
  savedChatsMany: "{n} chats saved",
  noSavedChats: "No saved chats",
  clearAllTitle: "Delete all chats",
  clearAllBodyOne:
    "{n} chat will be permanently deleted. Your crystals are kept.",
  clearAllBodyMany:
    "{n} chats will be permanently deleted. Your crystals are kept.",
  clearAllConfirm: "Delete all",
  footer: "VibeCouncil · We don't store or sell your data",
  termsOfUse: "Terms of Use",
  privacyPolicy: "Privacy Policy",
  councilGathering: "The council is gathering…",
  crystalRefunded: "Your crystal was refunded.",
  councilDone:
    "The council has spoken. Gather a new council for a new situation.",
  chooseCouncil: "Choose Your Council",
  chooseCouncilBody:
    "Pick up to 4 members, then upload an image and describe the situation.",
  describePlaceholder: "Describe the situation…",
  councilReplyPlaceholder: "Message the council…",
  shareSignature: "The Council",
  verdictLabel: "Council Verdict",
  finalVerdict: "Final Ruling",
  detectedSymptoms: "Detected Symptoms",
  endSession: "Reveal Verdict",
  endSessionHint: "Close the session and get the council's joint ruling.",
  verdictPending: "The council is deliberating…",
  verdictClose: "Close",
  verdictShare: "Share",
  sessionClosed: "Session closed. The ruling is final.",
  verdictConfirmTitle: "The council is closing the session",
  verdictConfirmBody: "Once the verdict is revealed, you can't continue this session.",
  verdictConfirmCancel: "Cancel",
  newSession: "Start New Session",
  voteLabel: "Council Vote",
  grandTitle: "Grand Council",
  grandSub: "All 8 members · 2 crystals per message",
  grandBody: "All eight members gather. Each message or vote costs 2 crystals; at least 4 reply, say \"everyone\" and they all speak.",
  grandPlaceholder: "Ask the Grand Council…",
  grandCost: "2 crystals per message",
  voteYes: "yes",
  voteNo: "no",
  voteYesUp: "YES",
  voteNoUp: "NO",
  voteMode: "Vote",
  votePlaceholder: "Ask the council a yes/no question…",
  voteShare: "Share",
  shareCta: "Ask your own council · VibeCouncil",
  dailyFrom: "Today's message from {name}",
  memorySection: "Council Memory",
  memoryEmpty: "As you chat, the council will remember important things about you. It all stays on this phone.",
  memoryHint: "Stored only on this device. Tap to delete.",
  memoryCountOne: "{n} memory saved",
  memoryCountMany: "{n} memories saved",
  memoryNone: "Nothing remembered yet",
  memoryDeleteTitle: "Delete this memory?",
  memoryDeleteBody: "The council will no longer remember this.",
  memoryClearTitle: "Clear all memory?",
  memoryClearBody: "Everything the council remembers about you will be permanently deleted.",
  memoryClear: "Clear memory",
  reminderSection: "Notifications",
  reminderDaily: "Daily message reminder",
  reminderSub: "Every day at {time}",
  reminderTimeLabel: "Time",
  reminderTitle: "The council's message is ready",
  reminderBody: "What will they tell you today? Take a look.",
  dmIntro: "{tagline}. Ask away.",
  dmPlaceholder: "Message {name}…",
  typing: "{name} is typing…",
  renameTitle: "Name this chat",
  renamePlaceholder: "Chat name",
  renameSave: "Save",
  renameCancel: "Cancel",
  dmVerdictPending: "{name} is deciding…",
  dmDecide: "Decide",
  dmDone: "{name} has made the call.",
};

export const STRINGS: Record<Language, Record<TKey, string>> = {
  tr,
  en,
  es: esStrings,
  de: deStrings,
  pt: ptStrings,
  fr: frStrings,
};

const BASE_PERSONA_COPY: Record<"tr" | "en", Record<PersonaId, PersonaCopy>> = {
  tr: {
    Nyx: {
      title: "Görsel Yargıç",
      tagline: "Acımasız stil ve estetik",
      bio: "Kombinine, ışığına, pozuna acımadan bakar. Görmek istemediğin şeyi tek cümlede söyler.",
    },
    Astraea: {
      title: "Kozmik Hizalanma",
      tagline: "Karmik frekans okuması",
      bio: "Gezegen geçişleri, enerji alanları ve karmik döngüler üzerinden okur.",
    },
    Metis: {
      title: "Soğuk Stratejist",
      tagline: "Güç hamleleri ve taktik",
      bio: "Duygu yok, oyun teorisi var. Sana atacağın somut adımı söyler.",
    },
    Harmonia: {
      title: "Dengeleyici",
      tagline: "Şifalı bakış, yumuşak kapanış",
      bio: "Darbeleri yumuşatır, hepsini insani bir yere bağlar. Ama yalan söylemez.",
    },
    Hecate: {
      title: "Dedektif",
      tagline: "Kırmızı bayraklar ve yalanlar",
      bio: "Satır aralarını okur. Tutarsızlığı, yalanı ve kırmızı bayrağı ilk o yakalar.",
    },
    Momus: {
      title: "Trol",
      tagline: "İroni, roast, komik altyazı",
      bio: "Her şeyle dalga geçer. Seni yerden yere vurur ama güldürerek.",
    },
    Peitho: {
      title: "Cazibe Ustası",
      tagline: "Rizz, karizma ve baştan çıkarma",
      bio: "Karizmanı ölçer, cazibeni parlatır. Ne yazacağını, nasıl duracağını bilir.",
    },
    Nemesis: {
      title: "İntikamcı",
      tagline: "Küçük intikamlar, toksik hamleler",
      bio: "Affetmez, unutmaz. Sana en tatlı, en küçük intikamı fısıldar.",
    },
  },
  en: {
    Nyx: {
      title: "Visual Judge",
      tagline: "Ruthless style and aesthetics",
      bio: "Looks at your outfit, lighting and pose without mercy. Says what you don't want to see in one sentence.",
    },
    Astraea: {
      title: "Cosmic Alignment",
      tagline: "Karmic frequency reading",
      bio: "Reads through planetary transits, energy fields and karmic cycles.",
    },
    Metis: {
      title: "Cold Strategist",
      tagline: "Power moves and tactics",
      bio: "No feelings, just game theory. Tells you the concrete move to make.",
    },
    Harmonia: {
      title: "The Balancer",
      tagline: "Healing view, gentle closure",
      bio: "Softens the blows and ties it all back to something human. But never lies.",
    },
    Hecate: {
      title: "The Detective",
      tagline: "Red flags and lies",
      bio: "Reads between the lines. First to catch inconsistencies, lies and red flags.",
    },
    Momus: {
      title: "The Troll",
      tagline: "Irony, roasts, funny captions",
      bio: "Mocks everything. Knocks you flat, but makes you laugh doing it.",
    },
    Peitho: {
      title: "Master of Charm",
      tagline: "Rizz, charisma and seduction",
      bio: "Reads your charisma and sharpens your pull. Knows what to text and how to carry yourself.",
    },
    Nemesis: {
      title: "The Avenger",
      tagline: "Petty revenge, toxic moves",
      bio: "Never forgives, never forgets. Whispers the sweetest, pettiest revenge to you.",
    },
  },
};

export const PERSONA_COPY: Record<Language, Record<PersonaId, PersonaCopy>> = {
  ...BASE_PERSONA_COPY,
  es: esPersona,
  de: dePersona,
  pt: ptPersona,
  fr: frPersona,
};

const DATE_LOCALES = { tr: trLocale, en: enUS, es: esLocale, de: deLocale, pt: ptBR, fr: frLocale };

/** Replaces `{name}` placeholders. */
const fill = (text: string, vars?: Record<string, string | number>): string =>
  vars
    ? text.replace(/\{(\w+)\}/g, (_, k: string) => String(vars[k] ?? ""))
    : text;

export const translate = (
  lang: Language,
  key: TKey,
  vars?: Record<string, string | number>,
) => fill(STRINGS[lang][key], vars);

/** Non-hook access for use outside React (alerts in callbacks, api errors). */
export const t = (key: TKey, vars?: Record<string, string | number>): string =>
  translate(useCouncilStore.getState().language, key, vars);

export function useI18n() {
  const lang = useCouncilStore((s) => s.language);
  return {
    lang,
    t: (key: TKey, vars?: Record<string, string | number>) =>
      translate(lang, key, vars),
    up: (text: string) => upper(text, lang),
    persona: (id: PersonaId) => PERSONA_COPY[lang][id],
    dateLocale: DATE_LOCALES[lang],
  };
}
