const SYNODIC = 29.530588853;
/** A known new moon: 2000-01-06 18:14 UTC. */
const REF_NEW_MOON = Date.UTC(2000, 0, 6, 18, 14);

export type MoonPhaseKey =
  | "moonNew"
  | "moonWaxingCrescent"
  | "moonFirstQuarter"
  | "moonWaxingGibbous"
  | "moonFull"
  | "moonWaningGibbous"
  | "moonLastQuarter"
  | "moonWaningCrescent";

const KEYS: MoonPhaseKey[] = [
  "moonNew",
  "moonWaxingCrescent",
  "moonFirstQuarter",
  "moonWaxingGibbous",
  "moonFull",
  "moonWaningGibbous",
  "moonLastQuarter",
  "moonWaningCrescent",
];

/** Moon phase computed on-device. `phase` is 0 (new) → 0.5 (full) → 1. */
export function moonPhase(date: Date = new Date()) {
  const days = (date.getTime() - REF_NEW_MOON) / 86400000;
  const phase = (((days / SYNODIC) % 1) + 1) % 1;
  const illumination = (1 - Math.cos(2 * Math.PI * phase)) / 2;
  const key = KEYS[Math.round(phase * 8) % 8]!;
  return { phase, illumination, key };
}
