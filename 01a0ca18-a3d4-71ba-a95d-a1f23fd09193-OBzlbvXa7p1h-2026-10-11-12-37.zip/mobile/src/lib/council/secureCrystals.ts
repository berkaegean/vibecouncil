import * as Crypto from 'expo-crypto';
import * as SecureStore from 'expo-secure-store';

/**
 * Crystals are kept in SecureStore (iOS Keychain / Android Keystore) instead of
 * AsyncStorage, and signed with a per-install secret so a tampered value (e.g. someone
 * editing the raw storage file) fails verification and gets reset instead of trusted.
 */
const SECRET_KEY = 'vibecouncil_credit_secret_v1';
const CRYSTALS_KEY = 'vibecouncil_credits_v1';

async function getOrCreateSecret(): Promise<string> {
  const existing = await SecureStore.getItemAsync(SECRET_KEY);
  if (existing) return existing;
  const bytes = await Crypto.getRandomBytesAsync(32);
  const secret = Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
  await SecureStore.setItemAsync(SECRET_KEY, secret);
  return secret;
}

async function sign(value: number, secret: string): Promise<string> {
  return Crypto.digestStringAsync(Crypto.CryptoDigestAlgorithm.SHA256, `${value}:${secret}`);
}

export async function readCrystals(fallback: number): Promise<number> {
  const secret = await getOrCreateSecret();
  const raw = await SecureStore.getItemAsync(CRYSTALS_KEY);
  if (!raw) {
    await writeCrystals(fallback);
    return fallback;
  }
  try {
    const parsed = JSON.parse(raw) as { value: number; sig: string };
    const expected = await sign(parsed.value, secret);
    if (
      parsed.sig !== expected ||
      typeof parsed.value !== 'number' ||
      !Number.isFinite(parsed.value) ||
      parsed.value < 0
    ) {
      await writeCrystals(fallback);
      return fallback;
    }
    return parsed.value;
  } catch {
    await writeCrystals(fallback);
    return fallback;
  }
}

export async function writeCrystals(value: number): Promise<void> {
  const secret = await getOrCreateSecret();
  const sig = await sign(value, secret);
  await SecureStore.setItemAsync(CRYSTALS_KEY, JSON.stringify({ value, sig }));
}
