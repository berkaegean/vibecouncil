import React from "react";
import { Image } from "expo-image";

export const PERSONA_IDS = [
  "Nyx",
  "Astraea",
  "Metis",
  "Harmonia",
  "Hecate",
  "Momus",
  "Peitho",
  "Nemesis",
] as const;
export type PersonaId = (typeof PERSONA_IDS)[number];

export type PersonaMeta = {
  id: PersonaId;
};

export const PERSONAS: Record<PersonaId, PersonaMeta> = {
  Nyx: {
    id: "Nyx",
  },
  Astraea: {
    id: "Astraea",
  },
  Metis: {
    id: "Metis",
  },
  Harmonia: {
    id: "Harmonia",
  },
  Hecate: {
    id: "Hecate",
  },
  Momus: {
    id: "Momus",
  },
  Peitho: {
    id: "Peitho",
  },
  Nemesis: {
    id: "Nemesis",
  },
};

/** The classic four — default members of a new council. */
export const DEFAULT_COUNCIL: PersonaId[] = [
  "Nyx",
  "Astraea",
  "Metis",
  "Harmonia",
];
export const MAX_COUNCIL = 4;

export const PERSONA_LIST: PersonaMeta[] = PERSONA_IDS.map(
  (id) => PERSONAS[id],
);

const PERSONA_IMAGES: Record<PersonaId, number> = {
  Nyx: require("../../../assets/personas/nyx.jpg"),
  Astraea: require("../../../assets/personas/astraea.jpg"),
  Metis: require("../../../assets/personas/metis.jpg"),
  Harmonia: require("../../../assets/personas/harmonia.jpg"),
  Hecate: require("../../../assets/personas/hecate.jpg"),
  Momus: require("../../../assets/personas/momus.jpg"),
  Peitho: require("../../../assets/personas/peitho.jpg"),
  Nemesis: require("../../../assets/personas/nemesis.jpg"),
};

type GlyphProps = {
  persona: PersonaId;
  size?: number;
  /** Ring colour around the portrait. */
  color?: string;
  /** Kept for call-site compatibility with the old vector sigils. */
  strokeWidth?: number;
};

/** Circular persona portrait. */
export function PersonaGlyph({ persona, size = 24, color }: GlyphProps) {
  return (
    <Image
      source={PERSONA_IMAGES[persona]}
      contentFit="cover"
      style={{
        width: size,
        height: size,
        borderRadius: size / 2,
        backgroundColor: "#FFFFFF",
        borderWidth: color ? 1 : 0,
        borderColor: color,
      }}
    />
  );
}
