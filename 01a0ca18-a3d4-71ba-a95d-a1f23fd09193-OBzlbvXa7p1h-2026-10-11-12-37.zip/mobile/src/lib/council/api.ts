import { fetch } from "expo/fetch";

import { t } from "./i18n";
import type { PersonaId } from "./personas";
import type { BirthProfile, CouncilVote, Language } from "./store";

const baseUrl = process.env.EXPO_PUBLIC_BACKEND_URL ?? "";

export type CouncilLine = {
  persona: PersonaId;
  message: string;
  delay_ms: number;
};

export type CouncilAnalysis = {
  chat_sequence: CouncilLine[];
  /** A new fact worth remembering about the user, if any. */
  memory?: string;
};

/** "The Verdict": the council's joint closing ruling. No scores, ever. */
export type CouncilVerdict = {
  diagnostics: { detected_symptoms: string[] };
  final_verdict: string;
};

export type CouncilVoteResult = { question: string; votes: CouncilVote[]; memory?: string };

type Envelope<T> = { data?: T; error?: { message: string; code: string } };

async function post<T>(path: string, body: unknown): Promise<T> {
  const response = await fetch(`${baseUrl}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

  const json = (await response.json().catch(() => null)) as Envelope<T> | null;

  if (!response.ok || !json?.data) {
    throw new Error(json?.error?.message ?? t("networkError"));
  }
  return json.data;
}

export const councilApi = {
  analyze: (input: {
    imageDataUrl?: string;
    context?: string;
    birth?: BirthProfile;
    personas?: PersonaId[];
    lang?: Language;
    history?: { role: "user" | "assistant"; content: string }[];
    memories?: string[];
    mode?: "grand";
  }) => post<CouncilAnalysis>("/api/council/analyze", input),

  vote: (input: {
    imageDataUrl?: string;
    context?: string;
    birth?: BirthProfile;
    personas?: PersonaId[];
    lang?: Language;
    memories?: string[];
    grand?: boolean;
  }) => post<CouncilVoteResult>("/api/council/analyze", { ...input, mode: "vote" }),

  verdict: (input: {
    history: { role: "user" | "assistant"; content: string }[];
    personas?: PersonaId[];
    lang?: Language;
  }) => post<CouncilVerdict>("/api/council/verdict", input),

  daily: (input: {
    date: string;
    birth?: BirthProfile;
    lang?: Language;
    memories?: string[];
  }) => post<{ persona: PersonaId; message: string; date: string }>("/api/council/daily", input),

  dm: (input: {
    persona: PersonaId;
    messages: { role: "user" | "assistant"; content: string }[];
    imageDataUrl?: string;
    birth?: BirthProfile;
    lang?: Language;
    memories?: string[];
  }) => post<{ persona: PersonaId; message: string; memory?: string }>("/api/council/dm", input),
};
