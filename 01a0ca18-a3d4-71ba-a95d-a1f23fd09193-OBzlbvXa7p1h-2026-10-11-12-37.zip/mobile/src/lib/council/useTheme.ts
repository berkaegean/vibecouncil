import { useCouncilStore } from "./store";
import { PALETTES, type Palette } from "./theme";

/**
 * The active palette. Subscribes only to the theme name (a primitive) so a
 * theme switch is the only thing that re-renders consumers.
 */
export function useTheme(): Palette {
  const name = useCouncilStore((s) => s.themeName);
  return PALETTES[name];
}
