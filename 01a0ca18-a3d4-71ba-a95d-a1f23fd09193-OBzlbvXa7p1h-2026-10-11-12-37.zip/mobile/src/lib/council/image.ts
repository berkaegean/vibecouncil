import * as ImagePicker from "expo-image-picker";

export type PickedImage = {
  uri: string;
  /** Ready-to-send `data:image/...;base64,...` URL. */
  dataUrl: string;
};

/**
 * Opens the photo library and returns both a local URI (for rendering)
 * and a base64 data URL (for the vision model).
 */
export async function pickImage(): Promise<PickedImage | null> {
  const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
  if (!permission.granted) return null;

  const result = await ImagePicker.launchImageLibraryAsync({
    mediaTypes: ["images"],
    allowsEditing: false,
    quality: 0.6,
    base64: true,
  });

  if (result.canceled || result.assets.length === 0) return null;

  const asset = result.assets[0];
  if (!asset?.base64) return null;

  const mimeType =
    asset.mimeType ?? (asset.uri.endsWith(".png") ? "image/png" : "image/jpeg");

  return { uri: asset.uri, dataUrl: `data:${mimeType};base64,${asset.base64}` };
}
