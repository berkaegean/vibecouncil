import { Platform } from "react-native";
import Purchases, { type PurchasesPackage } from "react-native-purchases";

import { useCouncilStore } from "./store";

/**
 * Consumable crystal packs. `productId` must match the App Store Connect /
 * RevenueCat product; `price` is a fallback until the store price loads.
 */
export type CrystalPack = {
  productId: string;
  amount: number;
  price: string;
  popular?: boolean;
};

export const CRYSTAL_PACKS: CrystalPack[] = [
  { productId: "vibecouncil_credits_20", amount: 20, price: "$3.99" },
  { productId: "vibecouncil_credits_60", amount: 60, price: "$7.99", popular: true },
  { productId: "vibecouncil_credits_150", amount: 150, price: "$16.99" },
];

// Test Store key in development; real store keys in production builds.
const apiKey = __DEV__
  ? process.env.EXPO_PUBLIC_VIBECODE_REVENUECAT_TEST_KEY
  : Platform.select({
      ios: process.env.EXPO_PUBLIC_VIBECODE_REVENUECAT_APPLE_KEY,
      android: process.env.EXPO_PUBLIC_VIBECODE_REVENUECAT_GOOGLE_KEY,
      default: undefined,
    });

let configured = false;

export const purchasesAvailable = (): boolean => configured;

export function initPurchases(): void {
  if (configured || !apiKey || Platform.OS === "web") return;
  try {
    Purchases.configure({ apiKey });
    configured = true;
  } catch (error) {
    console.warn("[purchases] configure failed", error);
  }
}

async function findPackage(productId: string): Promise<PurchasesPackage | null> {
  const offerings = await Purchases.getOfferings();
  const current = offerings.current;
  if (!current) return null;
  return current.availablePackages.find((p) => p.product.identifier === productId) ?? null;
}

/** Localized store prices keyed by product id; empty when the store is unavailable. */
export async function loadPackPrices(): Promise<Record<string, string>> {
  if (!configured) return {};
  try {
    const offerings = await Purchases.getOfferings();
    const prices: Record<string, string> = {};
    for (const p of offerings.current?.availablePackages ?? []) {
      prices[p.product.identifier] = p.product.priceString;
    }
    return prices;
  } catch {
    return {};
  }
}

export type PurchaseResult = "success" | "cancelled" | "unavailable";

/** Buys a consumable pack and grants its crystals locally on success. */
export async function purchaseCrystalPack(pack: CrystalPack): Promise<PurchaseResult> {
  if (!configured) return "unavailable";
  const pkg = await findPackage(pack.productId);
  if (!pkg) return "unavailable";
  try {
    await Purchases.purchasePackage(pkg);
    useCouncilStore.getState().grantCrystals(pack.amount);
    return "success";
  } catch (error: any) {
    if (error?.userCancelled) return "cancelled";
    throw error;
  }
}

/**
 * Grants crystals for a pack bought through the RevenueCat paywall.
 * Matches the product id against CRYSTAL_PACKS, falling back to the trailing amount.
 */
export function grantForProduct(productId: string): void {
  const pack = CRYSTAL_PACKS.find((p) => p.productId === productId);
  const amount = pack?.amount ?? Number(productId.match(/(\d+)$/)?.[1] ?? 0);
  if (amount > 0) useCouncilStore.getState().grantCrystals(amount);
}
