import { useEffect, type RefObject } from "react";
import { Keyboard, Platform, type FlatList } from "react-native";

/**
 * Keeps a chat list pinned to its newest message: jumps to the bottom on
 * first layout and scrolls back down whenever the keyboard opens.
 */
export function useStickToBottom(listRef: RefObject<FlatList | null>) {
  useEffect(() => {
    const event = Platform.OS === "ios" ? "keyboardWillShow" : "keyboardDidShow";
    const sub = Keyboard.addListener(event, () => {
      // Once now, and again after the padding animation has settled.
      listRef.current?.scrollToEnd({ animated: true });
      setTimeout(() => listRef.current?.scrollToEnd({ animated: true }), 280);
    });
    return () => sub.remove();
  }, [listRef]);

  return {
    onContentSizeChange: () => listRef.current?.scrollToEnd({ animated: false }),
  };
}
