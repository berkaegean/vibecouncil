# VibeCouncil

A mythological council that judges your screenshots. Four ancient voices read the situation and hand down an Aura score.

## Design language — "Hyper-Spatial Liquid Glass"

- Pure OLED black (`#000000`) with a single faint warm wash at the top — no coloured shapes, the glass panels are the only light source (`components/council/Atmosphere.tsx`)
- Frosted glass panels: severe blur, `rgba(255,255,255,0.06)` fill, hairline inner light refraction, zero heavy borders (`components/council/Glass.tsx`)
- Apple system type, massive negative space, champagne gold (`#D4AF37`) for active highlights
- Turkish UI throughout

## The roster

| Persona | Role | Sigil |
|---|---|---|
| **Nyx** | Gölge Yargıç — ruthless reality checks | Razor-thin eclipse ring |
| **Astraea** | Kozmik Hizalanma — karmic frequency reading | Intersecting orbits with a single vertex |
| **Metis** | Soğuk Stratejist — power moves and tactics | Open geometric diamond lattice |
| **Harmonia** | Dengeleyici — healing, empathetic closure | Two balanced vertical light bars |

Sigils are hand-drawn SVG paths in `mobile/src/lib/council/personas.tsx`.

## Screens

- **`/` Home** — masthead with credit badge (`⚡ 3`), a large breathing hero card that starts a full council, a horizontal rail of the four personas for instant DMs, then the history list. Long-press a history row to delete.
- **`/council/[id]` Group Council** — upload a photo + optional context ("Durumu açıkla..."), then the four speak in sequence with realistic typing delays (1.5–2.2s) and a "[Persona] yazıyor..." indicator. Ends with an Aura verdict card and a share sheet.
- **`/dm/[id]` Direct Chat** — free-form conversation with one persona, last 16 turns kept as context.
- **`/paywall`** — glass modal sheet for the 50-credit consumable ($4.99).

## Credits & monetization

Credits start at **3** and persist locally. One group analysis = **1 credit**; DMs are free. A failed analysis refunds the credit. At zero credits the paywall sheet is triggered.

Purchases are not wired yet — RevenueCat must be connected from the **Payments tab** in the Vibecode app first. The paywall currently explains this instead of faking a purchase.

## Architecture

**Mobile** (`mobile/`) — Expo Router, NativeWind, Reanimated.

- `src/lib/council/store.ts` — Zustand + AsyncStorage: threads, messages, credits
- `src/lib/council/api.ts` — typed client for the council endpoints
- `src/lib/council/image.ts` — photo picker returning both a local URI and a base64 data URL
- `src/lib/council/personas.tsx` — roster metadata and SVG sigils
- `src/lib/council/theme.ts` — colour tokens

**Backend** (`backend/`) — Hono. Holds the OpenAI key so it never ships in the app bundle.

- `POST /api/council/analyze` — `{ imageDataUrl?, context? }` → `{ chat_sequence[], final_verdict, share_quote }`, Zod-validated, delays clamped to 1500–2200ms
- `POST /api/council/dm` — `{ persona, messages[], imageDataUrl? }` → `{ persona, message }`
- `src/personas.ts` — Turkish system prompts and character voices

Both use OpenAI's Responses API with vision.
